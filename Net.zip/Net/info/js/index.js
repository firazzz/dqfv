_satellite['_runScript16'](function (event, target, Promise) {
    ;(function () {
      // environment detection
      function detectProduction() {
        if (
          !!window._satellite &&
          !!window._satellite.buildInfo &&
          !!window._satellite.buildInfo.environment &&
          window._satellite.buildInfo.environment == 'production'
        ) {
          return true
        }

        return false
      }

      // base url depending on environment
      function constructBaseUrl(suffix) {
        var baseURL = 'https://pixel.mijntelco.be/proximus/'
        if (!this.isProduction) {
          //      baseURL = baseURL.replace('pixel', 'RTT:fiets@pixel.staging');
          baseURL = baseURL.replace('pixel', 'pixel.staging')
        }
        if (!!suffix) {
          baseURL += suffix
        }
        return baseURL
      }

      // main 'class'
      function DPGPixel() {
        this.isProduction = this.detectProduction()
        this.pixels = {}
        this.pixelCNT = 0
        this.start = function start() {
          this.process()
          return this
        }
      }

      // class functions
      var proto = DPGPixel.prototype

      proto.process = process
      proto.detectProduction = detectProduction
      proto.constructBaseUrl = constructBaseUrl
      proto.objectToQS = objectToQS
      proto.addParameterToURL = addParameterToURL
      proto.lastCampaign = lastCampaign
      proto.getURL = getURL
      proto.getReferrer = getReferrer
      proto.getVisitorID = getVisitorID
      proto.getTS = getTS
      proto.isDPGLanding = isDPGLanding
      proto.sendPixel = sendPixel
      proto.detectWebform = detectWebform
      proto.isDPGLast = isDPGLast
      proto.isDPG = isDPG
      proto.detectOrder = detectOrder
      proto.processProducts = processProducts

      function lastCampaign() {
        return !!window._MCM && !!window._MCM.update
          ? window._MCM.update()
          : undefined
      }

      function addParameterToURL(url, parameter) {
        url += '?' + parameter
        return url
      }

      function sendPixel(url, type) {
        //check if this pixel has been send for this page
        if (!!this.pixels[type]) {
          return this
        } else {
          this.pixelCNT++
          this.pixels[type] = url
          url += '&ts=' + new Date().getTime() + ''
          var a = new Image()
          a.src = url
          document.head.appendChild(a)
        }

        return this
      }

      function isDPG(u) {
        u = !!u ? u.replace(/=/gm, ':').toLowerCase() : ''
        if (u.indexOf('v1:affiliate') > -1 && u.indexOf('v3:dpg') > -1) {
          return true
        }
        return false
      }

      function isDPGLanding(val) {
        if (this.isDPG(this.getURL())) {
          //only identify as landing page when the current url contains dpg params but the referrer does not, some pages 'rememmber' parameters across pageviews
          if (!!!this.isDPG(this.getReferrer())) {
            return true
          }
        }
        return false
      }

      function isDPGLast() {
        return this.isDPG(this.lastCampaign())
      }

      function process(data) {
        if (!!this.isDPGLanding()) {
          // this is a landing page with the proper parameters
          var url = this.constructBaseUrl('product-landing.gif')
          var queryData = {}
          var vid, u, ref, ts
          ;(vid = this.getVisitorID()) && (queryData.visitorId = vid)
          ;(u = this.getURL()) && (queryData.url = u)
          ;(ref = this.getReferrer()) && (queryData.referrer = ref)
          var qs = this.objectToQS(queryData)
          url = this.addParameterToURL(url, qs)
          this.sendPixel(url, 'landing')
        }

        if (!!this.isDPGLast()) {
          // console.log('The last Channel was DPG');
          //DPG was the last channel
          //do we need to send anything?
          if (!!this.detectWebform(data)) {
            // this is a webform success submission
            var url = this.constructBaseUrl('thank-you.gif')
            var queryData = { isWebForm: '1' }
            var vid, u, ref
            ;(vid = this.getVisitorID()) && (queryData.visitorId = vid)
            ;(u = this.getURL()) && (queryData.url = u)
            var qs = this.objectToQS(queryData)
            url = this.addParameterToURL(url, qs)
            this.sendPixel(url, 'webform')
          }
          if (!!this.detectOrder(data)) {
            // this is an order
            //console.log('This is an Order');
            var products = this.processProducts(data)
            //only send if we have product details
            if (!!products) {
              //console.log('This is an Order with products',products);
              var url = this.constructBaseUrl('thank-you.gif')
              var queryData = {
                products: products,
              }
              var vid, u, ref, ts
              ;(vid = this.getVisitorID()) && (queryData.visitorId = vid)
              ;(u = this.getURL()) && (queryData.url = u)
              var qs = this.objectToQS(queryData)
              //console.log('This is an Order with products and parameters',products,qs);
              url = this.addParameterToURL(url, qs)
              //console.log('Detected order :', url);
              this.sendPixel(url, 'order')
            }
          }
        }

        return undefined
      }

      function objectToQS(data) {
        data = data || {}
        var qs = []
        for (var key in data) {
          if (Object.hasOwnProperty.call(data, key)) {
            var element = data[key] || ''
            qs.push(key + '=' + encodeURIComponent(element.toLowerCase()))
          }
        }

        return qs.length > 0 ? qs.join('&') : undefined
      }

      function getVisitorID() {
        var id = !!window._satellite
          ? window._satellite.getVisitorId().getMarketingCloudVisitorID()
          : !!window.s && !!window.s.visitor
          ? window.s.visitor.getMarketingCloudVisitorID()
          : undefined
        return id
      }
      function getURL() {
        return document.location.href + ''
      }

      function getReferrer() {
        return document.referrer
      }

      function getTS() {
        return new Date().getTime() + ''
      }
      function detectWebform(data) {
        data = data || {}
        //for tealium
        var webformsuccess = !!data.ev && data.ev == 'webform_success'
        if (!!webformsuccess) {
          return true
        }
        //for launch
        if (
          !!data.eventname &&
          data.eventname == 'form-response' &&
          !!!(!!data.error && !!data.error.message)
        ) {
          return true
        }
        return false
      }

      function detectOrder(data) {
        data = data || {}
        //for tealium;
        var orderId = data.cart_order_id || data.order_id || false
        if (!!orderId) {
          //this is the ordering part for tealium
          return true
        }
        // for launch
        if (!!data.cart && !!data.cart.order_id) {
          return true
        }

        return false
      }

      function processProducts(data) {
        data = data || {}
        //tealium
        if (
          !!data.product_group_main &&
          !!data.product_type &&
          !!data.product_name &&
          !!data.product_qty
        ) {
          var o = []
          for (var index = 0; index < data.product_name.length; index++) {
            var product_name = data.product_name[index]
            var product_type = data.product_type[index]
            var product_group_main = data.product_group_main[index]
            var product_qty = data.product_qty[index]
            var sales_category = data.product_sales_category[index]
            var packornot =
              !!data.product_group_id && !!data.product_group_id[index]
                ? data.product_group_id[index]
                : product_group_main
            if (
              !!product_type &&
              product_type == 'new' &&
              !!sales_category
            ) {
              var tmp = []
              tmp.push(packornot)
              tmp.push(product_name)
              tmp.push(product_qty)
              tmp = tmp.join(':')
              o.push(tmp)
            }
          }
          if (o.length > 0) {
            return o.join(';')
          }
        }
      }
      window._dpgp = window._dpgp || new DPGPixel()
    })()
  })
  _satellite['_runScript17'](function (event, target, Promise) {
    window.dataLayer = window.dataLayer || []
    function gtag() {
      dataLayer.push(arguments)
    }
    window.gtag = window.gtage || gtag
    gtag('js', new Date())
    gtag('config', 'DC-5452414')
    gtag('config', 'UA-36292445-1', {
      send_page_view: false,
      groups: 'pickx',
    })
  })
  _satellite['_runScript15'](function (event, target, Promise) {
    !!window._MCM && window._MCM.update()
  })
  _satellite['_runScript14'](function (event, target, Promise) {
    ;(function () {
      function customAdobetargetTrackEvent(conf) {
        if (!!conf && !!conf.mbox) {
          if (conf.mbox == 'target-global-mbox') {
            conf.mbox = 'target-event-mbox'
          }
        }
        window.adobe.target._originalTrackEvent(conf)
      }
      if (
        !!window.adobe &&
        !!window.adobe.target &&
        !!adobe.target.trackEvent &&
        !window.adobe.target._originalTrackEvent
      ) {
        window.adobe.target._originalTrackEvent =
          window.adobe.target.trackEvent
        window.adobe.target.trackEvent = customAdobetargetTrackEvent
      }
    })()
  })
  _satellite['_runScript13'](function (event, target, Promise) {
    ;(function () {
      document.addEventListener('at-request-succeeded', setTTMeta)
      //prettier-ignore
      function setTTMeta(e){window.ttMETA=void 0!==window.ttMETA?window.ttMETA:[];var tokens=e.detail.responseTokens,uniqueTokens;isEmpty(tokens)||distinct(tokens).forEach((function(token){window.ttMETA.push({CampaignName:token["activity.name"],CampaignId:token["activity.id"],RecipeName:token["experience.name"],RecipeId:token["experience.id"],OfferId:token["offer.id"],OfferName:token["offer.name"],MboxName:e.detail.mbox})}))}
      //prettier-ignore
      function isEmpty(val){return void 0===val||null==val||val.length<=0}
      //prettier-ignore
      function key(obj){return Object.keys(obj).map((function(k){return k+""+obj[k]})).join("")}
      //prettier-ignore
      function distinct(arr){var result=arr.reduce((function(acc,e){return acc[key(e)]=e,acc}),{});return Object.keys(result).map((function(k){return result[k]}))}
    })()
  })
  _satellite['_runScript12'](function (event, target, Promise) {
    var previouspage = _satellite.cookie.get('gpv_v18')

    if (!!previouspage) {
      _satellite.logger.log('The previous page was', previouspage)
      _satellite.setVar('_Previous Page', previouspage)
      _satellite.cookie.remove('gpv_v18')
    }
  })
  _satellite['_runScript11'](function (event, target, Promise) {
    ;(function () {
      // prettier-ignore
      var matches=function matches(elem,selector){var p=Element.prototype,f;return(p.matches||p.webkitMatchesSelector||p.mozMatchesSelector||p.msMatchesSelector||function(s){return-1!==[].indexOf.call(document.querySelectorAll(s),this)}).call(elem,selector)};
      // prettier-ignore
      var closest=function closest(elem,selector){if(elem.closest)return elem.closest(selector);for(;elem;){if(matches(elem,selector))return elem;elem=elem.parentElement}return null};
      // prettier-ignore
      var clean=function clean(){function removeAccents(str){var accents="ÀÁÂÃÄÅàáâãäåÒÓÔÕÕÖØòóôõöøÈÉÊËèéêëðÇçÐÌÍÎÏìíîïÙÚÛÜùúûüÑñŠšŸÿýŽž",accentsOut="AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeCcDIIIIiiiiUUUUuuuuNnSsYyyZz",strLen=(str=str.split("")).length,i,x;for(i=0;i<strLen;i++)-1!=(x=accents.indexOf(str[i]))&&(str[i]=accentsOut[x]);return str.join("")}function replace(string){if("string"!=typeof string)return string;var slug=string.replace(/[,*+~.()'"?!:@]/gm,"").replace(/^\s+|\s+$/g,"").replace(/[-\s]+/g,"-").replace(/[\u1000-\uFFFF]+/g,"").replace(/(^-)|(-$)/g,"");return(slug=slug.normalize&&"function"==typeof slug.normalize?slug.normalize("NFD").replace(/[\u0300-\u036f]/g,""):removeAccents(slug)).toLowerCase()}return replace}();
      // prettier-ignore
      var getTxt=function getTxt(){var text="innerText"in document.createElement("div")?"textContent":"textContent";return function getTxt(el){return el?el[text]:null}}();
      // prettier-ignore
      function extend(){var extended={},deep=!1,i=0;"[object Boolean]"===Object.prototype.toString.call(arguments[0])&&(deep=arguments[0],i++);for(var merge=function(obj){for(var prop in obj)obj.hasOwnProperty(prop)&&(deep&&"[object Object]"===Object.prototype.toString.call(obj[prop])?extended[prop]=extend(extended[prop],obj[prop]):extended[prop]=obj[prop])};i<arguments.length;i++)merge(arguments[i]);return extended}
      // prettier-ignore
      function unflatten(target,opts){var delimiter=(opts=opts||{}).delimiter||".",overwrite=opts.overwrite||!0,result={},sortedKeys;if("[object Object]"!==Object.prototype.toString.call(target))return target;function getkey(key){var parsedKey=Number(key);return isNaN(parsedKey)||-1!==key.indexOf(".")||opts.object?key:parsedKey}return Object.keys(target).sort((function(keyA,keyB){return keyA.length-keyB.length})).forEach((function(key){for(var split=key.split(delimiter),key1=getkey(split.shift()),key2=getkey(split[0]),recipient=result;void 0!==key2;){var type=Object.prototype.toString.call(recipient[key1]),isobject="[object Object]"===type||"[object Array]"===type;if(!overwrite&&!isobject&&void 0!==recipient[key1])return;(overwrite&&!isobject||!overwrite&&null==recipient[key1])&&(recipient[key1]="number"!=typeof key2||opts.object?{}:[]),recipient=recipient[key1],split.length>0&&(key1=getkey(split.shift()),key2=getkey(split[0]))}recipient[key1]=unflatten(target[key],opts)})),result}
      // prettier-ignore
      function getAttributes(el){if(el){for(var out={},att=el.attributes,i=0;i<att.length;i++){var el=att[i];(t=el.name.replace("data-tms-",""))!=el.name&&(0!=t.indexOf("event-")&&(t=t.replace(/-/gm,".")),out[t]=((el.value || '').toLowerCase()))}return i>0?out:{}}}
      // prettier-ignore
      function getComponentName(event){if(event){var component=event||"";return(component=component.split("-")).shift()}}
      // prettier-ignore
      function getImageDataFromElement(clickable){var img=clickable.querySelector("img");if(img){var ra=null;if(t=img.alt,t=t&&""!==t?t:img.src,t=t.indexOf("/")>-1&&(ra=/.*\/(.*?)\.\w*$/.exec(t))?ra[1]:t,t)return t}} // prettier-ignore
      // prettier-ignore
      function getIconDataFromElement(clickable){var is=clickable.getElementsByTagName("i");if(is.length>0){var tn=is[0].className,x=!1,t=!1;if(t=(x=/.*?icon-([^ \n]*)/.exec(tn))?x[1]:t)return t}}
      // prettier-ignore
      function getAutoTrackingData(el){var imgData=clean(getImageDataFromElement(el));if(imgData)return imgData;var txtData=clean(getTxt(el));if(txtData)return txtData;var iconData=clean(getIconDataFromElement(el));return iconData||void 0}
      // prettier-ignore
      function isEmptyObject(value){if(null==value)return!0;for(var key in value)if(hasOwnProperty.call(value,key))return!1;return!0}
      //prettier-ignore
      function contains(context,node){return context.contains?context.contains(node):context.compareDocumentPosition?context===node||!!(16&context.compareDocumentPosition(node)):void 0}
      //prettier-ignore
      function safeJSONParse(v){var o=void 0;try{o=JSON.parse(v)}catch(e){}return o}
      //prettier-ignore
      function isJSONText(v){return!!("string"==typeof v&&v.indexOf("{")>-1&&/^[\[|\{](\s|.*|\w)*[\]|}]$/.test(v))}
      //prettier-ignore
      function ObjectIsElement(obj){var IsElem=!0;return null==obj?IsElem=!1:"object"!=typeof obj.appendChild&&"function"!=typeof obj.appendChild?IsElem=!1:-1==(obj.appendChild+"").replace(/[\r\n\t\b\f\v\xC2\xA0\x00-\x1F\x7F-\x9F ]/gi,"").search(/\{\[NativeCode]}$/i)?IsElem=!1:1!=obj.nodeType&&(IsElem=!1),IsElem}
      // correctly parse values
      function jsonReplacer(k, v) {
        if (!!v && isJSONText(v)) {
          return safeJSONParse(v)
        }
        if (!!v && ObjectIsElement(v)) {
          return getClickData(v) || 'dom node'
        }
        return v
      }
      //make a 'copy' of the input and transform any json values
      function transformJSONValues(o) {
        var output
        var out = JSON.stringify(o, jsonReplacer)
        if (!!out) {
          output = safeJSONParse(out)
          !!!output && (output = o)
        } else {
          output = o
        }
        return output
      }
      window.__ = window.__ || {}
      window.__.clickTracker = {
        contains: contains,
        closest: closest,
        matches: matches,
        getTxt: getTxt,
        extend: extend,
        unflatten: unflatten,
        getAttributes: getAttributes,
        getComponentName: getComponentName,
        getImageDataFromElement: getImageDataFromElement,
        getIconDataFromElement: getIconDataFromElement,
        getAutoTrackingData: getAutoTrackingData,
        getClickData: getClickData,
        handleEvent: clickHandler,
      }

      function clickHandler(event) {
        var el = event.target
        if (el) {
          var x = getClickData(el)
          if (!!x && !isEmptyObject(x) && !!window.pxdatalayer) {
            x = transformJSONValues(x)
            window.pxdatalayer.push(x)
          }
        }
        return true
      }
      function getLegacyAutoTagData(el, boundary) {
        //this use case handles the old data-tms-id situation
        //the boundary being defined on the element with a data tms id
        var out
        var tmsId = boundary
          .getAttribute('data-tms-id')
          .toLowerCase()
          .replace('tms_', '')
        var event = 'link-click'
        var component = 'link'
        var selectorsClickable = [
          'a,button',
          '.rs-clickable',
          '.jsrs-clickable',
          '.rs-box-clickable',
        ].join(',')
        var clickable = closest(el, selectorsClickable)
        if (clickable) {
          if (
            !(clickable.nodeName == 'A' || clickable.nodeName == 'BUTTON')
          ) {
            var clickablechild = clickable.querySelector('a,button')
            clickable = clickablechild ? clickablechild : clickable
          }
          var clickableData = getAutoTrackingData(clickable)
          if (clickableData) {
            var x = getAttributes(clickable)
            x = unflatten(x)
            x.event = event
            x[component] = x[component] || {}
            x[component].zone = tmsId
            x[component].text = clickableData
            return x
          }
        }
        return out
      }

      function getNewAutoTagData(el, boundary) {
        var out
        if (boundary == el) {
          return unflatten(getAttributes(el))
        } else {
          var pnode = el
          var linkDetected = false
          var data = []
          while (pnode && pnode != boundary) {
            var dt = getAttributes(pnode)
            if (
              (isEmptyObject(dt) && pnode.nodeName == 'A') ||
              pnode.nodeName == 'BUTTON'
            ) {
              var text = getAutoTrackingData(pnode)
              dt['link.text'] = text
              clickable = pnode
              linkDetected = true
            }
            data.unshift(dt)
            pnode = pnode.parentNode
          }
          if (!linkDetected) {
            var jsclickable = closest(el, '.jsrs-clickable,.rs-clickable')
            if (jsclickable) {
              var jsclickablechild = jsclickable.querySelector('a,button')
              if (jsclickablechild) {
                var dt = getAttributes(jsclickablechild)
                var text = getAutoTrackingData(jsclickablechild)
                dt['link.text'] = text
                data.push(dt)
              }
            }
          }
          data.unshift(getAttributes(boundary))
          x = extend.apply(extend, data)
          x = unflatten(x)
          return x
        }
      }

      function getBasicAutoTagData(el) {
        //this use case is there when no tms id's nor proper data attributes are found
        //this is the most basic way of fetching click details
        var boundary = closest(el, 'a,button')
        if (!!boundary) {
          var dt = getAttributes(boundary)
          var data = getAutoTrackingData(boundary)
          if (!!data) {
            dt.event = 'link-click'
            dt.link = dt.link || {}
            dt.link.text = dt.link.text || data
            return dt
          }
        }
        return undefined
      }

      function getClickData(el) {
        //return empty object when no element is specified
        if (!el) {
          return false
        }

        //this part is for the manually defined tracking
        //it uses the data attributes as a guidance to get the data
        var boundary = closest(el, '[data-tms-event*="-click"]')
        var component = !!boundary
          ? getComponentName(boundary.getAttribute('data-tms-event'))
          : 'link' //get the actual component or default to 'link'
        var noclick = closest(el, '[data-tms-noclick]')

        if (!!boundary) {
          if (!!noclick && contains(boundary, noclick)) {
            _satellite.logger.log('Noclick within boundary found. Abort')
            return false
          }
          x = getNewAutoTagData(el, boundary)
          x._meta = x._meta || {}
          x._meta.taggingType = 'html'
        } else {
          //check if the element's parent does not have the attribute data-tms-noclick,else bail, we do not track these
          if (!!noclick) {
            _satellite.logger.log('Noclick found. Abort')
            return false
          }
          var boundary = closest(el, '[data-tms-id]')
          if (!!boundary) {
            x = getLegacyAutoTagData(el, boundary)
            if (!!x) {
              x._meta = x._meta || {}
              x._meta.taggingType = 'legacy'
            }
          } else {
            x = getBasicAutoTagData(el)
            if (!!x) {
              x._meta = x._meta || {}
              x._meta.taggingType = 'basic'
            }
          }
        }
        if (
          !!x &&
          !!x[component] &&
          (!!x[component].name || !!x[component].text)
        ) {
          if (!!x[component].name) {
            x[component].name = clean(x[component].name)
          }
          x._meta.component = component
          x.event = component + '-click'
          //workaround for funnel-click added 09/07
          // when a funnel click happens without a button or link element then abort
          if (component == 'funnel' && !!!x.button && !!!x.link) {
            return false
          }
          return x
        }
        return false
      }
      //the following section checks if the addEventHandler has been instrumented by Angular Zone.js
      // if it has been, we check if the native addEventListener is available and use that one.
      // this would make sure that there is no interference from ANgular with our code and should have a small perf boost.
      // AngularJS EVIL
      /* prettier-ignore-start */
      var de = document.documentElement
      var aavl = window.__zone_symbol__addEventListener
      if (!!aavl && typeof aavl == 'function') {
        aavl.call(de, 'mousedown', window.__.clickTracker, true)
      } else {
        de.addEventListener('mousedown', window.__.clickTracker, true)
      }
      /* prettier-ignore-end */
    })()
  })
  _satellite['_runScript10'](function (event, target, Promise) {
    !(function (root, globalName) {
      function RequestManager() {
        var currentUrl
        Object.defineProperty(this, 'currentUrl', {
          get: function () {
            return this.checkCurrentUrl(
              currentUrl || document.location.href,
            )
          },
          set: function (url) {
            return (currentUrl = url), this.checkCurrentUrl(url)
          },
        }),
          (this.validateUrl = function validateUrl(url) {
            if (!url) return !1
            if (0 == url.indexOf('http') && -0 !== url.indexOf('//')) {
              var thisUrlDetails = this.parseUri(url),
                thisUrlTLD = thisUrlDetails.tld
              if (
                (this.currentUrl.tld != thisUrlTLD &&
                  -1 ==
                    this.whitelistDomains.indexOf(thisUrlDetails.host)) ||
                this.blacklistDomains.indexOf(thisUrlDetails.host) > -1
              )
                return !0
            }
            return !1
          }),
          (this.checkUrl = function checkUrl(url) {
            if (!!url && 'string' !== typeof url) {
              return url
            }
            return (
              this.validateUrl(url) && (url = this.sanitizeUrl(url)), url
            )
          }),
          (this.intercept = function intercept() {
            this.interceptDOM(),
              this.interceptXHR(),
              this.interceptFetch(),
              this.interceptSendBeacon()
          }),
          (this.restore = function restore() {
            this.restoreDOM(),
              this.restoreXHR(),
              this.restoreFetch(),
              this.restoreSendBeacon()
          })
      }
      var rmproto = RequestManager.prototype
      //remove html encoding for ampersands and equal signs
      rmproto.removeHtmlEncoding = function removeHtmlEncoding(str) {
        if (!!!str) {
          return str
        }
        //this construct is needed as tealium is replacing the amp part during saving/minifiction
        var r = new RegExp(['&', 'amp', ';'].join(''), 'gm')
        str = str.replace(r, '&')
        str = str.replace(/&equals;/gm, '=')
        return str
      }
      ;(rmproto.whitelistKeys = []),
        (rmproto.whitelistDomains = []),
        (rmproto.blacklistDomains = []),
        (rmproto.checkCurrentUrl = function checkCurrentUrl(url) {
          url && (url = this.removeHtmlEncoding(url))
          url && (url = this.parseUri(url))
          var outArray = (urlQSArray = hashArray = [])
          url.query && (urlQSArray = url.query.split('&'))
          var hash = url.anchor ? url.anchor.split('?')[1] : void 0
          hash = !!hash
            ? hash
            : url.anchor && url.anchor.indexOf('=') > -1
            ? url.anchor
            : void 0
          hash &&
            hash.length > 0 &&
            hash.indexOf('=') > -1 &&
            (hashArray = hash.split('&')),
            (outArray = [].concat(urlQSArray, hashArray)),
            (this.whitelistKeys = this.whitelistKeys || [])
          for (
            var newQSList = [], index = 0;
            index < outArray.length;
            index++
          ) {
            var element = outArray[index]
            if (element && element.indexOf('=') > -1) {
              var key = element.replace(/=.*/, '')
              ;-1 == this.whitelistKeys.indexOf(key) &&
                (newQSList.push(element),
                newQSList.push(encodeURIComponent(element)))
            }
          }
          ;(outArray = newQSList),
            (url.qslist =
              outArray && outArray.length > 0 ? outArray : void 0)
          var qstring = outArray ? '(' + outArray.join('|') + ')' : void 0
          return (
            (url.qsrx =
              qstring && '(|)' != qstring && '()' != qstring
                ? new RegExp(qstring, 'gmi')
                : void 0),
            url
          )
        }),
        (function (root) {
          function getHostAndPath(url) {
            var match = /([^\/]*:?\/\/)?([^\/^?]*)([^?]*)?/.exec(url)
            if (match) {
              for (
                var host = match[2],
                  path = match[3] ? match[3].split('/') : [],
                  filteredpath = [],
                  i = 0;
                i < path.length;
                i++
              ) {
                var p = path[i]
                p && filteredpath.push(p)
              }
              return { host: host, path: filteredpath }
            }
          }
          function getQueryAndHash(url) {
            var o = { query: '', hash: '' }
            var indexOfQuestionSign = indexOf('?', url)
            //handle the queryparameters
            if (-1 !== indexOfQuestionSign) {
              var source = url.slice(indexOfQuestionSign + 1)
              if (!!source) {
                var indexOfHash = indexOf('#', source)
                if (-1 !== indexOfHash) {
                  source = source.slice(0, indexOfHash)
                }
                o.query = source
              }
            }
            var indexOfHash = indexOf('#', url)
            if (-1 !== indexOfHash) {
              var hash = url.slice(indexOfHash + 1)
              o.hash = hash
            }
            return o
          }
          function parse(url) {
            var hp = getHostAndPath(url),
              qh = getQueryAndHash(url),
              host = hp.host,
              path,
              query,
              hash,
              tld,
              h,
              result
            return {
              host: host,
              path: hp.path,
              query: qh.query,
              anchor: qh.hash,
              tld:
                ((h = (h = host) ? h.split('.') : []).length > 2 &&
                  (h = [h[h.length - 2], h[h.length - 1]]),
                h.join('.')),
            }
          }
          function decode(component) {
            try {
              return decodeURIComponent(component)
            } catch (e) {
              return component
            }
          }

          function indexOf(string, context) {
            return context.indexOf(string)
          }
          root.parseUri = parse
        })(rmproto),
        (rmproto.sanitizeUrl = function sanitizeUrl(url) {
          var outurl = url,
            regx = this.currentUrl.qsrx
          return url
            ? (regx &&
                (outurl = url.replace(regx, function sanitizeReplace() {
                  var value = arguments[0]
                  return (
                    3 == (value = value.split(/(%3D|=)/)).length &&
                      value.pop(),
                    value.push('x'),
                    (value = value.join(''))
                  )
                })),
              outurl)
            : url
        }),
        (rmproto.interceptDOM = function interceptDOM() {
          var that = this
          if (rmproto._interceptDOM) return !0
          for (
            var _interceptDOM = {},
              DOMELEMENTS = [
                'HTMLImageElement',
                'HTMLIFrameElement',
                'HTMLScriptElement',
              ],
              index = 0;
            index < DOMELEMENTS.length;
            index++
          ) {
            var element = DOMELEMENTS[index]
            ;(_interceptDOM[element] = Object.getOwnPropertyDescriptor(
              window[element].prototype,
              'src',
            )),
              Object.defineProperty(window[element].prototype, 'src', {
                configurable: !0,
                set: srcHandler,
              })
          }
          function srcHandler(src) {
            var url = that.checkUrl(src)
            url && this.setAttribute('src', url)
          }
          return (rmproto._interceptDOM = _interceptDOM), this
        }),
        (rmproto.restoreDOM = function restoreDOM() {
          if (rmproto._interceptDOM)
            for (var key in rmproto._interceptDOM)
              if (rmproto._interceptDOM.hasOwnProperty(key)) {
                var element = rmproto._interceptDOM[key]
                Object.defineProperty(window[key].prototype, 'src', element)
              }
        }),
        (rmproto.interceptFetch = function interceptFetch() {
          var that = this
          if (
            !('fetch' in window && 'function' == typeof window.fetch) ||
            this._fetch
          )
            return !1
          ;(rmproto._fetch = window.fetch),
            (window.fetch = function interceptFetch(url, options) {
              return (
                url && (url = that.checkUrl(url)),
                that._fetch.apply(this, [url, options])
              )
            })
        }),
        (rmproto.restoreFetch = function restoreFetch() {
          window.fetch = this._fetch
        }),
        (rmproto.interceptSendBeacon = function interceptSendBeacon() {
          if (
            !window.navigator ||
            !window.navigator.sendBeacon ||
            'function' != typeof window.navigator.sendBeacon ||
            this._navigatorSendBeacon
          )
            return !1
          var that = this
          ;(rmproto._navigatorSendBeacon = window.navigator.sendBeacon),
            (window.navigator.sendBeacon = function interceptNavigatorSendBeacon(
              url,
              data,
            ) {
              return (
                url && (url = that.checkUrl(url)),
                that._navigatorSendBeacon.apply(this, [url, data])
              )
            })
        }),
        (rmproto.restoreSendBeacon = function restoreBeacon() {
          this._navigatorSendBeacon &&
            (window.navigator.sendBeacon = this._navigatorSendBeacon)
        }),
        (rmproto.interceptXHR = function interceptXHR(
          urlmatch,
          callback,
          once,
        ) {
          var that = this
          ;(rmproto._XHROpen = XMLHttpRequest.prototype.open),
            (rmproto._XHRSend = XMLHttpRequest.prototype.send),
            (XMLHttpRequest.prototype.open = function interceptOpen(
              method,
              url,
              async,
              user,
              password,
            ) {
              void 0 === async && (async = !0),
                url &&
                  ((this._originalUrl = url), (url = that.checkUrl(url))),
                that._XHROpen.apply(this, [
                  method,
                  url,
                  async,
                  user,
                  password,
                ])
            }),
            (XMLHttpRequest.prototype.send = function interceptSend(body) {
              var url = this.responseURL || this._originalUrl
              body &&
                'string' == typeof body &&
                url &&
                that.validateUrl(url) &&
                (body = that.sanitizeUrl(body)),
                that._XHRSend.apply(this, [body])
            })
        }),
        (rmproto.restoreXHR = function restoreXHR() {
          this._XHROpen && (XMLHttpRequest.prototype.open = this._XHROpen),
            this._XHRSend && (XMLHttpRequest.prototype.send = this._XHRSend)
        }),
        (globalName = globalName || '_rqmgr'),
        (window[globalName] = new RequestManager())
    })(window, '_rqmgr')

    window._rqmgr.whitelistKeys = [
      'v1',
      'v2',
      'v3',
      'v4',
      'v5',
      'v6',
      'v7',
      'v8',
      'rid',
      'lang',
      'pricingplan',
      'pricingPlan',
      'mobile',
      'television',
      'fixed',
      'tvoption',
      'pack',
      'state',
      'execution',
      'select',
      'ismypxs',
      'city',
      'inapp',
      'ru',
    ]
    //additional whitelisting for webforms
    //check if this is a webform
    var l2 = _satellite.getVar('Page Category L2')
    if (!!l2 && l2.toLowerCase() == 'forms') {
      window._rqmgr.whitelistKeys.push('mobile')
      window._rqmgr.whitelistKeys.push('callconnectlicence')
      window._rqmgr.whitelistKeys.push('internetguarantee')
      window._rqmgr.whitelistKeys.push('proximustv')
      window._rqmgr.whitelistKeys.push('tvbonus')
      window._rqmgr.whitelistKeys.push('tvreplayplus')
      window._rqmgr.whitelistKeys.push('bizzonline')
      window._rqmgr.whitelistKeys.push('eoy')
    }
    //for beats pages
    if (document.location.href.toLowerCase().indexOf('cr_beats') > -1) {
      window._rqmgr.whitelistKeys.push('ci')
      window._rqmgr.whitelistKeys.push('fixed-service')
      window._rqmgr.whitelistKeys.push('tv-option')
    }
    window._rqmgr.whitelistDomains = [
      'skynet.be',
      '',
      'maps.googleapis.com',
    ] //domain+subdomains, no protocol
    window._rqmgr.blacklistDomains = [
      'smetrics.proximus.be',
      'metrics.proximus.be',
    ] //domain+subdomains, no protocol
    window._rqmgr.intercept()
  })
  _satellite['_runScript9'](function (event, target, Promise) {
    // Start.identify version 1.0.0
    ;(function () {
      'use strict'

      //  detects if session Storage is supported
      // this can be problem on private browsing sessions namely on Apple devices
      function isSessionStorageSupported() {
        try {
          var testKey = 'test',
            storage = window.sessionStorage
          storage.setItem(testKey, '1')
          storage.removeItem(testKey)
          return true
        } catch (error) {
          return false
        }
      }

      //  detects if localStorage is supported
      // this can be problem on private browsing sessions namely on Apple devices
      function isLocalStorageSupported() {
        try {
          var testKey = 'test',
            storage = window.localStorage
          storage.setItem(testKey, '1')
          storage.removeItem(testKey)
          return true
        } catch (error) {
          return false
        }
      }

      function decodeRFC(s) {
        s = s + ''
        return s
          .replace(/\*/gm, '##')
          .replace(/##/gm, ',')
          .replace(/!/gm, ' ')
      }

      function getCookie(name) {
        var nameEQ = name + '='
        var ca = document.cookie.split(';')

        for (var i = 0; i < ca.length; i++) {
          var c = ca[i]

          while (c.charAt(0) == ' ') {
            c = c.substring(1, c.length)
          }

          if (c.indexOf(nameEQ) == 0) {
            var d = c.substring(nameEQ.length, c.length)
            d = decodeRFC(d)
            return d
          }
        }

        return undefined
      }

      // check if the user is authenticated
      function getAuthentificationStatus() {
        //get the authentification level
        var o = {
          loggedIn: false,
          authenticated: false,
          status: 'unknown',
        } //only the iamsid cookie is usable to identify a correct active session
        //the BGC_AUTH_LVL cookie was used as well but this is a session cookie and doe not expire unless the page is either refreshed or closed and false positive might be detected due to that
        // need to check as well in ITT/UAT since the iiamsid cookie is httponly in one of these environments and hence not accessible....:-(

        var isLoggedIn = !!document.cookie.match(
          /^(.*;)?\s*iiamsid|iiamsid-*\s*=\s*[^;]+(.*)?$/,
        )

        if (isLoggedIn) {
          o.loggedIn = true
          o.authenticated = true
          o.status = 'authenticated - logged in'
          return o
        }

        var isOnlyAuth =
          (document.cookie.match(
            /^(?:.*;)?\s*BGC_AUT_LVL\s*=\s*([^;]+)(?:.*)?$/,
          ) || [, null])[1] === 'IDE'

        if (isOnlyAuth) {
          o.loggedIn = false
          o.authenticated = true
          o.status = 'authenticated - not logged in'
          return o
        }

        o.loggedIn = false
        o.authenticated = false
        o.status = 'not authenticated'
        return o
      }

      function encodeRFC(s) {
        s = s + ''
        return s
          .replace(/^,/gm, '')
          .replace(/,$/gm, '')
          .replace(/\*/gm, ',')
          .replace(/,/gm, '##')
          .replace(/\s/gm, '!')
      }

      var type = {} //type checking functions

      ;(function () {
        var types = 'Array Object String Date RegExp Function Boolean Number Null Undefined'.split(
          ' ',
        )

        var typef = function typef() {
          return Object.prototype.toString.call(this).slice(8, -1)
        }

        for (var i = types.length; i--; ) {
          type['is' + types[i]] = (function (self) {
            return function (elem) {
              return typef.call(elem) === self
            }
          })(types[i])
        }
      })()

      var config = {
        currentDomain: getURLDomain(document.domain) || 'proximus.be',
      } //var currentDomain = config.currentDomain;

      function getURLDomain(a, b, c) {
        b = a.split('.')
        c = /\.co\.|\.com\.|\.org\.|\.edu\.|\.net\.|\.asn\./.test(a) ? 3 : 2
        return b.splice(b.length - c, c).join('.')
      }

      function setCookie(name, value, days, dom) {
        value = encodeRFC(value)
        var ck = name + '=' + value

        if (days && type.isNumber(days)) {
          var d = new Date()
          d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000)
          ck += '; expires=' + d.toGMTString()
        }

        ck += '; domain=' + (dom ? dom : '.' + config.currentDomain)
        ck += '; path=/'
        document.cookie = ck
        return ck
      }

      //check if an object is empty
      function isEmptyObject(value) {
        if (null == value) return !0

        for (var key in value) {
          if (hasOwnProperty.call(value, key)) return !1
        }

        return !0
      }

      // return the first numeric value from an array
      function takeNumber(arr) {
        //convert input to array if it is not the case
        if (!type.isArray(arr)) {
          arr = [arr]
        }

        var i = arr.length
        i = !!i ? i + 1 : 0
        var y = arr.length
        var t

        while (i--) {
          if ((t = arr[y - i])) {
            if (t * 1 > 0) {
              return t * 1
            }
          }
        }

        return undefined
      }

      //check if input is SHA256 hashed
      function isSHA256(inputString) {
        if (!!!inputString) {
          return false
        }

        if (!type.isString(inputString) && type.isNumber(inputString)) {
          inputString = inputString.toString()
        }

        return /\b[A-Fa-f0-9]{64}\b/.test(inputString)
      }

      //lite version of the hashing method sha256

      function i2s(a) {
        // integer array to hex string
        for (var i = a.length; i--; ) {
          a[i] = ('0000000' + (a[i] >>> 0).toString(16)).slice(-8)
        }

        return a.join('')
      }

      function s2i(_s) {
        // string to integer array
        var s = unescape(encodeURIComponent(_s)),
          len = s.length,
          i = 0,
          bin = []

        for (; i < len; ) {
          bin[i >> 2] =
            (s.charCodeAt(i++) << 24) |
            (s.charCodeAt(i++) << 16) |
            (s.charCodeAt(i++) << 8) |
            s.charCodeAt(i++)
        }

        bin.len = len
        return bin
      }

      function shaInit(bin, len) {
        if (typeof bin == 'string') {
          bin = s2i(bin)
          len = bin.len
        } else len = len || bin.length << 2

        bin[len >> 2] |= 0x80 << (24 - (31 & (len <<= 3)))
        bin[(((len + 64) >> 9) << 4) + 15] = len
        return bin
      } //** sha256

      var initial_map = [],
        constants_map = []

      function buildMaps() {
        // getFractionalBits
        function a(e) {
          return ((e - (e >>> 0)) * 0x100000000) | 0
        }

        outer: for (var b = 0, c = 2, d; b < 64; c++) {
          // isPrime
          for (d = 2; d * d <= c; d++) {
            if (c % d === 0) continue outer
          }

          if (b < 8) initial_map[b] = a(Math.pow(c, 0.5))
          constants_map[b++] = a(Math.pow(c, 1 / 3))
        }
      }

      function convertsha256(data, _len) {
        initial_map[0] || buildMaps()
        var a,
          b,
          c,
          d,
          e,
          f,
          g,
          h,
          t1,
          t2,
          j,
          i = 0,
          w = [],
          A = initial_map[0],
          B = initial_map[1],
          C = initial_map[2],
          D = initial_map[3],
          E = initial_map[4],
          F = initial_map[5],
          G = initial_map[6],
          H = initial_map[7],
          bin = shaInit(data, _len),
          len = bin.length,
          K = constants_map

        for (; i < len; ) {
          a = A
          b = B
          c = C
          d = D
          e = E
          f = F
          g = G
          h = H

          for (j = 0; j < 64; ) {
            if (j < 16) w[j] = bin[i + j]
            else {
              t1 = w[j - 2]
              t2 = w[j - 15]
              w[j] =
                ((t1 >>> 17) ^
                  (t1 << 15) ^
                  (t1 >>> 19) ^
                  (t1 << 13) ^
                  (t1 >>> 10)) +
                (w[j - 7] | 0) +
                ((t2 >>> 7) ^
                  (t2 << 25) ^
                  (t2 >>> 18) ^
                  (t2 << 14) ^
                  (t2 >>> 3)) +
                (w[j - 16] | 0)
            }
            t1 =
              (w[j] | 0) +
              h +
              ((e >>> 6) ^
                (e << 26) ^
                (e >>> 11) ^
                (e << 21) ^
                (e >>> 25) ^
                (e << 7)) +
              ((e & f) ^ (~e & g)) +
              K[j++]
            t2 =
              ((a >>> 2) ^
                (a << 30) ^
                (a >>> 13) ^
                (a << 19) ^
                (a >>> 22) ^
                (a << 10)) +
              ((a & b) ^ (a & c) ^ (b & c))
            h = g
            g = f
            f = e
            e = (d + t1) | 0
            d = c
            c = b
            b = a
            a = (t1 + t2) | 0
          }

          A += a
          B += b
          C += c
          D += d
          E += e
          F += f
          G += g
          H += h
          i += 16
        }

        return [A, B, C, D, E, F, G, H]
      }

      function SHA256(data) {
        var o = void 0

        if (!!!data) {
          return undefined
        }

        if (!type.isString(data) && type.isNumber(data)) {
          data = data.toString()
        }

        if (type.isString(data)) {
          data = data.replace(/^[ ]+/g, '').replace(/[ ]+$/g, '')
        }

        if (!!data && type.isString(data)) {
          o = i2s(convertsha256(data))
        }

        return o
      }

      //check if input is MD5Hashed
      function isMD5(inputString) {
        return /[a-fA-F0-9]{32}/.test(inputString)
      }

      // hash input to MD5
      function FF(a, b, c, d, m, s, k) {
        var n = a + ((b & c) | (~b & d)) + (m >>> 0) + k
        return ((n << s) | (n >>> (32 - s))) + b
      }

      function GG(a, b, c, d, m, s, k) {
        var n = a + ((b & d) | (c & ~d)) + (m >>> 0) + k
        return ((n << s) | (n >>> (32 - s))) + b
      }

      function HH(a, b, c, d, m, s, k) {
        var n = a + (b ^ c ^ d) + (m >>> 0) + k
        return ((n << s) | (n >>> (32 - s))) + b
      }

      function II(a, b, c, d, m, s, k) {
        var n = a + (c ^ (b | ~d)) + (m >>> 0) + k
        return ((n << s) | (n >>> (32 - s))) + b
      }

      function bs(_byte) {
        return String.fromCharCode(255 & _byte)
      }

      function wordToBytes(word) {
        return bs(word) + bs(word >>> 8) + bs(word >>> 16) + bs(word >>> 24)
      }

      function byteToHex(_byte2) {
        return (256 + (255 & _byte2)).toString(16).substr(-2)
      }

      var utf8toBytes = function utf8toBytes(utf8) {
        return unescape(encodeURIComponent(utf8))
      }

      function bytesToWords(bytes) {
        for (
          var bytes_count = bytes.length,
            bits_count = bytes_count << 3,
            words = new Uint32Array(((bytes_count + 72) >>> 6) << 4),
            i = 0,
            n = bytes.length;
          i < n;
          ++i
        ) {
          words[i >>> 2] |= bytes.charCodeAt(i) << ((3 & i) << 3)
        }

        return (
          (words[bytes_count >> 2] |= 128 << (31 & bits_count)),
          (words[words.length - 2] = bits_count),
          words
        )
      }

      var bytesToMD5 = function bytesToMD5(bytes) {
          for (
            var words = bytesToWords(bytes),
              a = 1732584193,
              b = 4023233417,
              c = 2562383102,
              d = 271733878,
              i = 0,
              ws = words.length;
            i < ws;
            i += 16
          ) {
            var AA = a,
              BB = b,
              CC = c,
              DD = d
            ;(a = FF(a, b, c, d, words[i + 0], 7, 3614090360)),
              (d = FF(d, a, b, c, words[i + 1], 12, 3905402710)),
              (c = FF(c, d, a, b, words[i + 2], 17, 606105819)),
              (b = FF(b, c, d, a, words[i + 3], 22, 3250441966)),
              (a = FF(a, b, c, d, words[i + 4], 7, 4118548399)),
              (d = FF(d, a, b, c, words[i + 5], 12, 1200080426)),
              (c = FF(c, d, a, b, words[i + 6], 17, 2821735955)),
              (b = FF(b, c, d, a, words[i + 7], 22, 4249261313)),
              (a = FF(a, b, c, d, words[i + 8], 7, 1770035416)),
              (d = FF(d, a, b, c, words[i + 9], 12, 2336552879)),
              (c = FF(c, d, a, b, words[i + 10], 17, 4294925233)),
              (b = FF(b, c, d, a, words[i + 11], 22, 2304563134)),
              (a = FF(a, b, c, d, words[i + 12], 7, 1804603682)),
              (d = FF(d, a, b, c, words[i + 13], 12, 4254626195)),
              (c = FF(c, d, a, b, words[i + 14], 17, 2792965006)),
              (a = GG(
                a,
                (b = FF(b, c, d, a, words[i + 15], 22, 1236535329)),
                c,
                d,
                words[i + 1],
                5,
                4129170786,
              )),
              (d = GG(d, a, b, c, words[i + 6], 9, 3225465664)),
              (c = GG(c, d, a, b, words[i + 11], 14, 643717713)),
              (b = GG(b, c, d, a, words[i + 0], 20, 3921069994)),
              (a = GG(a, b, c, d, words[i + 5], 5, 3593408605)),
              (d = GG(d, a, b, c, words[i + 10], 9, 38016083)),
              (c = GG(c, d, a, b, words[i + 15], 14, 3634488961)),
              (b = GG(b, c, d, a, words[i + 4], 20, 3889429448)),
              (a = GG(a, b, c, d, words[i + 9], 5, 568446438)),
              (d = GG(d, a, b, c, words[i + 14], 9, 3275163606)),
              (c = GG(c, d, a, b, words[i + 3], 14, 4107603335)),
              (b = GG(b, c, d, a, words[i + 8], 20, 1163531501)),
              (a = GG(a, b, c, d, words[i + 13], 5, 2850285829)),
              (d = GG(d, a, b, c, words[i + 2], 9, 4243563512)),
              (c = GG(c, d, a, b, words[i + 7], 14, 1735328473)),
              (a = HH(
                a,
                (b = GG(b, c, d, a, words[i + 12], 20, 2368359562)),
                c,
                d,
                words[i + 5],
                4,
                4294588738,
              )),
              (d = HH(d, a, b, c, words[i + 8], 11, 2272392833)),
              (c = HH(c, d, a, b, words[i + 11], 16, 1839030562)),
              (b = HH(b, c, d, a, words[i + 14], 23, 4259657740)),
              (a = HH(a, b, c, d, words[i + 1], 4, 2763975236)),
              (d = HH(d, a, b, c, words[i + 4], 11, 1272893353)),
              (c = HH(c, d, a, b, words[i + 7], 16, 4139469664)),
              (b = HH(b, c, d, a, words[i + 10], 23, 3200236656)),
              (a = HH(a, b, c, d, words[i + 13], 4, 681279174)),
              (d = HH(d, a, b, c, words[i + 0], 11, 3936430074)),
              (c = HH(c, d, a, b, words[i + 3], 16, 3572445317)),
              (b = HH(b, c, d, a, words[i + 6], 23, 76029189)),
              (a = HH(a, b, c, d, words[i + 9], 4, 3654602809)),
              (d = HH(d, a, b, c, words[i + 12], 11, 3873151461)),
              (c = HH(c, d, a, b, words[i + 15], 16, 530742520)),
              (a = II(
                a,
                (b = HH(b, c, d, a, words[i + 2], 23, 3299628645)),
                c,
                d,
                words[i + 0],
                6,
                4096336452,
              )),
              (d = II(d, a, b, c, words[i + 7], 10, 1126891415)),
              (c = II(c, d, a, b, words[i + 14], 15, 2878612391)),
              (b = II(b, c, d, a, words[i + 5], 21, 4237533241)),
              (a = II(a, b, c, d, words[i + 12], 6, 1700485571)),
              (d = II(d, a, b, c, words[i + 3], 10, 2399980690)),
              (c = II(c, d, a, b, words[i + 10], 15, 4293915773)),
              (b = II(b, c, d, a, words[i + 1], 21, 2240044497)),
              (a = II(a, b, c, d, words[i + 8], 6, 1873313359)),
              (d = II(d, a, b, c, words[i + 15], 10, 4264355552)),
              (c = II(c, d, a, b, words[i + 6], 15, 2734768916)),
              (b = II(b, c, d, a, words[i + 13], 21, 1309151649)),
              (a = II(a, b, c, d, words[i + 4], 6, 4149444226)),
              (d = II(d, a, b, c, words[i + 11], 10, 3174756917)),
              (c = II(c, d, a, b, words[i + 2], 15, 718787259)),
              (b = II(b, c, d, a, words[i + 9], 21, 3951481745)),
              (a = (a + AA) >>> 0),
              (b = (b + BB) >>> 0),
              (c = (c + CC) >>> 0),
              (d = (d + DD) >>> 0)
          }

          var hash_bytes = new String(
            wordToBytes(a) +
              wordToBytes(b) +
              wordToBytes(c) +
              wordToBytes(d),
          )
          return (
            (hash_bytes.toHex = function () {
              for (var hex = '', i = 0, n = hash_bytes.length; i < n; ++i) {
                hex += byteToHex(hash_bytes.charCodeAt(i))
              }

              return hex
            }),
            hash_bytes
          )
        },
        utf8toMD5 = function utf8toMD5(utf8) {
          return bytesToMD5(utf8toBytes(utf8))
        }

      function MD5(utf8) {
        return utf8toMD5(utf8).toHex()
      }

      function safeJSONParse(v) {
        var o = void 0

        try {
          o = JSON.parse(v)
        } catch (e) {}

        return o
      }

      function validateMSISDN(i) {
        //if it is empty
        if (typeof i === 'undefined' || i === '') {
          return undefined
        } //remove non digits

        i = (i + '').replace(/\D/g, '')

        if (typeof i !== 'undefined' && i.indexOf('4') === 0) {
          i = i.replace(/^4/, '324')
        }

        if (typeof i !== 'undefined' && i.indexOf('04') === 0) {
          i = i.replace(/^0/, '32')
        } //the expected length is 11 (6 numbers for subscriber and 3 for the prefix and 2 for the country)

        if (i.length !== 11) {
          return undefined
        }

        return i
      }

      // identifier 1.0
      var hasSessionStorageSupport = isSessionStorageSupported()
      var hasLocalStorageSupport = isLocalStorageSupported()
      var KEY = 'tmsmgr'
      /*
//monkey patch the clean function to NOT remove our session data
//removed to make so problems occur with the logout
if (hasSessionStorageSupport) {
let originalSessionClean = window.sessionStorage.clear;

window.sessionStorage.clear = function sessionStorageClear() {
  //store the origninal data
  let tmsdata = sessionStorage.getItem(KEY);
  originalSessionClean.call(window.sessionStorage);
  !!tmsdata && sessionStorage.setItem(KEY, tmsdata);
};
}
*/

      function TMSMGR() {
        this.init()
      }

      var TMSMGR_proto = TMSMGR.prototype
      // parameter nohash: boolean indicating if NO hashing is needed when TRUE

      TMSMGR_proto.getCustomerDetailsFromLegacyCookie = function getCustomerDetailsFromLegacyCookie() {
        var o = void 0
        var cookieValue = takeNumber(getCookie('selectedCustomerAccountId'))

        if (!!cookieValue) {
          cookieValue = cookieValue.toString()
          o = {}
          o.customerid = cookieValue
          o._origin = 'ck_sca'
          return o
        }

        return undefined
      }

      TMSMGR_proto.processCustomerObject = function processCustomerObject(
        data,
        origin,
      ) {
        // makes for a uniform object
        // enables hashing
        var out = {}
        data = data || {}
        origin = origin || 'na'
        var cid = isSHA256(data.customerid)
          ? data.customerid
          : SHA256(takeNumber(data.customerid))
        var gid = takeNumber(data.globalid)
        var ms = isMD5(data.msisdn)
          ? data.msisdn
          : MD5(validateMSISDN(takeNumber(data.msisdn))) //reset to avoid strange results

        this.customerid = this.globalid = this.msisdn = undefined

        if (!!cid) {
          this.customerid = cid
          out.customerid = cid
        }

        if (!!gid) {
          this.globalid = gid
          out.globalid = gid
        }

        if (!!ms && ms !== MD5('undefined')) {
          this.msisdn = ms
          out.msisdn = ms
        }

        this.origin = origin
        this.serialize()
        return out
      }

      TMSMGR_proto.getCustomerDetailsFromTagging = function getCustomerDetailsFromTagging(
        data,
      ) {
        var o

        if (!!data) {
          var cid = takeNumber(data.customer_id)
          var gid = takeNumber(data.gid, data.user_gid, data.user_globalid)

          if (!!cid) {
            cid = cid.toString()
            o = {}
            o.customerid = cid

            if (!!gid) {
              gid = gid.toString()
              o.globalid = gid
            }

            o._origin = 'tg_teal'
            return o
          }
        }

        return o
      } //pickx specific

      TMSMGR_proto.getCustomerDetailsFromTaggingPickx = function getCustomerDetailsFromTaggingPickx(
        data,
      ) {
        var o

        if (!!data && !!data.user && !!data.user.customerid) {
          var cid = takeNumber(data.user.customerid)

          if (!!cid) {
            o = {}
            cid = cid.toString()
            o.customerid = cid
            o._origin = 'tg_pickx'
          }
        }

        if (!!data && !!data.user && !!data.user.globalid) {
          var gid = takeNumber(data.user.globalid)

          if (!!gid) {
            o = !!o ? o : {}
            gid = gid.toString()
            o.globalid = gid
            o._origin = 'tg_pickx'
          }
        }

        return o
      } // webshop only

      TMSMGR_proto.getCustomerDetailsFromTaggingWebshop = function getCustomerDetailsFromTaggingWebshop(
        data,
      ) {
        var o

        if (!!data && !!data.customer_id) {
          var cid = takeNumber(data.customer_id)

          if (!!cid) {
            cid = cid.toString()
            o = {}
            o.customerid = cid
            var gid = takeNumber(data.user_gid)

            if (!!gid) {
              gid = gid.toString()
              o.globalid = gid
            }

            o._origin = 'tg_ws'
            return o
          }
        }

        return o
      } // web order completion only

      TMSMGR_proto.getCustomerDetailsFromTaggingWOC = function getCustomerDetailsFromTaggingWOC(
        data,
      ) {
        var o

        if (!!data && !!data.customer_id) {
          var cid = takeNumber(data.customer_id)

          if (!!cid) {
            cid = cid.toString()
            o = {}
            o.customerid = cid
            o._origin = 'tg_woc'
            return o
          }
        }

        return o
      } //extract the customer details from sessionstorage
      //only for non smoothaccess/ ebill AND when active session AND when not opened a new tab :-(

      TMSMGR_proto.getCustomerDetailsFromBrowserStorageProximus = function getCustomerDetailsFromBrowserStorageProximus() {
        var o = undefined

        if (
          !!hasSessionStorageSupport &&
          !!window.sessionStorage &&
          !!window.sessionStorage.getItem &&
          typeof window.sessionStorage.getItem == 'function'
        ) {
          var details = safeJSONParse(
            window.sessionStorage.getItem('customerAccount'),
          )

          if (!!details) {
            var gid = takeNumber(details.globalId)
            var cid = takeNumber([details.cdbIds, details.customerId])
            var msisdn = takeNumber(details.mobile)

            if (!!cid) {
              o = {} //allways have a string

              cid = cid.toString()
              o.customerid = cid
              o._origin = 'px_ss_ca'

              if (!!gid) {
                o.globalid = gid.toString()
              } // msisdn related info

              if (!!msisdn) {
                msisdn = validateMSISDN(msisdn)

                if (!!msisdn) {
                  msisdn = msisdn.toString()
                  o.msisdn = msisdn
                }
              }
            }
          }
        }

        return o
      } // get the customer id and segment data from the sessionStorage
      //only for smoothaccess/mybill context

      TMSMGR_proto.getCustomerDetailsFromBrowserStorageMyBill = function getCustomerDetailsFromBrowserStorageMyBill() {
        var o = undefined

        if (
          !!hasSessionStorageSupport &&
          !!window.sessionStorage &&
          !!window.sessionStorage.getItem &&
          typeof window.sessionStorage.getItem == 'function'
        ) {
          var details = safeJSONParse(
            window.sessionStorage.getItem('authentication'),
          )

          if (!!details) {
            //only the customer id can be fetched here
            if (!!details.cid) {
              var cid = takeNumber(details.cid) //only retain when it is a numeric value

              if (!!cid) {
                o = {} // always convert to string

                cid = cid.toString()
                o.customerid = cid
                o._origin = 'mpx_ss_aut'
              }
            }
          }
        }

        return o
      } //retrieve the details from webshop browser storage

      TMSMGR_proto.getCustomerDetailsFromBrowserStorageWebshop = function getCustomerDetailsFromBrowserStorageWebshop() {
        var o = undefined

        if (
          !!hasLocalStorageSupport &&
          !!window.localStorage &&
          !!window.localStorage.getItem &&
          typeof window.localStorage.getItem == 'function' &&
          document.location.href
            .toLowerCase()
            .indexOf('proximus.be/webshop/') > -1
        ) {
          var details = safeJSONParse(
            window.localStorage.getItem('x-shopping-cart') ||
              window.localStorage.getItem('analytics-thank-you-OC-cart'),
          )

          if (!!details && details.customer) {
            var cid = takeNumber(details.customer.cdbId)
            var gid = takeNumber(details.customer.globalId)
            var msisdn = takeNumber(details.customer.contactNumber)

            if (!!cid) {
              o = {} // always convert to string

              cid = cid.toString()
              o.customerid = cid
              o._origin = 'ws_ls_oc'

              if (!!gid) {
                gid = gid.toString()
                o.globalid = gid
              }

              if (!!msisdn) {
                msisdn = validateMSISDN(msisdn)

                if (!!msisdn) {
                  o.msisdn = msisdn
                }
              }
            }
          }
        }

        return o
      } // get the data from the tms cookie

      TMSMGR_proto.getCustomerDataInCookie = function getCustomerDataInCookie() {
        var o = {}
        var ck = getCookie(KEY)
        !!ck && (ck = ck.split('|'))

        if (!!ck && ck.length > 1) {
          var cid = ck[0]
          var gid = ck[1]
          var msisdn = ck[2]
          !!cid && (cid = cid.toString())
          !!cid &&
            (cid == 'na' ||
              cid == 'undefined' ||
              cid == SHA256('na') ||
              cid == SHA256('undefined')) &&
            (cid = undefined)
          !!gid && (gid = gid.toString())
          !!gid && (gid == 'na' || gid == 'undefined') && (gid = undefined)
          !!msisdn && (msisdn = msisdn.toString())
          !!msisdn &&
            (msisdn == 'na' ||
              msisdn == 'undefined' ||
              msisdn == MD5('na') ||
              msisdn == MD5('undefined')) &&
            (msisdn = undefined)

          if (!!cid) {
            o.customerid = cid
          }

          if (!!gid) {
            o.globalid = gid
          }

          if (!!msisdn) {
            o.msisdn = msisdn
          }

          o = this.processCustomerObject(o, 'tmscookie')
        }

        return !isEmptyObject(o) ? o : undefined
      }

      TMSMGR_proto.init = function init() {
        this.running = false // this.removeOldData();

        this.startIdentification()
      }

      TMSMGR_proto.getAuthentificationStatus = getAuthentificationStatus

      TMSMGR_proto.readLocalData = function readLocalData(data) {
        data = data || {} //check for smoothaccess first

        var mybill = this.getCustomerDetailsFromBrowserStorageMyBill()

        if (!!mybill && !!mybill.customerid) {
          return this.processCustomerObject(mybill, 'browserstoragemybill')
        } // proximus.be and myproximus storage (not smoothauthentication)

        var proxi = this.getCustomerDetailsFromBrowserStorageProximus()

        if (!!proxi && !!proxi.customerid) {
          return this.processCustomerObject(proxi, 'browserstorageproximus')
        } //check webshop next

        var webshop = this.getCustomerDetailsFromBrowserStorageWebshop()

        if (!!webshop && !!webshop.customerid) {
          return this.processCustomerObject(
            webshop,
            'browserstoragewebshop',
          )
        }

        var url = document.location.href.toLowerCase() // Webshop specific

        if (
          url.indexOf('proximus.be/webshop') > -1 &&
          url.indexOf('/login') < 0
        ) {
          var ws = this.getCustomerDetailsFromTaggingWebshop(data)

          if (!!ws && !!ws.customerid) {
            return this.processCustomerObject(ws, 'taggingwebshop')
          }
        } // WOC specific

        if (
          url.indexOf('/order-completion') > -1 &&
          url.indexOf('/login') < 0
        ) {
          var woc = this.getCustomerDetailsFromTaggingWOC(data)

          if (!!woc && !!woc.customerid) {
            return this.processCustomerObject(woc, 'taggingwoc')
          }
        } // for Pickx, only the global id is set for the moment...

        if (
          url.indexOf('proximus.be/pickx') > -1 &&
          url.indexOf('/login') < 0
        ) {
          var pickx = this.getCustomerDetailsFromTaggingPickx(data) //get the stored data as well to verify

          var stored = this.getCustomerDataInCookie() //compare the stored data to see if it is the same user

          if (
            !!pickx &&
            !!stored &&
            pickx.globalid &&
            stored.globalid &&
            pickx.globalid == stored.globalid
          ) {
            //both values are the same so return everything
            return this.processCustomerObject(stored, 'pickx+stored')
          } else if (!!pickx && !!!stored) {
            //if there is pickx data but nothing stored
            //store these values to have a maximum of data
            // do not override the stored data here since the stored data might be needed later in other pages(non pickx)
            return this.processCustomerObject(pickx, 'pickxpartial')
          }
        }

        var tck = this.getCustomerDataInCookie()

        if (!!tck && !!tck.customerid) {
          return this.processCustomerObject(tck, 'tmscookie')
        }

        var tg = this.getCustomerDetailsFromTagging(data)

        if (!!tg && !!tg.customerid) {
          return this.processCustomerObject(tg, 'tagging')
        }

        var legacy = this.getCustomerDetailsFromLegacyCookie()

        if (!!legacy && !!legacy.customerid) {
          return this.processCustomerObject(legacy, 'legacycookie')
        }
      }

      TMSMGR_proto.getBDAY = function getBDAY(i) {
        return undefined
      }

      TMSMGR_proto.extractCustomerData = function extractCustomerData(
        data,
      ) {
        var customerData = {}

        if (!!data) {
          if (!!data.globalId) {
            customerData.globalid = data.globalId
          }

          if (!!data.mobile) {
            var msisdn = validateMSISDN(data.mobile)
            !!msisdn && (customerData.msisdn = msisdn)
          }

          if (!!data.birthDate) {
            var bday = data.birthDate
            !!bday && (customerData.age = bday)
          }

          if (
            !!data._embedded &&
            data._embedded.hasOwnProperty('us:fls-default-customer') &&
            !!data._embedded['us:fls-default-customer'].customerId
          ) {
            customerData.customerid =
              data._embedded['us:fls-default-customer'].customerId + ''
            return customerData
          }

          if (
            !!data._embedded &&
            data._embedded.hasOwnProperty('us:mcs-default-customer') &&
            !!data._embedded['us:mcs-default-customer'].customerId
          ) {
            customerData.customerid =
              data._embedded['us:mcs-default-customer'].customerId + ''
            return customerData
          }
        }

        return !!customerData && !isEmptyObject(customerData)
          ? customerData
          : undefined
      }

      TMSMGR_proto.getSessionDataFromSS = function getSessionDataFromSS() {
        var data = hasSessionStorageSupport
          ? safeJSONParse(sessionStorage.getItem(KEY))
          : undefined //console.log('getSessionDataFromSS', data);

        if (!!data && !isEmptyObject(data)) {
          return this.processCustomerObject(data, 'microservicecache')
        }

        return undefined
      }

      TMSMGR_proto.setSessionDataToSS = function setSessionDataToSS(data) {
        if (hasSessionStorageSupport) {
          sessionStorage.setItem(KEY, JSON.stringify(data))
        }
      }

      TMSMGR_proto.getSessionData = function getSessionData() {
        if (!!this.running) {
          return true
        }

        this.running = true
        this.remote = false
        var that = this //contacting the micro service for the actual data
        //there is no session stored yet
        //get the details from th micro service

        var SERVICE_USER_URL = '/rest/user/user' //var SERVICE_USER_URL = '/';
        //header is important to get additional info :-)

        fetch(SERVICE_USER_URL, {
          headers: {
            accept: 'application/vnd.pxs.user.v2+json',
          },
        })
          .then(function (response) {
            if (!response.ok) {
              throw new Error('Response is not ok')
            }

            return response.text()
          })
          .then(function (text) {
            try {
              var data = JSON.parse(text)
              return data
            } catch (e) {
              throw new Error('Response is no JSON')
            }
          })
          .then(function (data) {
            if (!!data) {
              var customerData = that.extractCustomerData(data) // console.log('microservice customerData', customerData);

              if (!!customerData) {
                var processed = that.processCustomerObject(
                  customerData,
                  'microservice',
                ) // console.log('prpocressed', processed);

                that.setSessionDataToSS(processed)
                that.remote = processed
                return Promise.resolve(processed)
              }
            }

            throw new Error('No data found...')
          })
          ['catch'](function (error) {
            //console.warn('Error:', error);
          })
          .then(function (data) {
            // console.log('getSessiondata request is done', that, data);
            that.running = false
            that.serialize()
          })
      }

      TMSMGR_proto.serialize = function serialize() {
        var ids = [
          this.customerid || 'na',
          this.globalid || 'na',
          this.msisdn || 'na',
        ]
        setCookie(KEY, ids.join('|'), 365)
      }

      TMSMGR_proto.removeOldData = function removeOldData() {
        setCookie('tmsids', null, -1)
      }

      TMSMGR_proto.resetData = function resetData() {
        this.customerid = this.globalid = this.msisdn = this.origin = undefined
      }

      TMSMGR_proto.startIdentification = TMSMGR_proto.update = function startIdentification() {
        this.resetData()
        var auth = this.getAuthentificationStatus()

        if (!!auth) {
          this.authenticated = auth.authenticated
          this.loggedIn = auth.loggedIn
          this.status = auth.status
        }

        if (this.remote && !isEmptyObject(this.remote)) {
          // console.log('startIdentification, remote data from memory');
          //already have response data for this page load in memory
          //save the memory object to SS to be sure
          this.setSessionDataToSS(this.remote) //use it

          return this.processCustomerObject(
            this.remote,
            'microservicememory',
          )
        }

        if (this.loggedIn) {
          //console.log('startIdentification, logged in');
          var session = this.getSessionDataFromSS()

          if (!!session) {
            // console.log('startIdentification, remote data from ss', JSON.stringify(this, null, 2));
            return this.processCustomerObject(session, 'microservicecache')
          } else {
            // console.log('startIdentification, logged in getSessionData', JSON.stringify(this, null, 2));
            this.getSessionData()
            var cookiedata = this.getCustomerDataInCookie()

            if (!!!cookiedata || isEmptyObject(cookiedata)) {
              // console.log( 'startIdentification, logged in getSessionData ->local data', JSON.stringify(this, null, 2) );
              return this.readLocalData()
            } else {
              // console.log('startIdentification, logged in getSessionData ->cookiedata', JSON.stringify(this, null, 2) );
              return this.processCustomerObject(cookiedata, 'cookiedata')
            }
          }
        } else {
          //console.log('startIdentification, not logged in');
          var _session = this.getSessionDataFromSS()

          if (!!_session) {
            return this.processCustomerObject(_session, 'microservicecache')
          }

          this.readLocalData() //console.log('startIdentification, not logged in after loacaldata',  JSON.stringify(this, null, 2) );
        }

        return this
      }

      var tmsmgr = new TMSMGR()

      //identify.update();

      window._tmsmgr = tmsmgr
    })()
    // End.identify 1.0.0
  })
  _satellite['_runScript8'](function (event, target, Promise) {
    ;(function () {
      //Marketing Channel detection

      //check which TMS is active now to see what functions we have at our disposal
      function isLaunch() {
        if (!!window._satellite && !!window._satellite.buildInfo) {
          return true
        }
        return false
      }
      function encodeCookie(ck) {
        return encodeURIComponent(ck)
      }
      function decodeCookie(ck) {
        return decodeURIComponent(ck)
      }
      function getCookie(a) {
        var b = document.cookie.match('(^|;)\\s*' + a + '\\s*=\\s*([^;]+)')
        return b ? b.pop() : undefined
      }
      var searchEngineRules = [
        /* eslint-disable max-len */
        {
          rule: /(\.)?(google|googlesyndication|googleadservices|naver|bing|yahoo|yandex|daum|baidu|myway|ecosia|ask|dogpile|sogou|seznam|aolsvc|altavista|duckduckgo|mywebsearch|wow|webcrawler|infospace|blekko|docomo)(?=\.[a-z.]{2,5})/gi,
          valueParam: false,
        },
        /* eslint-enable */
        { rule: /(\.)?(goo\.gl)/gi, valueParam: false },
        {
          rule: /^android-app:\/\/com\.google\.android/gi,
          valueParam: false,
        },
      ]

      function MarketingChannelManager() {
        this.value = undefined
        return this
      }

      var MCM_proto = MarketingChannelManager.prototype

      MCM_proto.getSearchEngine = function getSearchEngine() {
        var referrer = document.referrer + ''
        if (!!!referrer) {
          return undefined
        }
        for (var index = 0; index < searchEngineRules.length; index++) {
          var rule = searchEngineRules[index].rule
          if (!!referrer.match(rule)) {
            return 'searchengine'
          }
        }
        return undefined
      }

      MCM_proto.update = function update() {
        //detect campaigns
        var url = document.location.href + ''
        url = url.toLowerCase()
        var campaign = this.getCampaign()
        if (!!campaign) {
          this.value = campaign
          this.storeCampaignCookie(campaign)
          return this.value
        }
        /*
// a search engine is not a paid channel so not overriding the last channel
var se = this.getSearchEngine();
if (!!se) {
  this.value = se;
  this.storeCampaignCookie(se);
  return this.value;
}
*/
        this.value = decodeCookie(getCookie('cidtms'))
        return this.value
      }

      function getCampaignLaunch() {
        return _satellite.getVar('Campaign')
      }

      function getCampaignTealium() {
        return _TMS_.p.createCampaign()
      }
      function getURLDomain(a, b, c) {
        b = a.split('.')
        c = /\.co\.|\.com\.|\.org\.|\.edu\.|\.net\.|\.asn\./.test(a) ? 3 : 2
        return b.splice(b.length - c, c).join('.')
      }
      function setCookie(name, value, expires, dom) {
        var ck = name + '=' + value

        var maxAge = 30 * 24 * 60 * 60 // 30 days in milliseconds
        ck += '; max-age=' + maxAge
        dom = '.' + getURLDomain(document.domain)

        ck += '; domain=' + dom
        ck += '; path=/'
        document.cookie = ck
        return ck
      }

      function storeCampaignCookie(value) {
        value = encodeCookie(value)
        setCookie('cidtms', value)
      }
      MCM_proto.storeCampaignCookie = storeCampaignCookie
      if (isLaunch()) {
        MCM_proto.getCampaign = getCampaignLaunch
      } else {
        MCM_proto.getCampaign = getCampaignTealium
      }

      //this will store , in a cookie, the last channel interacted with in the last 30 days
      //every new channel will prolonge that time window and replace the value with the last channel
      // with the exception of direct and self referral/session refreshed

      var MCM = new MarketingChannelManager()
      window._MCM = MCM
      MCM.update()
    })()
  })
  _satellite['_runScript7'](function (event, target, Promise) {
    ;(function () {
      var env = _satellite.getVar('Adobe Launch Environment')

      var pipeline = []
      function PxDatalayer() {
        var arr = []
        if (Array.isArray(arguments[0])) {
          arr.or = arr.concat(arguments[0])
        }
        arr.__proto__ = PxDatalayer.prototype
        /* disable since the issue is fixed in prod 10/06
  if(!!env && env != 'development' && env !='staging'){
    Object.defineProperty(arr,"push",{
        set:function(v){console.warn('do not monkey patch the push method!!!');
        },
        get: function () {
          return PxDatalayer.prototype.push;
        }
    });
  }
  */

        return arr
      }
      PxDatalayer.prototype = new Array()
      PxDatalayer.prototype.start = function () {}
      PxDatalayer.prototype.use = function (fn) {
        if (typeof fn == 'function') {
          pipeline.push(fn)
        }
        return this
      }
      PxDatalayer.prototype.emit = function (type, data) {
        var that = this
        var tmp = undefined
        pipeline.forEach(function (fn) {
          var arg = tmp || data
          var xtmp = fn.call(that, arg)
          !!xtmp && (tmp = xtmp)
        })
        return this
      }
      PxDatalayer.prototype.globalData = {}
      PxDatalayer.prototype.q = []
      var p = PxDatalayer.prototype.push
      PxDatalayer.prototype.push = function (data) {
        if (!!this.or && this.or.length > 0) {
          var ele = false
          while ((ele = this.or.shift())) {
            if (!!ele) {
              this.emit('push', ele)
              p.apply(this, [ele])
            }
          }
        } else {
          delete this.or
        }
        this.emit('push', data)
        p.apply(this, arguments)
        return this
      }

      window.PxDatalayer = PxDatalayer
      var odl = window.pxdatalayer || []
      var pxdatalayer = new PxDatalayer(odl)
      //prettier-ignore
      function safeJSONParse(v){var o=void 0;try{o=JSON.parse(v)}catch(e){}return o}
      //prettier-ignore
      function isJSONText(v){return!!("string"==typeof v&&v.indexOf("{")>-1&&/^[\[|\{](\s|.*|\w)*[\]|}]$/.test(v))}
      //prettier-ignore
      function ObjectIsElement(obj){var IsElem=!0;return null==obj?IsElem=!1:"object"!=typeof obj.appendChild&&"function"!=typeof obj.appendChild?IsElem=!1:-1==(obj.appendChild+"").replace(/[\r\n\t\b\f\v\xC2\xA0\x00-\x1F\x7F-\x9F ]/gi,"").search(/\{\[NativeCode]}$/i)?IsElem=!1:1!=obj.nodeType&&(IsElem=!1),IsElem}
      // correctly parse values
      function jsonReplacer(k, v) {
        if (!!v && isJSONText(v)) {
          return safeJSONParse(v)
        }
        if (!!v && ObjectIsElement(v)) {
          return getClickData(v) || 'dom node'
        }
        return v
      }
      //make a 'copy' of the input and transform any json values
      function transformJSONValues(o) {
        var output
        var out = JSON.stringify(o, jsonReplacer)
        if (!!out) {
          output = safeJSONParse(out)
          !!!output && (output = o)
        } else {
          output = o
        }
        return output
      }
      pxdatalayer.use(function (e) {
        var e = transformJSONValues(e)
        return e
      })
      //enrich with customer details
      pxdatalayer.use(function (e) {
        try {
          var custDetails = window.__.customer.getCustomerdetails(e)
          if (custDetails && !!custDetails.customeridHash) {
            e.customer = e.customer || {}
            e.customer.idHashed = custDetails.customeridHash
            if (!!custDetails.customerid) {
              e.customer.id = custDetails.customerid
            }
            e._cust = custDetails
          }
          if (custDetails && !!custDetails.globalid) {
            e.user = e.user || {}
            e.user.globalid = custDetails.globalid
          }
          if (custDetails && !!custDetails.msisdnHash) {
            e.user = e.user || {}
            e.user.msisdnHash = custDetails.msisdnHash
          }
        } catch (error) {}

        return e
      })
      //enrich with new customer details
      pxdatalayer.use(function (e) {
        if (window._tmsmgr) {
          window._tmsmgr.update()
          e.authenticationstatus = window._tmsmgr.status || 'unidentified'
          e.identifier = [
            window._tmsmgr.customerid,
            window._tmsmgr.globalid,
            window._tmsmgr.msisdn,
          ].join('|')
          e.identifier = e.identifier == '||' ? undefined : e.identifier
        }

        return e
      })
      pxdatalayer.use(function (e) {
        var data = []
        if (
          !!e &&
          !!e.bundled &&
          e.bundled.products &&
          e.bundled.products.length > 0
        ) {
          data = __.parseProducts(e.bundled.products)
        } else if (
          !!e &&
          !!e.bundled_products &&
          e.bundled_products.length > 0
        ) {
          data = __.parseProducts(e.bundled_products)
        } else if (!!e && !!e.product && !!e.product.length > 0) {
          if (!!e.product[0] && !!!e.product[0].processed) {
            data = __.parseProducts(e.product)
            delete e.product
          }
        } else if (!!e && !!e.products && e.products.length > 0) {
          if (!!e.products[0] && !!!e.products[0].processed) {
            //this is unparsed product data
            data = __.parseProducts(e.products)
          } else {
            //this data has been processed
            data = e.products
          }
        }
        if (data.length > 0) {
          this.globalData['products'] = data
          e.products = data
        } else {
          if (!!this.globalData && !!this.globalData['products']) {
            e.products = this.globalData['products'] || data
          } else {
            e.products = data
          }
        }
        return e
      })

      pxdatalayer.use(function (e) {
        if (!!e && !!!e.event) {
          //workaround for missing event in mypx reskin
          if (!!e.action && !!e.action.name) {
            var type = !!e.button ? 'button' : 'link'
            e.event = type + '-click'
          } else if (e.event == 'page_view') {
            e.event = 'page-impression'
            _satellite.logger.warn(
              'page_view event detected while it should be page-impression',
            )
          } else {
            e.event = 'internal-event'
          }
        }
      })
      pxdatalayer.use(function (e) {
        //card-scriptloaded|binkies interactive|apple – iphone 12 64gb red	6206
        //exlude binkies events...
        if (
          !!e &&
          !!e.card &&
          !!e.card.zone &&
          e.card.zone == 'binkies interactive'
        ) {
          _satellite.logger.log('blocking binkies events', e)
          e.event = 'abort'
          return e
        }
      })
      pxdatalayer.use(function (e) {
        function checkCockpit() {
          //for debugging
          var debug = window.location.href.indexOf('cockpit=true') > -1
          //search for <meta property="px:app_context" content="dof"/>
          var tag = document.querySelector(
            'meta[property="px:app_context"]',
          )
          if (tag) {
            var value = tag.getAttribute('content')
            !!value && (value = value.toLowerCase())
            !!value && (value = value.match(/(dof|hot|arc|partners)/gi))
            !!value && (value = value.join(''))
            if (!!value) {
              return value
            }
          }
          if (!!debug) {
            return true
          }
          return undefined
        }
        if (!!e && !!e.event && e.event != 'abort') {
          var c = JSON.parse(JSON.stringify(e))
          if (!!!checkCockpit()) {
            c.eventname = c.event + ''
            c.event = 'datalayer-push'
            this.q.push(c)
          } else {
            var data = {
              event: 'iframe-push',
              event_context: 'launch',
              iframe: c,
            }
            data = JSON.stringify(data)
            //check if the page is visible, we do not want to send stuff when it is not visible
            if (
              !!document &&
              !!document.body &&
              !!document.body.offsetHeight
            ) {
              !!window.top &&
                window.top != window &&
                window.top.postMessage('tms$' + data, '*')
            }
          }
        }
      })

      /*
pxdatalayer.use(function(e) {
function getPage(){
var page = window.pxdatalayer && window.pxdatalayer.q && window.pxdatalayer.q.computedState && window.pxdatalayer.q.computedState.page ? window.pxdatalayer.q.computedState.page : {};
page.url =page.url || document.location.href;
return page
}
this.counters = this.counters || {};
if(!this.counters['pageviews']){ 
    this.counters['pageviews'] = new __.SW({name:'HELLO',getPage:getPage});
    this.counters['pageviews'].start();
}
if(!!e && !!e.event && e.event == 'page-impression'){
    var duration = this.counters['pageviews'].stop();
    console.log('page-impression details',duration,e);
     this.counters['pageviews'].start();
     e.timeSincePreviousPageView = duration.elapsed;
}
return e;

});
*/
      pxdatalayer.start()

      if (
        'defineProperty' in Object &&
        'getOwnPropertyDescriptor' in Object &&
        !!Object.getOwnPropertyDescriptor(window, 'pxdatalayer') &&
        !!Object.getOwnPropertyDescriptor(window, 'pxdatalayer')
          .configurable
      ) {
        Object.defineProperty(window, 'pxdatalayer', {
          configurable: true,
          get: function () {
            return pxdatalayer
          },
          set: function () {
            console.error(
              'Tag Management: Massive meltdown! Please do not redefine the pxdatalayer variable. pxdatalayer=[] should be added in the head before the script include 🙃',
            )
          },
        })
      } else {
        window.pxdatalayer = pxdatalayer
      }
    })()
  })
  _satellite['_runScript6'](function (event, target, Promise) {
    window.utag_data = window.utag_data || {}
    ;(function () {
      //utils
      var _ = {}
      ;(function (root) {
        function dlv(obj, key, def, p, undef) {
          key = key.split ? key.split('.') : key
          for (p = 0; p < key.length; p++) {
            obj = obj ? obj[key[p]] : undef
          }
          return obj === undef ? def : obj
        }

        function getComponentPart(component, part) {
          var subparts = part.split('|')
          for (var idx = 0; idx < subparts.length; idx++) {
            var val = dlv(component, subparts[idx])
            if (!!val) {
              return val
            }
          }
          return undefined
        }

        function composeComponentDetail(event, parts) {
          var data = !!event && !!event.detail ? event.detail : undefined
          if (!!data && !!parts && parts.length > 0) {
            var composed = []
            var valid = false
            for (var index = 0; index < parts.length; index++) {
              var part = parts[index]
              var partvalue = getComponentPart(data, part)
              if (!!partvalue) {
                valid = true
                composed.push(partvalue)
              } else {
                composed.push('na')
              }
            }
            if (valid) {
              return composed.join('|')
            }
          }
          return undefined
        }

        root.composeComponentDetail = composeComponentDetail
      })(_)

      //fontDetection
      ;(function (root) {
        var detectFont = (function () {
          // is this a browser that supports the native way of checking?
          function supportsNativeAPI() {
            if (
              !!document &&
              !!document.fonts &&
              !!document.fonts.check &&
              typeof document.fonts.check == 'function'
            ) {
              return true
            }
            return false
          }
          if (supportsNativeAPI()) {
            return function detect(font) {
              if (!!!font) {
                return false
              }
              return !!document.fonts.check('12px ' + font)
            }
          } else {
            var canvas = document.createElement('canvas')
            var context = canvas.getContext('2d')
            // the text whose final pixel size I want to measure
            var text = Array(100).join('wmlli')
            // specifying the baseline font
            context.font = '72px monospace'
            // checking the size of the baseline text
            var baselineSize = context.measureText(text).width
            return function detect(fontName) {
              if (!!!fontName) {
                return false
              }
              // specifying the font whose existence we want to check
              context.font = "72px '" + fontName + "', monospace"
              // checking the size of the font we want to check
              var newSize = context.measureText(text).width
              return newSize !== baselineSize
            }
          }
        })()
        root.detectFont = detectFont
      })(_)

      //detect user agent types for in app browsing using the useragent
      ;(function (root) {
        root.detectUserAgent = detectUserAgent

        function detectUserAgent($) {
          //get the browsers user agent
          var ua =
            window.navigator.userAgent ||
            window.navigator.vendor ||
            window.opera
          if (!!!ua) {
            return undefined //just bail if the useragent is empty (should not happen though)
          }
          ua = ua + '' //make sure it is string
          var inapp = false //default
          var detect = {
            //all detection rules here, return value of each function is either a boolean or a string indicating what it is
            proximus: function (ua) {
              var m = ua.match(/((?:MyPxApp.|evmsapp.|Kiosk.)\w*)/i) || []
              m = !!m[1] ? m[1] : false
              if (m) {
                return m
              }
              return false
            },

            facebook: function (ua) {
              return ua
                .toLowerCase()
                .match(
                  /((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i,
                )
              //return (ua.toLowerCase().indexOf("fban") > -1) || (ua.indexOf("fbav") > -1);
            },
            twitter: function (ua) {
              return ua.toLowerCase().indexOf('twitter') > -1
            },
            pinterest: function (ua) {
              return ua.toLowerCase().indexOf('pinterest/') > -1
            },
            instagram: function (ua) {
              return !!ua
                .toLowerCase()
                .match(/(chromium|instagram)[\/ ]([-\w\.]+)/i)
            },

            snapchat: function (ua) {
              return ua.toLowerCase().indexOf('snapchat') > -1
            },
            linkedin: function (ua) {
              return ua.toLowerCase().indexOf('linkedinapp') > -1
            },
            'bing search app': function (ua) {
              return ua.toLowerCase().indexOf('bingweb/') > -1
            },
            'google search app': function (ua) {
              return ua.toLowerCase().indexOf('gsa/') > -1
            },
            cypress: function (ua) {
              return ua.toLowerCase().indexOf(' cypress') > -1
            },
            itcam: function (ua) {
              return ua.toLowerCase().indexOf('itcam') > -1
            },
            kbc: function (ua) {
              return ua.toLowerCase().indexOf('kbc') > -1
            },
            webview: function (ua) {
              var rules = [
                // if it says it's a webview, let's go with that
                'WebView',
                // iOS webview will be the same as safari but missing "Safari"
                '(iPhone|iPod|iPad)(?!.*Safari)',
                // Android Lollipop and Above: webview will be the same as native but it will contain "wv"
                // Android KitKat to lollipop webview will put {version}.0.0.0
                'Android.*(wv|.0.0.0)',
                // old chrome android webview agent
                'Linux; U; Android',
              ]
              var webviewRegExp = new RegExp(
                '(' + rules.join('|') + ')',
                'ig',
              )

              return !!ua.match(webviewRegExp)
            },
          }
          for (var rule in detect) {
            var r = detect[rule](ua) //execute the rule
            if (!!r) {
              //if it is not false --> true or string
              if (typeof r == 'string') {
                //when it is a string then use the value of the string
                inapp = r
              } else {
                inapp = rule //otherwise use the key of the function to indicate what useragent it is
              }
              break
            }
          }

          if (!!inapp) {
            return inapp
          }
          return undefined
        }
      })(_)

      ;(function (root) {
        function getData() {
          return {
            url: document.location.href,
          }
        }
        function Stopwatch(opt) {
          this.options = opt || {}
          this.options.autoStart = this.options.autoStart || true
          this.name = this.options.name || 'tms-generic'
          this.pauseDuration = 0
          this.startTime = Date.now()
          this.hasPrevious = false
          this.getPage =
            !!this.options.getPage &&
            typeof this.options.getPage == 'function'
              ? this.options.getPage
              : getData
          this.restore()
          !!this.options.autoStart && this.start()
          return this
        }
        var pr = Stopwatch.prototype
        pr.toJSON = function toJSON() {
          return {
            startTime: this.startTime,
            pauseDuration: this.pauseDuration,
            page: this.page,
            elapsed: this.getElapsed(),
          }
        }
        pr.toString = function toString() {
          return JSON.stringify(this.toJSON())
        }
        pr.save = function save() {
          sessionStorage.setItem(this.name, this.toString())
        }
        pr.remove = function remove() {
          sessionStorage.removeItem(this.name)
        }
        pr.restore = function restore() {
          var d = sessionStorage.getItem(this.name)
          if (!!d) {
            try {
              d = JSON.parse(d)
              !!d.pauseDuration && (this.pauseDuration += d.pauseDuration)
              !!d.startTime && (this.startTime = d.startTime)
              this.hasPrevious = true
              !!d.page && (this.page = d.page)
              !!!d.page && (this.page = this.getPage())
            } catch (error) {}
          }
          return this
        }

        pr.start = function start() {
          this.startTime = !!this.startTime ? this.startTime : Date.now()
          this.pauseDuration = !!this.pauseDuration ? this.pauseDuration : 0
          this.page = this.getPage()
          document.addEventListener('visibilitychange', this, {
            passive: true,
          })
          this.handleEvent()
          this.save()
          return this
        }
        pr.stop = function stop() {
          var out = this.hasPrevious ? this.toJSON() : false
          this.startTime = Date.now()
          this.pauseDuration = 0
          this.hasPrevious = true
          delete this.page
          document.removeEventListener('visibilitychange', this, {
            passive: true,
          })
          this.remove()
          return out
        }
        pr.pause = function pauze() {
          this.pauseStartTime = this.pauseStartTime || Date.now()
          this.save()
          return this
        }
        pr.resume = function resume() {
          if (!!this.pauseStartTime) {
            this.pauseDuration += Date.now() - this.pauseStartTime
            this.pauseStartTime = 0
          }
          this.save()
          return this
        }

        pr.getElapsed = function read() {
          return Date.now() - this.startTime - this.pauseDuration
        }

        pr.handleEvent = function handleEvent(e) {
          if (document.visibilityState === 'hidden') {
            this.pause()
          } else if (document.visibilityState === 'visible') {
            this.resume()
          }
        }

        root.SW = Stopwatch
      })(_)

      ;(function (root) {
        root.convertWebshopViewsToEvent = (function () {
          function deepGet(obj, key, def, p, undef) {
            key = key.split ? key.split('.') : key
            for (p = 0; p < key.length; p++) {
              obj = obj ? obj[key[p]] : undef
            }
            return obj === undef ? def : obj
          }
          function convertWebshopViewsToEvent(data) {
            var isLoadEvent = deepGet(data, 'event', 'na')
            isLoadEvent = isLoadEvent == 'element_load'
            var bprod = deepGet(data, 'bundled_products')
            var previousdata =
              window.pxdatalayer &&
              window.pxdatalayer.q &&
              !!window.pxdatalayer.q.computedState
                ? window.pxdatalayer.q.computedState
                : {}
            // shoppingcart open, this is the popup that is showing your cart content
            if (
              isLoadEvent &&
              deepGet(data, 'page_category_l3') == 'webshop_shoppingcart' &&
              deepGet(data, 'page_category_l4') == 'open'
            ) {
              var o = {
                event: 'popup-impression',
                popup: {
                  zone: deepGet(previousdata, 'page.category.l3', 'na'),
                  name: deepGet(data, 'page_usecase'),
                },
              }
              o.eventstring = [
                'cart-impression',
                o.popup.zone,
                o.popup.name,
              ].join(':')
              !!bprod && (o.bundled_products = bprod)
              // console.log('shoppingcart open event data after transform',JSON.stringify(o,null,2));
              return o
            }

            //email cart dialog, the popup that is shown after clicking the send by email button
            if (
              isLoadEvent &&
              deepGet(data, 'page_category_l3') ==
                'webshop_EmailCartDialog' &&
              deepGet(data, 'page_category_l4') == 'open'
            ) {
              var o = {
                event: 'popup-impression',
                popup: {
                  zone: deepGet(previousdata, 'page.category.l3', 'na'),
                  name: deepGet(data, 'page_usecase'),
                },
              }
              o.eventstring = [o.event, o.popup.zone, o.popup.name].join(
                ':',
              )
              !!bprod && (o.bundled_products = bprod)
              // console.log('email cart open event data after transform',JSON.stringify(o,null,2));
              return o
            }
            return data
          }
          return convertWebshopViewsToEvent
        })()
      })(_)
      _.customer = (function (t) {
        'use strict'
        function r(t) {
          for (
            var r, e = t + '=', o = document.cookie.split(';'), n = 0;
            n < o.length;
            n++
          ) {
            for (var i = o[n]; ' ' == i.charAt(0); )
              i = i.substring(1, i.length)
            if (0 == i.indexOf(e)) {
              var u = i.substring(e.length, i.length)
              return (
                (r = u),
                (u = (r += '')
                  .replace(/\*/gm, '##')
                  .replace(/##/gm, ',')
                  .replace(/!/gm, ' '))
              )
            }
          }
        }
        var e = 'proximus.be',
          o = {}
        function n(t) {
          o.isArray(t) || (t = [t])
          var r = t.length
          r = r ? r + 1 : 0
          for (var e, n = t.length; r--; )
            if ((e = t[n - r]) && 1 * e > 0) return 1 * e
        }
        function i(t) {
          return (
            !!t &&
            (!o.isString(t) && o.isNumber(t) && (t = t.toString()),
            /\b[A-Fa-f0-9]{64}\b/.test(t))
          )
        }
        function u(t, r) {
          return (
            (r =
              'string' == typeof t
                ? (t = (function (t) {
                    for (
                      var r = unescape(encodeURIComponent(t)),
                        e = r.length,
                        o = 0,
                        n = [];
                      o < e;

                    )
                      n[o >> 2] =
                        (r.charCodeAt(o++) << 24) |
                        (r.charCodeAt(o++) << 16) |
                        (r.charCodeAt(o++) << 8) |
                        r.charCodeAt(o++)
                    return (n.len = e), n
                  })(t)).len
                : r || t.length << 2),
            (t[r >> 2] |= 128 << (24 - (31 & (r <<= 3)))),
            (t[15 + (((r + 64) >> 9) << 4)] = r),
            t
          )
        }
        !(function () {
          for (
            var t = 'Array Object String Date RegExp Function Boolean Number Null Undefined'.split(
                ' ',
              ),
              r = function () {
                return Object.prototype.toString.call(this).slice(8, -1)
              },
              e = t.length;
            e--;

          )
            o['is' + t[e]] = (function (t) {
              return function (e) {
                return r.call(e) === t
              }
            })(t[e])
        })()
        var a = [],
          s = []
        function c(t, r) {
          a[0] ||
            (function () {
              function t(t) {
                return (4294967296 * (t - (t >>> 0))) | 0
              }
              t: for (var r, e = 0, o = 2; e < 64; o++) {
                for (r = 2; r * r <= o; r++) if (o % r == 0) continue t
                e < 8 && (a[e] = t(Math.pow(o, 0.5))),
                  (s[e++] = t(Math.pow(o, 1 / 3)))
              }
            })()
          for (
            var e,
              o,
              n,
              i,
              c,
              g,
              d,
              l,
              m,
              f,
              v,
              S = 0,
              p = [],
              h = a[0],
              w = a[1],
              b = a[2],
              _ = a[3],
              C = a[4],
              I = a[5],
              x = a[6],
              A = a[7],
              D = u(t, r),
              O = D.length,
              y = s;
            S < O;

          ) {
            for (
              e = h, o = w, n = b, i = _, c = C, g = I, d = x, l = A, v = 0;
              v < 64;

            )
              v < 16
                ? (p[v] = D[S + v])
                : ((m = p[v - 2]),
                  (f = p[v - 15]),
                  (p[v] =
                    ((m >>> 17) ^
                      (m << 15) ^
                      (m >>> 19) ^
                      (m << 13) ^
                      (m >>> 10)) +
                    (0 | p[v - 7]) +
                    ((f >>> 7) ^
                      (f << 25) ^
                      (f >>> 18) ^
                      (f << 14) ^
                      (f >>> 3)) +
                    (0 | p[v - 16]))),
                (m =
                  (0 | p[v]) +
                  l +
                  ((c >>> 6) ^
                    (c << 26) ^
                    (c >>> 11) ^
                    (c << 21) ^
                    (c >>> 25) ^
                    (c << 7)) +
                  ((c & g) ^ (~c & d)) +
                  y[v++]),
                (f =
                  ((e >>> 2) ^
                    (e << 30) ^
                    (e >>> 13) ^
                    (e << 19) ^
                    (e >>> 22) ^
                    (e << 10)) +
                  ((e & o) ^ (e & n) ^ (o & n))),
                (l = d),
                (d = g),
                (g = c),
                (c = (i + m) | 0),
                (i = n),
                (n = o),
                (o = e),
                (e = (m + f) | 0)
            ;(h += e),
              (w += o),
              (b += n),
              (_ += i),
              (C += c),
              (I += g),
              (x += d),
              (A += l),
              (S += 16)
          }
          return [h, w, b, _, C, I, x, A]
        }
        function g(t) {
          var r = void 0
          if (t)
            return (
              !o.isString(t) && o.isNumber(t) && (t = t.toString()),
              o.isString(t) &&
                (t = t.replace(/^[ ]+/g, '').replace(/[ ]+$/g, '')),
              t &&
                o.isString(t) &&
                (r = (function (t) {
                  for (var r = t.length; r--; )
                    t[r] = ('0000000' + (t[r] >>> 0).toString(16)).slice(-8)
                  return t.join('')
                })(c(t))),
              r
            )
        }
        function d(t) {
          return /[a-fA-F0-9]{32}/.test(t)
        }
        function l(t, r, e, o, n, i, u) {
          var a = t + ((r & e) | (~r & o)) + (n >>> 0) + u
          return ((a << i) | (a >>> (32 - i))) + r
        }
        function m(t, r, e, o, n, i, u) {
          var a = t + ((r & o) | (e & ~o)) + (n >>> 0) + u
          return ((a << i) | (a >>> (32 - i))) + r
        }
        function f(t, r, e, o, n, i, u) {
          var a = t + (r ^ e ^ o) + (n >>> 0) + u
          return ((a << i) | (a >>> (32 - i))) + r
        }
        function v(t, r, e, o, n, i, u) {
          var a = t + (e ^ (r | ~o)) + (n >>> 0) + u
          return ((a << i) | (a >>> (32 - i))) + r
        }
        function S(t) {
          return String.fromCharCode(255 & t)
        }
        function p(t) {
          return S(t) + S(t >>> 8) + S(t >>> 16) + S(t >>> 24)
        }
        var h = function (t) {
            for (
              var r = (function (t) {
                  for (
                    var r = t.length,
                      e = r << 3,
                      o = new Uint32Array(((r + 72) >>> 6) << 4),
                      n = 0,
                      i = t.length;
                    n < i;
                    ++n
                  )
                    o[n >>> 2] |= t.charCodeAt(n) << ((3 & n) << 3)
                  return (
                    (o[r >> 2] |= 128 << (31 & e)), (o[o.length - 2] = e), o
                  )
                })(t),
                e = 1732584193,
                o = 4023233417,
                n = 2562383102,
                i = 271733878,
                u = 0,
                a = r.length;
              u < a;
              u += 16
            ) {
              var s = e,
                c = o,
                g = n,
                d = i
              ;(e = l(e, o, n, i, r[u + 0], 7, 3614090360)),
                (i = l(i, e, o, n, r[u + 1], 12, 3905402710)),
                (n = l(n, i, e, o, r[u + 2], 17, 606105819)),
                (o = l(o, n, i, e, r[u + 3], 22, 3250441966)),
                (e = l(e, o, n, i, r[u + 4], 7, 4118548399)),
                (i = l(i, e, o, n, r[u + 5], 12, 1200080426)),
                (n = l(n, i, e, o, r[u + 6], 17, 2821735955)),
                (o = l(o, n, i, e, r[u + 7], 22, 4249261313)),
                (e = l(e, o, n, i, r[u + 8], 7, 1770035416)),
                (i = l(i, e, o, n, r[u + 9], 12, 2336552879)),
                (n = l(n, i, e, o, r[u + 10], 17, 4294925233)),
                (o = l(o, n, i, e, r[u + 11], 22, 2304563134)),
                (e = l(e, o, n, i, r[u + 12], 7, 1804603682)),
                (i = l(i, e, o, n, r[u + 13], 12, 4254626195)),
                (n = l(n, i, e, o, r[u + 14], 17, 2792965006)),
                (e = m(
                  e,
                  (o = l(o, n, i, e, r[u + 15], 22, 1236535329)),
                  n,
                  i,
                  r[u + 1],
                  5,
                  4129170786,
                )),
                (i = m(i, e, o, n, r[u + 6], 9, 3225465664)),
                (n = m(n, i, e, o, r[u + 11], 14, 643717713)),
                (o = m(o, n, i, e, r[u + 0], 20, 3921069994)),
                (e = m(e, o, n, i, r[u + 5], 5, 3593408605)),
                (i = m(i, e, o, n, r[u + 10], 9, 38016083)),
                (n = m(n, i, e, o, r[u + 15], 14, 3634488961)),
                (o = m(o, n, i, e, r[u + 4], 20, 3889429448)),
                (e = m(e, o, n, i, r[u + 9], 5, 568446438)),
                (i = m(i, e, o, n, r[u + 14], 9, 3275163606)),
                (n = m(n, i, e, o, r[u + 3], 14, 4107603335)),
                (o = m(o, n, i, e, r[u + 8], 20, 1163531501)),
                (e = m(e, o, n, i, r[u + 13], 5, 2850285829)),
                (i = m(i, e, o, n, r[u + 2], 9, 4243563512)),
                (n = m(n, i, e, o, r[u + 7], 14, 1735328473)),
                (e = f(
                  e,
                  (o = m(o, n, i, e, r[u + 12], 20, 2368359562)),
                  n,
                  i,
                  r[u + 5],
                  4,
                  4294588738,
                )),
                (i = f(i, e, o, n, r[u + 8], 11, 2272392833)),
                (n = f(n, i, e, o, r[u + 11], 16, 1839030562)),
                (o = f(o, n, i, e, r[u + 14], 23, 4259657740)),
                (e = f(e, o, n, i, r[u + 1], 4, 2763975236)),
                (i = f(i, e, o, n, r[u + 4], 11, 1272893353)),
                (n = f(n, i, e, o, r[u + 7], 16, 4139469664)),
                (o = f(o, n, i, e, r[u + 10], 23, 3200236656)),
                (e = f(e, o, n, i, r[u + 13], 4, 681279174)),
                (i = f(i, e, o, n, r[u + 0], 11, 3936430074)),
                (n = f(n, i, e, o, r[u + 3], 16, 3572445317)),
                (o = f(o, n, i, e, r[u + 6], 23, 76029189)),
                (e = f(e, o, n, i, r[u + 9], 4, 3654602809)),
                (i = f(i, e, o, n, r[u + 12], 11, 3873151461)),
                (n = f(n, i, e, o, r[u + 15], 16, 530742520)),
                (e = v(
                  e,
                  (o = f(o, n, i, e, r[u + 2], 23, 3299628645)),
                  n,
                  i,
                  r[u + 0],
                  6,
                  4096336452,
                )),
                (i = v(i, e, o, n, r[u + 7], 10, 1126891415)),
                (n = v(n, i, e, o, r[u + 14], 15, 2878612391)),
                (o = v(o, n, i, e, r[u + 5], 21, 4237533241)),
                (e = v(e, o, n, i, r[u + 12], 6, 1700485571)),
                (i = v(i, e, o, n, r[u + 3], 10, 2399980690)),
                (n = v(n, i, e, o, r[u + 10], 15, 4293915773)),
                (o = v(o, n, i, e, r[u + 1], 21, 2240044497)),
                (e = v(e, o, n, i, r[u + 8], 6, 1873313359)),
                (i = v(i, e, o, n, r[u + 15], 10, 4264355552)),
                (n = v(n, i, e, o, r[u + 6], 15, 2734768916)),
                (o = v(o, n, i, e, r[u + 13], 21, 1309151649)),
                (e = v(e, o, n, i, r[u + 4], 6, 4149444226)),
                (i = v(i, e, o, n, r[u + 11], 10, 3174756917)),
                (n = v(n, i, e, o, r[u + 2], 15, 718787259)),
                (o = v(o, n, i, e, r[u + 9], 21, 3951481745)),
                (e = (e + s) >>> 0),
                (o = (o + c) >>> 0),
                (n = (n + g) >>> 0),
                (i = (i + d) >>> 0)
            }
            var S = new String(p(e) + p(o) + p(n) + p(i))
            return (
              (S.toHex = function () {
                for (var t = '', r = 0, e = S.length; r < e; ++r)
                  t += (256 + (255 & S.charCodeAt(r)))
                    .toString(16)
                    .substr(-2)
                return t
              }),
              S
            )
          },
          w = function (t) {
            return h(
              (function (t) {
                return unescape(encodeURIComponent(t))
              })(t),
            )
          }
        function b(t) {
          return w(t).toHex()
        }
        function _(t) {
          var r = void 0
          if (t && o.isString(t))
            try {
              r = JSON.parse(t)
            } catch (t) {}
          return r
        }
        function C() {
          try {
            var t = 'test',
              r = window.sessionStorage
            return r.setItem(t, '1'), r.removeItem(t), !0
          } catch (t) {
            return !1
          }
        }
        function I() {
          try {
            var t = 'test',
              r = window.localStorage
            return r.setItem(t, '1'), r.removeItem(t), !0
          } catch (t) {
            return !1
          }
        }
        function x(t) {
          if (
            void 0 !== t &&
            '' !== t &&
            (void 0 !== (t = (t + '').replace(/\D/g, '')) &&
              0 === t.indexOf('4') &&
              (t = t.replace(/^4/, '324')),
            void 0 !== t &&
              0 === t.indexOf('04') &&
              (t = t.replace(/^0/, '32')),
            11 === t.length)
          )
            return t
        }
        var A = C(),
          D = I()
        function O(t, r, e) {
          return (
            (r = t.split('.')),
            (e = /\.co\.|\.com\.|\.org\.|\.edu\.|\.net\.|\.asn\./.test(t)
              ? 3
              : 2),
            r.splice(r.length - e, e).join('.')
          )
        }
        var y = {
            takeNumber: n,
            isSHA256: i,
            SHA256: g,
            isMD5: d,
            MD5: b,
            safeJSONParse: _,
            isSessionStorageSupported: C,
            isLocalStorageSupported: I,
            validateMSISDN: x,
            getAuthentificationStatus: function () {
              var t = {
                  loggedIn: !1,
                  authenticated: !1,
                  status: 'unknown',
                },
                e = r('BGC_AUT_LVL'),
                o =
                  !!(e = e ? e.replace(/ /gm, '').toLowerCase() : void 0) &&
                  'aut' == e,
                n = r('BGC_AUT_LVL_FULLNAME')
              return (
                (n = n ? n.replace(/ /gm, '') : void 0),
                o && n
                  ? ((t.loggedIn = !0),
                    (t.authenticated = !0),
                    (t.status = 'authenticated - logged in'),
                    t)
                  : !!e && 'ide' == e && n
                  ? ((t.loggedIn = !1),
                    (t.authenticated = !0),
                    (t.status = 'authenticated - not logged in'),
                    t)
                  : ((t.loggedIn = !1),
                    (t.authenticated = !1),
                    (t.status = 'not authenticated'),
                    t)
              )
            },
          },
          k = O(document.domain)
        function F() {
          var t = void 0,
            e = n(r('selectedCustomerAccountId'))
          if (e)
            return (
              (e = e.toString()),
              ((t = {}).customerid = e),
              (t._origin = 'ck_sca'),
              t
            )
        }
        function L() {
          var t
          return ((t = H()) && t.customerid) ||
            ((t = j()) && t.customerid) ||
            ((t = R()) && t.customerid)
            ? t
            : void 0
        }
        function N(t) {
          return (
            t &&
              t.customerid &&
              (t.customeridHash = i(t.customerid)
                ? t.customerid
                : g(t.customerid)),
            t &&
              t.msisdn &&
              (t.msisdnHash = d(t.msisdn) ? x(t.msisdn) : b(x(t.msisdn))),
            t
          )
        }
        function T(t) {
          var r
          if (t) {
            var e = n(t.customer_id),
              o = n(t.gid, t.user_gid, t.user_globalid)
            if (e)
              return (
                (e = e.toString()),
                ((r = {}).customerid = e),
                o && ((o = o.toString()), (r.globalid = o)),
                (r._origin = 'tg_teal'),
                r
              )
          }
          return r
        }
        function B(t) {
          var r
          if (t && t.user && t.user.customerid) {
            var e = n(t.user.customerid)
            e && ((r = {}), (e = e.toString()), (r.customerid = e))
          }
          if (t && t.user && t.user.globalid) {
            var o = n(t.user.globalid)
            if (o)
              return (
                (r = r || {}),
                (o = o.toString()),
                (r.globalid = o),
                (r._origin = 'tg_pickx'),
                r
              )
          }
          return r
        }
        function M(t) {
          var r
          if (t && t.customer_id) {
            var e = n(t.customer_id)
            if (e) {
              ;(e = e.toString()), ((r = {}).customerid = e)
              var o = n(t.user_gid)
              return (
                o && ((o = o.toString()), (r.globalid = o)),
                (r._origin = 'tg_ws'),
                r
              )
            }
          }
          return r
        }
        function U(t) {
          var r
          if (t && t.customer_id) {
            var e = n(t.customer_id)
            if (e)
              return (
                (e = e.toString()),
                ((r = {}).customerid = e),
                (r._origin = 'tg_woc'),
                r
              )
          }
          return r
        }
        function j() {
          var t = void 0
          if (
            A &&
            window.sessionStorage &&
            window.sessionStorage.getItem &&
            'function' == typeof window.sessionStorage.getItem
          ) {
            var r = _(window.sessionStorage.getItem('customerAccount'))
            if (r) {
              var e = n(r.globalId),
                o = n(r.cdbIds),
                i = n(r.mobile)
              o &&
                ((t = {}),
                (o = o.toString()),
                (t.customerid = o),
                (t._origin = 'px_ss_ca'),
                e && (t.globalid = e.toString()),
                i && (i = x(i)) && ((i = i.toString()), (t.msisdn = i)))
            }
          }
          return t
        }
        function H() {
          var t = void 0
          if (
            A &&
            window.sessionStorage &&
            window.sessionStorage.getItem &&
            'function' == typeof window.sessionStorage.getItem
          ) {
            var r = _(window.sessionStorage.getItem('authentication'))
            if (r && r.cid) {
              var e = n(r.cid)
              e &&
                ((t = {}),
                (e = e.toString()),
                (t.customerid = e),
                (t._origin = 'mpx_ss_aut'))
            }
          }
          return t
        }
        function R() {
          var t = void 0
          if (
            D &&
            window.localStorage &&
            window.localStorage.getItem &&
            'function' == typeof window.localStorage.getItem &&
            document.location.href
              .toLowerCase()
              .indexOf('proximus.be/webshop/') > -1
          ) {
            var r = _(
              window.localStorage.getItem('analytics-thank-you-OC-cart'),
            )
            if (r && r.customer) {
              var e = n(r.customer.cdbId),
                o = n(r.customer.globalId),
                i = n(r.customer.contactNumber)
              e &&
                ((t = {}),
                (e = e.toString()),
                (t.customerid = e),
                (t._origin = 'ws_ls_oc'),
                o && ((o = o.toString()), (t.globalid = o)),
                i && (i = x(i)) && (t.msisdn = i))
            }
          }
          return t
        }
        function G(t) {
          var r = t.customerid || '',
            n = t.globalid || '',
            i = k
          !(function (t, r, n, i) {
            var u
            u = r
            var a =
              t +
              '=' +
              (r = (u += '')
                .replace(/^,/gm, '')
                .replace(/,$/gm, '')
                .replace(/\*/gm, ',')
                .replace(/,/gm, '##')
                .replace(/\s/gm, '!'))
            if (n && o.isNumber(n)) {
              var s = new Date()
              s.setTime(s.getTime() + 24 * n * 60 * 60 * 1e3),
                (a += '; expires=' + s.toGMTString())
            }
            ;(a += '; domain=' + (i || '.' + e)),
              (a += '; path=/'),
              (document.cookie = a)
          })('tmsids', [r, n].join('|'), 734, i)
        }
        function P() {
          var t,
            e = r('tmsids')
          if ((e && (e = e.split('|')), e && e.length > 1)) {
            var o = e[0],
              n = e[1]
            if ((o && (o = o.toString()), n && (n = n.toString()), o))
              return (
                ((t = {}).customerid = o),
                n && (t.customerid = o),
                (t._origin = 'ck_tmsids'),
                (t = N(t))
              )
          }
          return t
        }
        function W(t) {
          var r = L()
          if (r && r.customerid) return G(r), N(r)
          var e = document.location.href.toLowerCase()
          if (
            e.indexOf('proximus.be/webshop') > -1 &&
            e.indexOf('/login') < 0
          ) {
            var o = M(t)
            if (o && o.customerid) return G(o), N(o)
          }
          if (
            e.indexOf('/order-completion') > -1 &&
            e.indexOf('/login') < 0
          ) {
            var n = U(t)
            if (n && n.customerid) return G(n), N(n)
          }
          if (
            e.indexOf('proximus.be/pickx') > -1 &&
            e.indexOf('/login') < 0
          ) {
            var i = B(t),
              u = P()
            if (
              i &&
              u &&
              i.globalid &&
              u.globalid &&
              i.globalid == u.globalid
            )
              return N(u)
            if (i && !u) return N(i)
          }
          var a = P()
          if (a && a.customerid) return N(a)
          var s = T(t)
          if (s && s.customerid) return G(r), N(s)
          var c = F()
          return c && c.customerid ? N(c) : void 0
        }
        var E = {
            __proto__: null,
            getURLDomain: O,
            util: y,
            getCustomerDetailsFromLegacyCookie: F,
            getCustomerDetailsFromBrowserStorage: L,
            processCustomerObject: N,
            getCustomerDetailsFromTagging: T,
            getCustomerDetailsFromTaggingPickx: B,
            getCustomerDetailsFromTaggingWebshop: M,
            getCustomerDetailsFromTaggingWOC: U,
            getCustomerDetailsFromBrowserStorageProximus: j,
            getCustomerDetailsFromBrowserStorageMyBill: H,
            getCustomerDetailsFromBrowserStorageWebshop: R,
            setCustomerDataInCookie: G,
            getCustomerDataInCookie: P,
            getCustomerDetails: W,
          },
          J = W
        return (t._ = E), (t.getCustomerdetails = J), t
      })({})

      _.isEmptyObject = function isEmptyObject(value) {
        if (null == value) return !0
        for (var key in value)
          if (hasOwnProperty.call(value, key)) return !1
        return !0
      }
      _.getUrlParameter = function getUrlParameter(name, str) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]')
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)')
        var results = regex.exec(str)
        return results === null
          ? ''
          : decodeURIComponent(results[1].replace(/\+/g, ' '))
      }
      _.clean = function (text) {
        text =
          text == null
            ? ''
            : (text + '')
                .replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
                .replace(/\s+/g, ' ')
                .split(' ')
                .join('.')
                .replace(/\s/g, '')
        return text
      }
      _.getTxt = (function () {
        var text =
          'innerText' in document.createElement('div')
            ? 'innerText'
            : 'textContent'
        return function (el) {
          return el ? el[text] : null
        }
      })()
      _.extend = function () {
        // Variables
        var extended = {}
        var deep = false
        var i = 0

        // Check if a deep merge
        if (
          Object.prototype.toString.call(arguments[0]) ===
          '[object Boolean]'
        ) {
          deep = arguments[0]
          i++
        }

        // Merge the object into the extended object
        var merge = function (obj) {
          for (var prop in obj) {
            if (obj.hasOwnProperty(prop)) {
              // If property is an object, merge properties
              if (
                deep &&
                Object.prototype.toString.call(obj[prop]) ===
                  '[object Object]'
              ) {
                extended[prop] = _.extend(extended[prop], obj[prop])
              } else {
                extended[prop] = obj[prop]
              }
            }
          }
        }

        // Loop through each object and conduct a merge
        for (; i < arguments.length; i++) {
          merge(arguments[i])
        }

        return extended
      }
      //prettier-ignore
      function safeJSONParse(v){var o=void 0;try{o=JSON.parse(v)}catch(e){}return o}
      //prettier-ignore
      function isJSONText(v){return!!("string"==typeof v&&v.indexOf("{")>-1&&/^[\[|\{](\s|.*|\w)*[\]|}]$/.test(v))}
      // correctly parse values
      function jsonReplacer(k, v) {
        if (!!v && isJSONText(v)) {
          return safeJSONParse(v)
        }
        return v
      }
      //make a 'copy' of the input and transform any json values
      function transformJSONValues(o) {
        var output
        var out = JSON.stringify(o, jsonReplacer)
        if (!!out) {
          output = safeJSONParse(out)
          !!!output && (output = o)
        } else {
          output = o
        }
        return output
      }
      _.getAttributes = function (el) {
        var out = Object.create(null)
        var att = el.attributes
        for (var i = 0; i < att.length; i++) {
          var el = att[i]
          if ((t = el.name.replace('data-tms-', '')) == el.name) {
            // do not add if not properly prefixed
            continue
          }
          if (t.indexOf('event-') != 0) {
            t = t.replace(/-/gm, '.')
          }
          out[t] = el.value.toLowerCase()
        }
        out = transformJSONValues(out)
        return out
      }
      _.unflatten = function unflatten(target, opts) {
        opts = opts || {}
        var delimiter = opts.delimiter || '.'
        var overwrite = opts.overwrite || true
        var result = {}

        if (Object.prototype.toString.call(target) !== '[object Object]') {
          return target
        }

        // safely ensure that the key is
        // an integer.
        function getkey(key) {
          var parsedKey = Number(key)

          return isNaN(parsedKey) || key.indexOf('.') !== -1 || opts.object
            ? key
            : parsedKey
        }

        var sortedKeys = Object.keys(target).sort(function (keyA, keyB) {
          return keyA.length - keyB.length
        })

        sortedKeys.forEach(function (key) {
          var split = key.split(delimiter)
          var key1 = getkey(split.shift())
          var key2 = getkey(split[0])
          var recipient = result

          while (key2 !== undefined) {
            var type = Object.prototype.toString.call(recipient[key1])
            var isobject =
              type === '[object Object]' || type === '[object Array]'

            // do not write over falsey, non-undefined values if overwrite is false
            if (
              !overwrite &&
              !isobject &&
              typeof recipient[key1] !== 'undefined'
            ) {
              return
            }

            if (
              (overwrite && !isobject) ||
              (!overwrite && recipient[key1] == null)
            ) {
              recipient[key1] =
                typeof key2 === 'number' && !opts.object ? [] : {}
            }

            recipient = recipient[key1]
            if (split.length > 0) {
              key1 = getkey(split.shift())
              key2 = getkey(split[0])
            }
          }

          // unflatten again for 'messy objects'
          recipient[key1] = unflatten(target[key], opts)
        })

        return result
      }
      function extractWebshopEventData(data) {
        var o = {}
        if (
          !!data &&
          !!data.data_action &&
          !!data.event_action &&
          !!data.event_location &&
          !!data.event_detail
        ) {
          var event_string = [
            data.event_action,
            data.event_location,
            data.event_detail,
          ]
            .join(':')
            .toLowerCase()
          var link = {
            name: data.page_event || data.eventName,
            zone: data.event_location,
          }
          o.event = 'link-click'
          o.eventstring = event_string
          o.link = link
          //handle the promocodes in webshop
          if (!!data.promoCode) {
            o.promocode = data.promoCode
            if (!!!o.action) {
              o.action = {
                name: data.event_action.toLowerCase(),
              }
            }
          }
          if (!!data.promoCodeError) {
            o.error = {
              type: 'error',
              message: data.promoCodeError,
            }
          }
          return o
        }
        return data
      }
      _.parseUtagData = function parseUtagData(data) {
        data = _.convertWebshopViewsToEvent(data)
        data = extractWebshopEventData(data)
        if (data.event && data.event.toLowerCase() == 'click') {
          data.event = 'link-click'
          if (!!data.event_location) {
            data.link_zone = data.event_location
            delete data.event_location
          }
          if (!!data.event_detail) {
            data.link_name = data.event_detail
            delete data.event_detail
          }
        }
        var o = __.unflatten(data, { delimiter: '_' })
        if (JSON.stringify(o) == '{}') {
          return undefined
        }
        !!o.page && !!o.page.lang && (o.page.language = o.page.lang)
        !!o.segment &&
          !!o.segment.page &&
          o.segment.page.segment &&
          (o.page.segment = o.segment.page.segment)
        o = JSON.parse(JSON.stringify(o))
        return o
      }
      _.getDataset = function (el) {
        return _.unflatten(_.getAttributes(el))
      }
      _.crypto = {}
      !(function (root) {
        function FF(a, b, c, d, m, s, k) {
          var n = a + ((b & c) | (~b & d)) + (m >>> 0) + k
          return ((n << s) | (n >>> (32 - s))) + b
        }
        function GG(a, b, c, d, m, s, k) {
          var n = a + ((b & d) | (c & ~d)) + (m >>> 0) + k
          return ((n << s) | (n >>> (32 - s))) + b
        }
        function HH(a, b, c, d, m, s, k) {
          var n = a + (b ^ c ^ d) + (m >>> 0) + k
          return ((n << s) | (n >>> (32 - s))) + b
        }
        function II(a, b, c, d, m, s, k) {
          var n = a + (c ^ (b | ~d)) + (m >>> 0) + k
          return ((n << s) | (n >>> (32 - s))) + b
        }
        function bs(byte) {
          return String.fromCharCode(255 & byte)
        }
        function wordToBytes(word) {
          return (
            bs(word) + bs(word >>> 8) + bs(word >>> 16) + bs(word >>> 24)
          )
        }
        function byteToHex(byte) {
          return (256 + (255 & byte)).toString(16).substr(-2)
        }
        var utf8toBytes = function (utf8) {
          return unescape(encodeURIComponent(utf8))
        }
        function bytesToWords(bytes) {
          for (
            var bytes_count = bytes.length,
              bits_count = bytes_count << 3,
              words = new Uint32Array(((bytes_count + 72) >>> 6) << 4),
              i = 0,
              n = bytes.length;
            i < n;
            ++i
          )
            words[i >>> 2] |= bytes.charCodeAt(i) << ((3 & i) << 3)
          return (
            (words[bytes_count >> 2] |= 128 << (31 & bits_count)),
            (words[words.length - 2] = bits_count),
            words
          )
        }
        var bytesToMD5 = function (bytes) {
            for (
              var words = bytesToWords(bytes),
                a = 1732584193,
                b = 4023233417,
                c = 2562383102,
                d = 271733878,
                S11 = 7,
                S12 = 12,
                S13 = 17,
                S14 = 22,
                S21 = 5,
                S22 = 9,
                S23 = 14,
                S24 = 20,
                S31 = 4,
                S32 = 11,
                S33 = 16,
                S34 = 23,
                S41 = 6,
                S42 = 10,
                S43 = 15,
                S44 = 21,
                i = 0,
                ws = words.length;
              i < ws;
              i += 16
            ) {
              var AA = a,
                BB = b,
                CC = c,
                DD = d
              ;(a = FF(a, b, c, d, words[i + 0], 7, 3614090360)),
                (d = FF(d, a, b, c, words[i + 1], 12, 3905402710)),
                (c = FF(c, d, a, b, words[i + 2], 17, 606105819)),
                (b = FF(b, c, d, a, words[i + 3], 22, 3250441966)),
                (a = FF(a, b, c, d, words[i + 4], 7, 4118548399)),
                (d = FF(d, a, b, c, words[i + 5], 12, 1200080426)),
                (c = FF(c, d, a, b, words[i + 6], 17, 2821735955)),
                (b = FF(b, c, d, a, words[i + 7], 22, 4249261313)),
                (a = FF(a, b, c, d, words[i + 8], 7, 1770035416)),
                (d = FF(d, a, b, c, words[i + 9], 12, 2336552879)),
                (c = FF(c, d, a, b, words[i + 10], 17, 4294925233)),
                (b = FF(b, c, d, a, words[i + 11], 22, 2304563134)),
                (a = FF(a, b, c, d, words[i + 12], 7, 1804603682)),
                (d = FF(d, a, b, c, words[i + 13], 12, 4254626195)),
                (c = FF(c, d, a, b, words[i + 14], 17, 2792965006)),
                (a = GG(
                  a,
                  (b = FF(b, c, d, a, words[i + 15], 22, 1236535329)),
                  c,
                  d,
                  words[i + 1],
                  5,
                  4129170786,
                )),
                (d = GG(d, a, b, c, words[i + 6], 9, 3225465664)),
                (c = GG(c, d, a, b, words[i + 11], 14, 643717713)),
                (b = GG(b, c, d, a, words[i + 0], 20, 3921069994)),
                (a = GG(a, b, c, d, words[i + 5], 5, 3593408605)),
                (d = GG(d, a, b, c, words[i + 10], 9, 38016083)),
                (c = GG(c, d, a, b, words[i + 15], 14, 3634488961)),
                (b = GG(b, c, d, a, words[i + 4], 20, 3889429448)),
                (a = GG(a, b, c, d, words[i + 9], 5, 568446438)),
                (d = GG(d, a, b, c, words[i + 14], 9, 3275163606)),
                (c = GG(c, d, a, b, words[i + 3], 14, 4107603335)),
                (b = GG(b, c, d, a, words[i + 8], 20, 1163531501)),
                (a = GG(a, b, c, d, words[i + 13], 5, 2850285829)),
                (d = GG(d, a, b, c, words[i + 2], 9, 4243563512)),
                (c = GG(c, d, a, b, words[i + 7], 14, 1735328473)),
                (a = HH(
                  a,
                  (b = GG(b, c, d, a, words[i + 12], 20, 2368359562)),
                  c,
                  d,
                  words[i + 5],
                  4,
                  4294588738,
                )),
                (d = HH(d, a, b, c, words[i + 8], 11, 2272392833)),
                (c = HH(c, d, a, b, words[i + 11], 16, 1839030562)),
                (b = HH(b, c, d, a, words[i + 14], 23, 4259657740)),
                (a = HH(a, b, c, d, words[i + 1], 4, 2763975236)),
                (d = HH(d, a, b, c, words[i + 4], 11, 1272893353)),
                (c = HH(c, d, a, b, words[i + 7], 16, 4139469664)),
                (b = HH(b, c, d, a, words[i + 10], 23, 3200236656)),
                (a = HH(a, b, c, d, words[i + 13], 4, 681279174)),
                (d = HH(d, a, b, c, words[i + 0], 11, 3936430074)),
                (c = HH(c, d, a, b, words[i + 3], 16, 3572445317)),
                (b = HH(b, c, d, a, words[i + 6], 23, 76029189)),
                (a = HH(a, b, c, d, words[i + 9], 4, 3654602809)),
                (d = HH(d, a, b, c, words[i + 12], 11, 3873151461)),
                (c = HH(c, d, a, b, words[i + 15], 16, 530742520)),
                (a = II(
                  a,
                  (b = HH(b, c, d, a, words[i + 2], 23, 3299628645)),
                  c,
                  d,
                  words[i + 0],
                  6,
                  4096336452,
                )),
                (d = II(d, a, b, c, words[i + 7], 10, 1126891415)),
                (c = II(c, d, a, b, words[i + 14], 15, 2878612391)),
                (b = II(b, c, d, a, words[i + 5], 21, 4237533241)),
                (a = II(a, b, c, d, words[i + 12], 6, 1700485571)),
                (d = II(d, a, b, c, words[i + 3], 10, 2399980690)),
                (c = II(c, d, a, b, words[i + 10], 15, 4293915773)),
                (b = II(b, c, d, a, words[i + 1], 21, 2240044497)),
                (a = II(a, b, c, d, words[i + 8], 6, 1873313359)),
                (d = II(d, a, b, c, words[i + 15], 10, 4264355552)),
                (c = II(c, d, a, b, words[i + 6], 15, 2734768916)),
                (b = II(b, c, d, a, words[i + 13], 21, 1309151649)),
                (a = II(a, b, c, d, words[i + 4], 6, 4149444226)),
                (d = II(d, a, b, c, words[i + 11], 10, 3174756917)),
                (c = II(c, d, a, b, words[i + 2], 15, 718787259)),
                (b = II(b, c, d, a, words[i + 9], 21, 3951481745)),
                (a = (a + AA) >>> 0),
                (b = (b + BB) >>> 0),
                (c = (c + CC) >>> 0),
                (d = (d + DD) >>> 0)
            }
            var hash_bytes = new String(
              wordToBytes(a) +
                wordToBytes(b) +
                wordToBytes(c) +
                wordToBytes(d),
            )
            return (
              (hash_bytes.toHex = function () {
                for (var hex = '', i = 0, n = hash_bytes.length; i < n; ++i)
                  hex += byteToHex(hash_bytes.charCodeAt(i))
                return hex
              }),
              hash_bytes
            )
          },
          utf8toMD5 = function (utf8) {
            return bytesToMD5(utf8toBytes(utf8))
          }
        function md5(utf8) {
          return utf8toMD5(utf8).toHex()
        }
        root.md5 = md5
      })(_.crypto)

      _.crypto.isMD5 = function isMD5(inputString) {
        return /[a-fA-F0-9]{32}/.test(inputString)
      }

      _.crypto.isSHA256 = function isSHA256(inputString) {
        return /\b[A-Fa-f0-9]{64}\b/.test(inputString)
      }

      /*! litejs.com/MIT-LICENSE.txt */
      !(function (q) {
        function D() {
          function a(a) {
            return (4294967296 * (a - (a >>> 0))) | 0
          }
          var b = 0,
            c = 2,
            d
          a: for (; 64 > b; c++) {
            for (d = 2; d * d <= c; d++) if (0 === c % d) continue a
            8 > b && (h[b] = a(Math.pow(c, 0.5)))
            C[b++] = a(Math.pow(c, 1 / 3))
          }
        }
        var h = [],
          C = []
        ;(q.crypto || (q.crypto = {})).sha256 = function (a) {
          h[0] || D()
          var b,
            c,
            d,
            e,
            n,
            p,
            r,
            k,
            l,
            f,
            m = 0,
            g = [],
            t = h[0],
            u = h[1],
            v = h[2],
            w = h[3],
            x = h[4],
            y = h[5],
            z = h[6],
            A = h[7],
            B
          b = void 0
          if ('string' == typeof a) {
            a = unescape(encodeURIComponent(a))
            b = a.length
            c = 0
            for (d = []; c < b; )
              d[c >> 2] =
                (a.charCodeAt(c++) << 24) |
                (a.charCodeAt(c++) << 16) |
                (a.charCodeAt(c++) << 8) |
                a.charCodeAt(c++)
            d.len = b
            a = d
            b = a.len
          } else b = b || a.length << 2
          a[b >> 2] |= 128 << (24 - (31 & (b <<= 3)))
          a[(((b + 64) >> 9) << 4) + 15] = b
          B = a
          for (var q = B.length, E = C; m < q; ) {
            a = t
            b = u
            c = v
            d = w
            e = x
            n = y
            p = z
            r = A
            for (f = 0; 64 > f; )
              16 > f
                ? (g[f] = B[m + f])
                : ((k = g[f - 2]),
                  (l = g[f - 15]),
                  (g[f] =
                    ((k >>> 17) ^
                      (k << 15) ^
                      (k >>> 19) ^
                      (k << 13) ^
                      (k >>> 10)) +
                    (g[f - 7] | 0) +
                    ((l >>> 7) ^
                      (l << 25) ^
                      (l >>> 18) ^
                      (l << 14) ^
                      (l >>> 3)) +
                    (g[f - 16] | 0))),
                (k =
                  (g[f] | 0) +
                  r +
                  ((e >>> 6) ^
                    (e << 26) ^
                    (e >>> 11) ^
                    (e << 21) ^
                    (e >>> 25) ^
                    (e << 7)) +
                  ((e & n) ^ (~e & p)) +
                  E[f++]),
                (l =
                  ((a >>> 2) ^
                    (a << 30) ^
                    (a >>> 13) ^
                    (a << 19) ^
                    (a >>> 22) ^
                    (a << 10)) +
                  ((a & b) ^ (a & c) ^ (b & c))),
                (r = p),
                (p = n),
                (n = e),
                (e = (d + k) | 0),
                (d = c),
                (c = b),
                (b = a),
                (a = (k + l) | 0)
            t += a
            u += b
            v += c
            w += d
            x += e
            y += n
            z += p
            A += r
            m += 16
          }
          m = [t, u, v, w, x, y, z, A]
          for (g = m.length; g--; )
            m[g] = ('0000000' + (m[g] >>> 0).toString(16)).slice(-8)
          return m.join('')
        }
      })(_)

      _.getDomData = function (el) {
        if (!!!el) {
          return undefined
        }

        var data = _.getDataset(el)
        var info = {}
        if (!!data && data.info) {
          //TODO safe json parse (externalise to not harm perf)
          info = JSON.parse(data.info)
          delete data.info
        }
        var args = [true, {}, data]
        !!info && args.push(info)
        var o = _.extend.apply(_, args)
        return o
      }
      //add userinfo data
      ;(function (root) {
        root.getUserInfo = getUserInfo

        function getUserInfo() {
          var info = _satellite.cookie.get('userInfo')
          var out
          function getCategories(v) {
            if (!!v) {
              return v == 1
                ? 'internet'
                : v == 2
                ? 'tv'
                : v == 3
                ? 'fix'
                : v == 4
                ? 'mobile'
                : undefined
            }
            return undefined
          }
          if (!!info) {
            info = decodeURIComponent(info)
            info = info.split('|')
            var segment = info[0]
            var mcsonly = info[1]
            var owner = info[2]
            var categories = info[3]
            var prepaid = info[4]
            if (!!prepaid) {
              if (prepaid == 0) {
                prepaid = info[5] || ''
                prepaid = prepaid + ''
                prepaid = prepaid.toLowerCase()
              } else if (prepaid == 1) {
                prepaid = info[5] || 'prepaid'
                prepaid = prepaid + ''
                prepaid = prepaid.toLowerCase()
              } else {
                prepaid = undefined
              }
            }
            !!segment &&
              (segment =
                segment == 1
                  ? 'private'
                  : segment == 2
                  ? 'companies'
                  : segment == 3
                  ? 'large'
                  : undefined)
            mcsonly = mcsonly == 1 ? 'mcsonly' : undefined
            !!owner && (owner = owner == 1 ? 'au' : 'ur')
            if (!!categories && (categories = categories.split(','))) {
              var tcat = []
              for (var i = 0; i < categories.length; i++) {
                var f = getCategories(categories[i])
                !!f && tcat.push(f)
              }
              tcat.length > 0 && (categories = tcat.sort().join('-'))
            }
            !!!segment && (segment = 'na')
            !!!owner && (owner = 'na')
            !!!categories && (categories = 'na')
            !!!prepaid && (prepaid = 'na')
            var output = [segment, owner, categories, prepaid]
            output = output.join('|')
            out = output
          }
          return out
        }
      })(_)

      ;(function (scope) {
        var dec2hex = []
        for (var i = 0; i <= 15; i++) {
          dec2hex[i] = i.toString(16)
        }

        var UUID = function () {
          var uuid = ''
          for (var i = 1; i <= 18; i++) {
            if (i === 15) {
              uuid += 4
            } else if (i === 20) {
              uuid += dec2hex[(Math.random() * 4) | (0 + 8)]
            } else {
              uuid += dec2hex[(Math.random() * 16) | 0]
            }
          }
          scope.UUID = function () {
            return uuid
          }
          return uuid
        }
        scope.UUID = UUID
      })(_)
      _.consentLevels = window.__.consentLevels || undefined
      window.__ = _
      //end util
    })()

    ;(function (LIB) {
      ;('use strict')
      var salesCatLookup = [
        { name: 'onlinesales#connectivity#fixedline#', category: 'fix' },
        { name: 'onlinesales#connectivity#internet#', category: 'fix' },
        { name: 'onlinesales#connectivity#postpaid', category: 'postpaid' },
        { name: 'onlinesales#connectivity#prepaid#', category: 'prepaid' },
        { name: 'onlinesales#connectivity#tv#', category: 'fix' },
        { name: 'onlinesales#device#', category: 'device' },
        { name: 'onlinesales#e-reload', category: 'ereload' },
        {
          name: 'onlinesales#pack#pack#pack#',
          category: 'fix,postpaid,tvservices',
        },
        {
          name: 'onlinesales#stimulation#tvservices#',
          category: 'tvservices',
        },
        { name: 'onlinesales#stimulation#', category: 'services' },
      ]
      //start categorisation sales cats
      function getProductClassification(key) {
        var array = salesCatLookup
        var al = array.length
        for (var index = 0; index < al; index++) {
          var element = array[index]
          if (!!key && key.indexOf(element.name) > -1) {
            return element.category
          }
        }
        return false
      }
      if (!LIB) {
        return true
      }
      LIB.parseProducts = parseProducts

      function extractCatFromSalesCatLookup(sc) {
        var spl = !!sc ? sc.split('#') : []
        spl = !!spl && spl.length >= 3 ? spl[2] : false
        return spl
      }

      function getBundleCategory(record) {
        if (record.group_type == 'standalone') {
          if (!!record.sales_category) {
            var o = extractCatFromSalesCatLookup(record.sales_category)
            if (!!o) {
              return o
            } else if (!!record.category) {
              return record.category
            }
          }
        } else if (
          !!record.sales_category &&
          record.sales_category.indexOf('connectivity') > -1
        ) {
          var o = extractCatFromSalesCatLookup(record.sales_category)
          return o
        }
        return undefined
      }

      function productToLowerCase(b) {
        return JSON.parse(
          JSON.stringify(b)
            .toLowerCase()
            .replace(/"(\d+)(,)(\d+)"/g, '"$1.$3"')
            .replace(/\|/gm, '#')
            .replace(/;/gm, '#'),
        )
      }
      var dataphone_lu = {
        dvanr: 's',
        mhzmj: 'm',
        plkay: 'l',
      }
      function parseProduct(product, parent, out, order) {
        if (!!!product || !!!product.id) {
          return out ? out : []
        }
        var toAdd = true
        var record = {
          bundleid: product.bundleid || parent.bundleid,
          id: product.id,
          best_pick: product.best_pick || '0',
          name: product.name,
          type: product.action || 'new',
          price: (product.price || 0) + '',
          // points : (product.points || 0) + "",//removed due to unused
          quantity: (product.quantity || 1) + '',
          clv: (product.clv || 0) + '',
          upm: '0',
          sales_category: product.sales_category,
          cumulated: product.cumulated
            ? product.cumulated.replace(/,/gm, '-')
            : product.cumulated,
          cat: product.category,
          cat_type: product.type || product.id,
          level: product.level || 0,
          group_main: '',
          order_cumulated: '',
          group_type: '',
          group_id: '',
          sales_category_context: 'outofpack',
          bundle_category: '',
          category: '',
          sales_category_ctx: '',
          subcat: '',
          isjo: product.isjo || false,
          combi: '',
          options: [],
          stock: product.stock || 'na',
          hasjo: product.isjo || 'na',
          hasclickcollect: product.hasclickcollect || 'na',
          jostock: product.jostock || 'na',
          prejostock: product.prejostock || 'na',
          prestock: product.prestock || 'na',
          ccstock: product.ccstock || 'na',
          detail: '',
          classification: '',
          processed: true,
        }
        record.detail = [
          record.stock,
          record.hasjo,
          record.hasclickcollect,
          record.jostock,
          record.prejostock,
          record.prestock,
          record.ccstock,
        ].join('#')
        record.upm = record.quantity * record.price + ''
        record.classification = !!record.sales_category
          ? getProductClassification(record.sales_category)
          : ''
        if (parent) {
          if (record.cat == 'joint_offer') {
            record.level = 0
            //parent.isjo = true;
            record.isjo = true
          }

          var dfl = dataphone_lu[record.id]
          !!dfl && (record.name = 'option ' + dfl)
          record.cumulated = parent.cumulated
          record.group_main = parent.group_type
          record.group_type = record.group_type || parent.group_type
          record.group_id = parent.group_id
          record.level > 1 &&
            !!record.name &&
            !!dfl &&
            (parent.combi += !!!parent.combi
              ? '' + record.name
              : ' + ' + record.name)
          record.level == 1 &&
            !!record.name &&
            (parent.combi += !!!parent.combi
              ? '' + record.name
              : ' + ' + record.name)
          record.level == 1 &&
            !!!record.isjo &&
            (record.bundle_category = getBundleCategory(record))

          record.sales_category_context = parent.sales_category_context
          record.group_type === 'unspecified' &&
            (record.group_type = undefined)
          !!record.group_type &&
            record.group_type !== 'standalone' &&
            (record.group_type = parent.group_type + ' component')
          !!record.group_type &&
            record.group_type === 'standalone' &&
            record.level > 1 &&
            (record.group_type = parent.group_type + ' component')
          if (record.isjo) {
            if (record.level > 0) {
              record.group_type = record.group_type + ' jo component'
              record.sales_category_context = parent.sales_category_context
            } else if (record.level == 0) {
              record.group_type = record.group_type + ' jo'
              record.sales_category_context =
                parent.group_type == 'pack' ? 'inpack' : 'outofpack'
            }
          }
          record.options = parent.options
          if (
            !!record.sales_category &&
            (record.sales_category.indexOf('tvservices') > -1 ||
              record.sales_category.indexOf(
                'fixed-telephony-options#international-calls',
              ) > -1)
          ) {
            record.options.push(record.name)
          }
          order.combi = parent.combi
          record.combi = order.combi
          parent.options = record.options
          record.category = !!parent.category
            ? parent.category == record.category
              ? product.category
                ? product.category
                : 'product'
              : parent.category +
                ' ' +
                (product.category ? product.category : 'product')
            : undefined
        } else {
          var bundlecategory = !!product.category
            ? product.category
            : !!product.id && product.id !== ''
            ? product.id
            : ''
          if (bundlecategory === 'standalone') {
            toAdd = false
          } else if (bundlecategory === 'unspecified') {
            toAdd = false
          } else if (bundlecategory === 'pack') {
            record.sales_category_context = 'inpack'
            record.product_up = '0'
          } else if (bundlecategory === 'mcs_joint_offer') {
            bundlecategory = 'jo'
          }

          record.group_type =
            bundlecategory === 'unspecified' ? undefined : bundlecategory
          record.group_main = record.group_type
          order.order_cumulated = !!order.order_cumulated
            ? order.order_cumulated + ' + ' + record.group_main
            : record.group_main
          order.combi = record.combi
          record.group_id = product.name
          record.category = !!record.group_type
            ? record.group_type == product.type
              ? product.type
              : record.group_type +
                (!!product.type ? ' ' + product.type : '')
            : undefined
          parent = record
        }
        record.sales_category_ctx =
          !!record.sales_category && cnt(record.sales_category, '#') < 4
            ? record.sales_category + '#na'
            : record.sales_category
        record.sales_category_ctx = !!record.sales_category_ctx
          ? record.sales_category_ctx + '#' + record.sales_category_context
          : record.sales_category_ctx
        record.subcat = record.cumulated || product.category

        !!toAdd && out.push(record)
        var sp
        if ((sp = product.products)) {
          if (Object.prototype.toString.call(sp) !== '[object Array]') {
            product.products = [product.products]
            sp = product.products
          }
          var spl = sp.length
          for (var i = 0; i < spl; i++) {
            var p = sp[i]
            p.level = record.level + 1
            p.isjo = record.isjo || false
            parseProduct(p, parent, out, order)
          }
        }

        return out
      }

      function cnt(str, schar) {
        return str.length - str.replace(RegExp(schar, 'gm'), '').length
      }

      function parseProducts(products) {
        var out = []
        var order = { combi: undefined, order_cumulated: undefined }
        products = productToLowerCase(products)
        var pl = products.length
        for (var i = 0; i < pl; i++) {
          var p = products[i]
          p.bundleid = 'id' + i
          parseProduct(p, undefined, out, order)
        }
        var lng = out.length

        var funneldetails = {}
        var funneldetailsorder = []
        for (var x = 0; x < lng; x++) {
          var prod = out[x]
          var bc = prod.bundle_category
          var bid = prod.bundleid
          if (!!bc && !!bid) {
            if (!!!funneldetails[bid]) {
              funneldetailsorder.push(bid)
            }
            funneldetails[bid] = funneldetails[bid] || []
            funneldetails[bid].push(bc)
          }
        }
        var funnelNames = []
        var funnelTypes = []
        for (var v = 0; v < funneldetailsorder.length; v++) {
          var key = funneldetailsorder[v]
          var value = funneldetails[key].sort()
          var valueLength = value.length
          if (valueLength > 1) {
            value.unshift(valueLength + 'p')
          }
          value = value.join('-')
          funnelTypes.push(valueLength > 1 ? valueLength + 'p' : value)
          funnelNames.push(value)
        }
        funnelTypes = funnelTypes.sort().join('+')
        funnelNames = funnelNames.sort().join('+')
        for (var i = 0; i < lng; i++) {
          out[i].order_cumulated = order.order_cumulated
          out[i].combi = order.combi || ''
          out[i].options = out[i].options || []
          out[i].options = out[i].options.sort().join(' + ') || ''
          out[i].order_cumulated_bundletypes = funnelTypes
          out[i].order_cumulated_bundledetails = funnelNames
        }

        return out
      }
    })(__)
  })
  _satellite['_runScript5'](function (event, target, Promise) {
    var navi =
      window.navigator && window.navigator.userAgent
        ? window.navigator.userAgent.toLowerCase()
        : ''
    if (
      navi.indexOf('bot') > -1 ||
      navi.indexOf('lighthouse') > -1 ||
      navi.indexOf('headless') > -1 ||
      navi.indexOf('ptst') > -1
    ) {
      document.cookie = 'notice_preferences=3:'
      document.cookie = 'notice_gdpr_prefs=0,1,2,3:'
      document.cookie = 'MY_PX_APP_SMARTBANNER=' + new Date().getTime()
      window.truste = {}
      window.truste.eu = {}
      window.truste.cma = true
    }
  })
  _satellite['_runScript4'](function (event, target, Promise) {
    ;(function () {
      var existing = document.querySelector('[name="referrer"]')
      if (!!existing) {
        existing.setAttribute('content', 'origin-when-cross-origin')
      } else {
        var meta = document.createElement('meta')
        meta.setAttribute('name', 'referrer')
        meta.setAttribute('content', 'origin-when-cross-origin')
        document.head.appendChild(meta)
      }
    })()
  })
  _satellite['_runScript3'](function (event, target, Promise) {
    ;(function () {
      var root = {}
      !(function (root, factory) {
        'function' == typeof define && define.amd
          ? define([], factory)
          : 'object' == typeof exports
          ? (module.exports = factory())
          : (root.sentinel = factory())
      })(root, function () {
        var isArray = Array.isArray,
          selectorToAnimationMap = {},
          animationCallbacks = {},
          styleEl,
          styleSheet,
          cssRules
        return {
          on: function (cssSelectors, callback) {
            if (callback) {
              if (!styleEl) {
                var doc = document,
                  head = doc.head
                doc.addEventListener(
                  'animationstart',
                  function (ev, callbacks, l, i) {
                    if ((callbacks = animationCallbacks[ev.animationName]))
                      for (
                        ev.stopImmediatePropagation(),
                          l = callbacks.length,
                          i = 0;
                        i < l;
                        i++
                      )
                        callbacks[i](ev.target)
                  },
                  !0,
                ),
                  (styleEl = doc.createElement('style')),
                  head.insertBefore(styleEl, head.firstChild),
                  (styleSheet = styleEl.sheet),
                  (cssRules = styleSheet.cssRules)
              }
              ;(isArray(cssSelectors) ? cssSelectors : [cssSelectors]).map(
                function (selector, animId, isCustomName) {
                  ;(animId = selectorToAnimationMap[selector]) ||
                    ((isCustomName = '!' == selector[0]),
                    (selectorToAnimationMap[
                      selector
                    ] = animId = isCustomName
                      ? selector.slice(1)
                      : 'sentinel-' + Math.random().toString(16).slice(2)),
                    (cssRules[
                      styleSheet.insertRule(
                        '@keyframes ' +
                          animId +
                          '{from{transform:none;}to{transform:none;}}',
                        cssRules.length,
                      )
                    ]._id = selector),
                    isCustomName ||
                      (cssRules[
                        styleSheet.insertRule(
                          selector +
                            '{animation-duration:0.0001s;animation-name:' +
                            animId +
                            ';}',
                          cssRules.length,
                        )
                      ]._id = selector),
                    (selectorToAnimationMap[selector] = animId)),
                    (animationCallbacks[animId] =
                      animationCallbacks[animId] || []).push(callback)
                },
              )
            }
          },
          off: function (cssSelectors, callback) {
            ;(isArray(cssSelectors) ? cssSelectors : [cssSelectors]).map(
              function (selector, animId, callbackList, i) {
                if ((animId = selectorToAnimationMap[selector])) {
                  if (
                    ((callbackList = animationCallbacks[animId]), callback)
                  )
                    for (i = callbackList.length; i--; )
                      callbackList[i] === callback &&
                        callbackList.splice(i, 1)
                  else callbackList = []
                  if (!callbackList.length) {
                    for (i = cssRules.length; i--; )
                      cssRules[i]._id == selector &&
                        styleSheet.deleteRule(i)
                    delete selectorToAnimationMap[selector],
                      delete animationCallbacks[animId]
                  }
                }
              },
            )
          },
          reset: function () {
            ;(selectorToAnimationMap = {}),
              (animationCallbacks = {}),
              styleEl && styleEl.parentNode.removeChild(styleEl),
              (styleEl = 0)
          },
        }
      })
      function handler(el) {
        if (!!el) {
          //only for the language and the myproximus dropdown for now as the search icon also triggers this
          if (
            el.className.indexOf('rs-btn-lang') > -1 ||
            el.className.indexOf('rs-btn-mypxs') > -1
          ) {
            el.setAttribute('data-tms-noclick', '')
            el.setAttribute('data-tms-id', 'tms_angular_ignore')
          }
        }
      }
      root.sentinel.on('[data-header-toggle="toggleOpen"]', handler)
    })()
  })
  _satellite['_runScript2'](function (event, target, Promise) {
    ;(function () {
      var clean = (function clean() {
        function removeAccents(str) {
          var accents =
              'ÀÁÂÃÄÅàáâãäåÒÓÔÕÕÖØòóôõöøÈÉÊËèéêëðÇçÐÌÍÎÏìíîïÙÚÛÜùúûüÑñŠšŸÿýŽž',
            accentsOut =
              'AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeCcDIIIIiiiiUUUUuuuuNnSsYyyZz',
            strLen = (str = str.split('')).length,
            i,
            x
          for (i = 0; i < strLen; i++)
            -1 != (x = accents.indexOf(str[i])) && (str[i] = accentsOut[x])
          return str.join('')
        }
        function replace(string) {
          if ('string' != typeof string) return string
          var slug = string
            .replace(/[,*+~.()'"?!:@]/gm, '')
            .replace(/^\s+|\s+$/g, '')
            .replace(/[-\s]+/g, '-')
            .replace(/[\u1000-\uFFFF]+/g, '')
            .replace(/(^-)|(-$)/g, '')
          return (slug =
            slug.normalize && 'function' == typeof slug.normalize
              ? slug.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
              : removeAccents(slug)).toLowerCase()
        }
        return replace
      })()
      var LoginOverlayer = {
        initialized: false,
        init: function LoginOverlayerInit() {
          if (!!!this.initialized) {
            window.addEventListener('message', this)
            this.initialized = true
          }
        },
        sendToTMS: function sendToTMS(data) {
          !!data && !!window.utag && !!window.utag.track
            ? this.sendToTealium(data)
            : this.sendToAL(data)
        },
        sendToAL: function sendToAL(data) {
          var popup_zone =
            !!window._satellite && !!window._satellite.getVar
              ? _satellite.getVar('Page ID')
              : 'na'
          data.popup.zone = popup_zone
          !!window.pxdatalayer && window.pxdatalayer.push(data)
        },
        sendToTealium: function sendToTealium(data) {
          var out = {}
          out.event = data.event
          out.event_detail = data.action.name
          out.event_location = data.popup.name
          var popupname = data.popup.name
          var popupzone =
            !!window.utag_data && !!window.utag_data.page_id
              ? window.utag_data.page_id
              : 'na'
          out.event_popup = [popupzone, popupname, 'na'].join('|')
          !!TMS && TMS.send && TMS.send(out)
        },
        handleEvent: function (e) {
          if (
            !!e.data &&
            typeof e.data == 'string' &&
            e.data.toLowerCase().indexOf('loginoverlayer') > -1
          ) {
            if (e.data.indexOf('overlayer_successful_login') > -1) {
              var data = {
                event: 'popup-click',
                popup: {
                  zone: 'na',
                  name: 'login dialog',
                },
                action: {
                  type: 'click',
                  name: 'login success',
                },
              }
              data.eventstring = [
                data.event,
                clean(data.popup.name),
                data.action.name,
              ]
                .join(':')
                .toLowerCase()
              this.sendToTMS(data)
            }
            if (e.data.indexOf('overlayer_cancel_login') > -1) {
              var data = {
                event: 'popup-click',
                popup: {
                  zone: 'na',
                  name: 'login dialog',
                },
                action: {
                  type: 'click',
                  name: 'login cancel',
                },
              }
              data.eventstring = [
                data.event,
                clean(data.popup.name),
                data.action.name,
              ]
                .join(':')
                .toLowerCase()
              this.sendToTMS(data)
            }
            if (e.data.indexOf('overlayer_continue_without_login') > -1) {
              var data = {
                event: 'popup-click',
                popup: {
                  zone: 'na',
                  name: 'login dialog',
                },
                action: {
                  type: 'click',
                  name: 'login continue without',
                },
              }
              data.eventstring = [
                data.event,
                clean(data.popup.name),
                data.action.name,
              ]
                .join(':')
                .toLowerCase()
              this.sendToTMS(data)
            }
            if (e.data.indexOf('overlayer_show_login') > -1) {
              var data = {
                event: 'popup-impression',
                popup: {
                  zone: 'na',
                  name: 'login dialog',
                },
                action: {
                  type: 'click',
                  name: 'login show',
                },
              }
              data.eventstring = [
                data.event,
                clean(data.popup.name),
                data.action.name,
              ]
                .join(':')
                .toLowerCase()
              this.sendToTMS(data)
            }
          }
        },
      }

      LoginOverlayer.init()
      !!window._TMS_ && (window._TMS_.LoginOverlayer = LoginOverlayer)
      !!window.__ && (window.__.LoginOverlayer = LoginOverlayer)
    })()
  })
  _satellite['_runScript1'](function (event, target, Promise) {
    ;(function () {
      function setReferrer() {
        // set the referrer to the previous referrer if there is one
        if (!!!Object.defineProperty) {
          //bail when not supported

          return true
        }
        if (typeof document.previousReferrer != 'string') {
          return false
        }
        //set the vlaue of the referrer to the previousreferrer so that all external code accessing the referrer get the correct value
        Object.defineProperty(document, 'referrer', {
          enumerable: true,

          configurable: true,

          writable: true,

          value: document.previousReferrer,
        })
      }
      var hasConsent =
        !!window.__ &&
        !!window.__.consentLevels &&
        !!window.__.consentLevels.consentGiven
          ? true
          : false

      var referrer = document.referrer
      if (!hasConsent) {
        //no consent, remember the referrer
        sessionStorage.setItem('previousReferrer', document.referrer)
        //monkey patch the sessionstorage.clean method to remember the set value;
        var sclear = sessionStorage.clear
        sessionStorage.clear = function sessionStorageClear() {
          var pref =
            sessionStorage.getItem('previousReferrer') || document.referrer
          sclear.call(sessionStorage)
          sessionStorage.setItem('previousReferrer', pref)
        }
      } else {
        //read the previousReferrer and expose it
        var previousReferrer = sessionStorage.getItem('previousReferrer')
        document.previousReferrer = previousReferrer
        sessionStorage.removeItem('previousReferrer')
        setReferrer()
      }
    })()
  })
        var pxdatalayer = pxdatalayer || []
      pxdatalayer.push({
        page: {
          id: 'Login',
          language: 'fr',
          site: 'sso',
          segment: 'private',

          category: {
            l1: 'Login',
            l2: 'Login',
            l3: 'Login',
          },
        },
      })
      if (navigator.userAgent.includes('MyPXApp-Android')) {
        document.addEventListener('DOMContentLoaded', function (
          event,
        ) {
          document.getElementById(
            'registerTab',
          ).onclick = function () {
            document
              .getElementById('ac-inputRegisterUserName')
              .addEventListener('click', function () {
                document
                  .getElementById('ac-inputRegisterUserName')
                  .scrollIntoView()
              })
          }
        })
      }
      var iportalData = iportalData || {}
      iportalData.bvUrl =
        '//display.ugc.bazaarvoice.com/static/proximus/fr_BE/bvapi.js'
      iportalData.author = false
      var elements = document.querySelectorAll('#langList li a')
      for (var i = 0; i < elements.length; i++) {
        elements[i].onclick = $fn.languageManagement.ngLangSwitch
      }
      ;(window.PxConsentManagerScript =
        window.PxConsentManagerScript || []).push([
        'PXPERSO',
        function () {
          window.hj =
            window.hj ||
            function () {
              ;(hj.q = hj.q || []).push(arguments)
            }
          hj('trigger', 'trigger-login-default-fr')
        },
      ])

      $(document).foundation('interchange', {
        named_queries: {
          STo120: 'only screen and (min-width: 641px)and (max-width: 1200px)',
          LFrom1200: 'only screen and (min-width: 1201px)',
        },
      })
      _satellite['_runScript18'](function (event, target, Promise) {
        !(function () {
          ;(window._dx_ = window._dx_ || {}),
            (window._dx_.util = window._dx_.util || {})
          var e = (window._dx_.WkMp =
            window.WeakMap ||
            function () {
              var e = '__' + [e++, Math.random()],
                t = function (t) {
                  return hOP.call(t, e)
                }
              return {
                has: t,
                get: function (t) {
                  return t[e]
                },
                delete: function (n) {
                  return t(n) && delete n[e]
                },
                set: function (t, n) {
                  return (
                    Object.defineProperty(t, e, { configurable: !0, value: n }),
                    this
                  )
                },
              }
            })
          ;(window._dx_.util.clean = (function () {
            function e(e) {
              var t,
                n,
                o =
                  '\xc0\xc1\xc2\xc3\xc4\xc5\xe0\xe1\xe2\xe3\xe4\xe5\xd2\xd3\xd4\xd5\xd5\xd6\xd8\xf2\xf3\xf4\xf5\xf6\xf8\xc8\xc9\xca\xcb\xe8\xe9\xea\xeb\xf0\xc7\xe7\xd0\xcc\xcd\xce\xcf\xec\xed\xee\xef\xd9\xda\xdb\xdc\xf9\xfa\xfb\xfc\xd1\xf1\u0160\u0161\u0178\xff\xfd\u017d\u017e',
                r =
                  'AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeCcDIIIIiiiiUUUUuuuuNnSsYyyZz',
                i = (e = e.split('')).length
              for (t = 0; t < i; t++)
                -1 != (n = o.indexOf(e[t])) && (e[t] = r[n])
              return e.join('')
            }
            function t(t) {
              if ('string' != typeof t) return t
              var n = t
                .replace(/[,*+~.()'"?!:@]/gm, '')
                .replace(/^\s+|\s+$/g, '')
                .replace(/[-\s]+/g, '-')
                .replace(/[\u1000-\uFFFF]+/g, '')
                .replace(/(^-)|(-$)/g, '')
              return (n =
                n.normalize && 'function' == typeof n.normalize
                  ? n.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                  : e(n)).toLowerCase()
            }
            return t
          })()),
            (window._dx_.util.inViewport = (function (e) {
              function t(t, n, o) {
                var i = {
                  container: e.document.body,
                  offset: 0,
                  debounce: 15,
                  failsafe: 150,
                }
                ;(void 0 !== n && 'function' != typeof n) || ((o = n), (n = {}))
                var a = (i.container = n.container || i.container),
                  u = (i.offset = n.offset || i.offset),
                  d = (i.debounce = n.debounce || i.debounce),
                  l = (i.failsafe = n.failsafe || i.failsafe)
                !0 === l ? (l = 150) : !1 === l && (l = 0),
                  l > 0 && l < d && (l = d + 50)
                for (var s = 0; s < c.length; s++)
                  if (
                    c[s].container === a &&
                    c[s]._debounce === d &&
                    c[s]._failsafe === l
                  )
                    return c[s].isInViewport(t, u, o)
                return c[c.push(r(a, d, l)) - 1].isInViewport(t, u, o)
              }
              function n(e, t, n) {
                e.attachEvent
                  ? e.attachEvent('on' + t, n)
                  : e.addEventListener(t, n, !1)
              }
              function o(e, t, n) {
                var o
                return function () {
                  function r() {
                    ;(o = null), n || e.apply(i, a)
                  }
                  var i = this,
                    a = arguments,
                    c = n && !o
                  clearTimeout(o), (o = setTimeout(r, t)), c && e.apply(i, a)
                }
              }
              function r(t, r, c) {
                function l(e, t, n) {
                  if (!n) return h(e, t)
                  var o = s(e, t, n)
                  return o.watch(), o
                }
                function s(e, t, n) {
                  function o() {
                    v.add(e, t, n)
                  }
                  function r() {
                    v.remove(e)
                  }
                  return { watch: o, dispose: r }
                }
                function f(e, t, n) {
                  h(e, t) && (v.remove(e), n(e))
                }
                function h(n, o) {
                  if (!n) return !1
                  if (
                    !d(e.document.documentElement, n) ||
                    !d(e.document.documentElement, t)
                  )
                    return !1
                  if (!n.offsetWidth || !n.offsetHeight) return !1
                  var r = n.getBoundingClientRect(),
                    i = {}
                  if (t === e.document.body)
                    i = {
                      top: -o,
                      left: -o,
                      right: e.document.documentElement.clientWidth + o,
                      bottom: e.document.documentElement.clientHeight + o,
                    }
                  else {
                    var a = t.getBoundingClientRect()
                    i = {
                      top: a.top - o,
                      left: a.left - o,
                      right: a.right + o,
                      bottom: a.bottom + o,
                    }
                  }
                  return (
                    r.right >= i.left &&
                    r.left <= i.right &&
                    r.bottom >= i.top &&
                    r.top <= i.bottom
                  )
                }
                var v = i(),
                  p = t === e.document.body ? e : t,
                  w = o(v.checkAll(f), r)
                return (
                  n(p, 'scroll', w),
                  p === e && n(e, 'resize', w),
                  u && a(v, t, w),
                  c > 0 && setInterval(w, c),
                  { container: t, isInViewport: l, _debounce: r, _failsafe: c }
                )
              }
              function i() {
                function e(e, t, n) {
                  o(e) || i.push([e, t, n])
                }
                function t(e) {
                  var t = n(e)
                  ;-1 !== t && i.splice(t, 1)
                }
                function n(e) {
                  for (var t = i.length - 1; t >= 0; t--)
                    if (i[t][0] === e) return t
                  return -1
                }
                function o(e) {
                  return -1 !== n(e)
                }
                function r(e) {
                  return function () {
                    for (var t = i.length - 1; t >= 0; t--) e.apply(this, i[t])
                  }
                }
                var i = []
                return { add: e, remove: t, isWatched: o, checkAll: r }
              }
              function a(e, t, n) {
                function o(e) {
                  !0 === e.some(r) && setTimeout(n, 0)
                }
                function r(t) {
                  var n = c.call(
                    [],
                    Array.prototype.slice.call(t.addedNodes),
                    t.target,
                  )
                  return a.call(n, e.isWatched).length > 0
                }
                var i = new MutationObserver(o),
                  a = Array.prototype.filter,
                  c = Array.prototype.concat
                i.observe(t, { childList: !0, subtree: !0, attributes: !0 })
              }
              var c = [],
                u = 'function' == typeof e.MutationObserver,
                d = function () {
                  return (
                    !e.document ||
                    (e.document.documentElement.compareDocumentPosition
                      ? function (e, t) {
                          return !!(16 & e.compareDocumentPosition(t))
                        }
                      : e.document.documentElement.contains
                      ? function (e, t) {
                          return e !== t && !!e.contains && e.contains(t)
                        }
                      : function (e, t) {
                          for (; (t = t.parentNode); ) if (t === e) return !0
                          return !1
                        })
                  )
                }
              return t
            })(window)),
            (window._dx_.util.QuerySelectorObserver = (function () {
              'use strict'
              function e(e) {
                ;(this._ = []),
                  (this.$ = e),
                  (this.I = 'selector-observer-' + r++),
                  (this.P = i ? 'outline-color' : '--' + this.I)
              }
              function t(e, t, n) {
                ;(this.addedNodes = t),
                  (this.removedNodes = n),
                  (this.target = e ? t[0] : n[0])
              }
              function n(e) {
                var n = d.get(e)
                if (n) {
                  d.delete(e)
                  for (var o, r = 0, i = n.length; r < i; r++)
                    (o = n[r]).connected && o.$([new t(!1, [], [e])])
                }
              }
              function o(e) {
                var t = document,
                  n = t.createElement('style')
                return (n.textContent = e), t.head.appendChild(n)
              }
              var r = 0,
                i = typeof Reflect == typeof i,
                a = [
                  'animationstart',
                  'webkitAnimationStart',
                  'MSAnimationStart',
                ],
                c = ['', '-webkit-', '-moz-', '-ms-', '-o-'],
                u = e.prototype,
                d = new window._dx_.WkMp(),
                l = [],
                s = null
              return (
                (t.prototype.type = 'childList'),
                (u.connected = !0),
                (u.handleEvent = function (e) {
                  e.animationName === this.I &&
                    (e.preventDefault(),
                    e.stopPropagation(),
                    this.$([
                      new t(
                        !0,
                        [
                          (function (e, t) {
                            var n = d.get(t)
                            return (
                              n ? n.indexOf(e) < 0 && n.push(e) : d.set(t, [e]),
                              t
                            )
                          })(this, e.target),
                        ],
                        [],
                      ),
                    ]))
                }),
                (u.observe = function (e) {
                  l.indexOf(e) < 0 && l.push(e),
                    s ||
                      (s = new MutationObserver(function (e) {
                        for (var t = 0, o = e.length; t < o; t++)
                          for (
                            var r,
                              i,
                              a = e[t].removedNodes,
                              c = 0,
                              u = a.length;
                            c < u;
                            c++
                          )
                            if (1 === (r = a[c]).nodeType) {
                              n(r)
                              for (
                                var d = 0,
                                  s = (i = r.querySelectorAll(l)).length;
                                d < s;
                                d++
                              )
                                n(i[d])
                            }
                      })).observe(document, { childList: !0, subtree: !0 })
                  var t = this._,
                    r = this.I,
                    i = this.P
                  t.length ||
                    (function (e, t, n) {
                      for (var r = 0, i = a.length; r < i; r++)
                        document.addEventListener(a[r], e, !0)
                      var u = []
                      for (r = 0, i = c.length; r < i; r++)
                        u[r] =
                          '@' +
                          c[r] +
                          'keyframes ' +
                          t +
                          ['{from{', ':#fff;}to{', ':#000;}}'].join(n)
                      e._.push(o(u.join('\n')))
                    })(this, r, i),
                    t.push(
                      o(
                        (function (e, t) {
                          for (var n = [], o = 0, r = c.length; o < r; o++)
                            n[o] = [
                              '',
                              'animation-duration:0.001s;',
                              'animation-name:' + t,
                            ].join(c[o])
                          return e + '{' + n.join(';') + ';}'
                        })(e, r),
                      ),
                    )
                }),
                (u.disconnect = function () {
                  !(function (e) {
                    e.connected = !1
                    for (var t = 0, n = a.length; t < n; t++)
                      document.removeEventListener(a[t], e, !0)
                    var o = e._.splice(0)
                    for (t = 0, n = o.length; t < n; t++) {
                      var r = o[t],
                        i = r.parentNode
                      i && i.removeChild(r)
                    }
                  })(this)
                }),
                e
              )
            })()),
            (window._dx_.util.matches = function (e, t) {
              var n = Element.prototype
              return (
                n.matches ||
                n.webkitMatchesSelector ||
                n.mozMatchesSelector ||
                n.msMatchesSelector ||
                function (e) {
                  return (
                    -1 !== [].indexOf.call(document.querySelectorAll(e), this)
                  )
                }
              ).call(e, t)
            }),
            (window._dx_.util.closest = function (e, t) {
              if (e.closest) return e.closest(t)
              for (; e; ) {
                if (window._dx_.util.matches(e, t)) return e
                e = e.parentElement
              }
              return null
            })
          var t = new e()
          window._dx_.viewed = {}
          var n = function (e) {
            e = e || []
            for (var n = 0; n < e.length; n++) {
              var o = e[n]
              if (o.addedNodes && o.addedNodes.length)
                for (var r = 0; r < o.addedNodes.length; r++) {
                  var i = o.addedNodes[r]
                  if (!t.has(i)) {
                    var a = __.getDomData(i),
                      c =
                        a && a.event
                          ? a.event.split('-').shift()
                          : 'interaction'
                    _satellite.logger.log('ImpressionTracker', c, a)
                    var u = {},
                      d = !!a && !!a[c] && a[c].name,
                      l = !!a && !!a[c] && a[c].zone
                    d && ((d = d.toLowerCase()), 'banner' === c && (u.id = d)),
                      _satellite.logger.log('ImpressionTracker', c, d, l)
                    var s = function (e) {
                      if (!!window['at-body-style'])
                        return this.watcher && this.watcher.watch(), !1
                      var t = __.getDomData(e),
                        n = {}
                      for (var o in t) 'event' != o && (n[o] = t[o])
                      var r =
                          t && t.products && t.products.length > 0
                            ? t.products
                            : t && t.product && t.product.length > 0
                            ? t.product
                            : void 0,
                        i = this.id
                      if (i && window._dx_.viewed[i])
                        return (window._dx_.viewed[i] += 1), !0
                      _satellite.logger.log(
                        'ImpressionTracker callback data',
                        c,
                        t,
                      ),
                        (n.event = c + '-impression'),
                        (n[c] = t[c] || {}),
                        (n[c].name = window._dx_.util.clean(d)),
                        (n[c].zone = l),
                        (n.products = r),
                        _satellite.logger.log(
                          'ImpressionTracker callback output',
                          c,
                          t,
                          n,
                        ),
                        i && (window._dx_.viewed[i] = 1),
                        pxdatalayer.push(n),
                        this.watcher
                    }
                    if (
                      ((u.cb = s),
                      !!window['at-body-style'] &&
                        window._dx_.util.inViewport(i))
                    ) {
                      u.cb.bind(u)(i)
                    } else {
                      var f = i.offsetHeight
                      f = (f = f > window.innerHeight ? 0 : f) ? 0.2 * -f : 0
                      var h = window._dx_.util.inViewport(
                        i,
                        { failsafe: !1, offset: f },
                        u.cb.bind(u),
                      )
                      u.watcher = h
                    }
                    t.set(i, u)
                  }
                }
            }
          }
          ;(window._dx_.qso = new window._dx_.util.QuerySelectorObserver(n)),
            window._dx_.qso.observe('[data-tms-event*="-impression"]'),
            (window._dx_.__mp = t)
        })()
      })
      _satellite['_runScript20'](function (event, target, Promise) {
        window.addEventListener('message', function (e) {
          if (!e || !e.origin || '' === e.origin) return !0
          if (!e.data || 'string' != typeof e.data || '' === e.data) return !0
          var t,
            a = e.data.slice('tms$'.length)
          if (
            0 !== e.data.indexOf('tms$') ||
            !/^[\[|\{](\s|.*|\w)*[\]|\}]$/.test(a)
          )
            return !0
          try {
            t = JSON.parse(a)
          } catch (e) {
            return !0
          }
          if (
            (t =
              t && 'Array' !== Object.prototype.toString.call(t).slice(8, -1)
                ? [t]
                : t) &&
            t.length > 0
          )
            for (var n = 0; n < t.length; n++) {
              var r = __.parseUtagData(t[n])
              r.event &&
                'element_load' == r.event &&
                (r.event = 'page-impression'),
                window.pxdatalayer && window.pxdatalayer.push(r)
            }
          return !0
        }),
          (window.TMS = window.TMS || {}),
          (window.TMS.send = function (e) {
            if (!e) return !0
            if ((e = __.parseUtagData(e)).event)
              switch (e.event) {
                case 'impression':
                  return !0
                case 'element_load':
                  e.event = 'page-impression'
                  break
                default:
                  e.event = 'app-interaction'
              }
            window.pxdatalayer && window.pxdatalayer.push(e)
          })
      })
      _satellite['_runScript21'](function (event, target, Promise) {
        setTimeout(function () {
          _satellite.track('DomReady2S')
        }, 2e3)
      })
      _satellite['_runScript19'](function (event, target, Promise) {
        !(function () {
          var a = window.utag_data
          if (a) {
            var t = __.parseUtagData(a)
            if (!t) return
            ;(t.event = 'tealiumdata-push'),
              _satellite.logger.log('Found utag_data and converted', t),
              pxdatalayer.push(t)
          }
        })()
      })
      _satellite['_runScript22'](function (event, target, Promise) {
        ;(() => {
          function t(o) {
            var r = n[o]
            if (void 0 !== r) return r.exports
            var i = (n[o] = { exports: {} })
            return e[o].call(i.exports, i, i.exports, t), i.exports
          }
          var e = {
              499: function () {
                var t =
                  (this && this.__awaiter) ||
                  function (t, e, n, o) {
                    return new (n || (n = Promise))(function (r, i) {
                      function s(t) {
                        try {
                          u(o.next(t))
                        } catch (t) {
                          i(t)
                        }
                      }
                      function a(t) {
                        try {
                          u(o.throw(t))
                        } catch (t) {
                          i(t)
                        }
                      }
                      function u(t) {
                        var e
                        t.done
                          ? r(t.value)
                          : ((e = t.value),
                            e instanceof n
                              ? e
                              : new n(function (t) {
                                  t(e)
                                })).then(s, a)
                      }
                      u((o = o.apply(t, e || [])).next())
                    })
                  }
                !(function () {
                  'use strict'
                  t(this, void 0, void 0, function* () {
                    const e = (document.cookie.match(
                        /^(?:.*;)?\s*aam_uuid\s*=\s*([^;]+)(?:.*)?$/,
                      ) || [, null])[1],
                      n = yield (() =>
                        t(this, void 0, void 0, function* () {
                          let t = (document.cookie.match(
                            /^(?:.*;)?\s*selectedCustomerAccountId\s*=\s*([^;]+)(?:.*)?$/,
                          ) || [, null])[1]
                          if (t) return t
                          try {
                            t =
                              JSON.parse(
                                sessionStorage.getItem('customerAccount') ||
                                  '{}',
                              ).customerId || null
                          } catch (e) {
                            t = null
                          }
                          if (t) return t
                          if (
                            !document.cookie.match(
                              /^(.*;)?\s*iiamsid|iiamsid-*\s*=\s*[^;]+(.*)?$/,
                            ) &&
                            'AUT' !==
                              (document.cookie.match(
                                /^(?:.*;)?\s*BGC_AUT_LVL\s*=\s*([^;]+)(?:.*)?$/,
                              ) || [, null])[1]
                          )
                            return null
                          const e = yield fetch('/rest/user/user')
                          if (!e.ok) return null
                          const n = (yield e.json()) || null
                          if (!n) return null
                          for (const t of [
                            'us:fls-default-customer',
                            'us:mcs-default-customer',
                          ])
                            if (
                              n._embedded &&
                              n._embedded.hasOwnProperty(t) &&
                              n._embedded[t].customerId
                            )
                              return n._embedded[t].customerId
                          return null
                        }))(),
                      o = (() => {
                        if (window.utag_data && utag_data.mkt_event)
                          return utag_data.mkt_event
                        if (window.pxdatalayer) {
                          const t = (
                            (window.pxdatalayer.or &&
                            window.pxdatalayer.or.length
                              ? window.pxdatalayer.or
                              : window.pxdatalayer
                            ).find((t) => !!t.page) || {}
                          ).page
                          return (t && t.mkt_event) || null
                        }
                        return null
                      })()
                    if (!n || !o || !e)
                      return void console.log(
                        '%c Skipping processInboundData, missing required data',
                        'background: #222; color: #bada55',
                      )
                    const r = yield (function (e) {
                      return t(this, void 0, void 0, function* () {
                        const t = yield crypto.subtle.digest(
                          'SHA-256',
                          new TextEncoder().encode(e),
                        )
                        return Array.from(new Uint8Array(t))
                          .map((t) => t.toString(16).padStart(2, '0'))
                          .join('')
                      })
                    })(n)
                    fetch('/rest/customer-segment/processInboundData', {
                      method: 'post',
                      body: JSON.stringify({
                        aamUuid: e,
                        dataPartnerUuid: r,
                        segmentIds: o,
                      }),
                      headers: { 'Content-Type': 'application/json' },
                    })
                      .then((t) => t.json())
                      .then((t) => {
                        try {
                          window.sessionStorage.removeItem('nboCondition'),
                            window.localStorage.removeItem('_px.User.Offer')
                        } catch (t) {
                          console.warn(t)
                        }
                      })
                  })
                })()
              },
            },
            n = {}
          ;(() => {
            'use strict'
            t(499)
          })()
        })()
      })
      _satellite['_runScript23'](function (event, target, Promise) {
        !(function () {
          function n(n) {
            return function () {
              window._PX_3P[n].load()
            }
          }
          window._PX_3P ||
            ((window._PX_3P = window._PX_3P || {}),
            (window._PX_3P._ = window._PX_3P._ || {}),
            (window._PX_3P.list3P = ['FB', 'CAPI']),
            (window._PX_3P.delay = 1e3),
            (window._PX_3P.initialize = function () {
              for (var o = 0; o < window._PX_3P.list3P.length; o++) {
                var i = window._PX_3P.list3P[o],
                  t = window._PX_3P[i]
                t &&
                  (t.prepare && t.prepare(),
                  t.init && t.init(),
                  setTimeout(n(i), window._PX_3P.delay))
              }
            }),
            (window._PX_3P._.crypto = {}),
            (function (n) {
              function o() {
                function n(n) {
                  return (4294967296 * (n - (n >>> 0))) | 0
                }
                var o,
                  e = 0,
                  w = 2
                n: for (; 64 > e; w++) {
                  for (o = 2; o * o <= w; o++) if (0 == w % o) continue n
                  8 > e && (i[e] = n(Math.pow(w, 0.5))),
                    (t[e++] = n(Math.pow(w, 1 / 3)))
                }
              }
              var i = [],
                t = []
              ;(n.crypto || (n.crypto = {})).sha256 = function (n) {
                i[0] || o()
                var e,
                  w,
                  _,
                  P,
                  d,
                  r,
                  c,
                  a,
                  p,
                  s,
                  u,
                  l = 0,
                  f = [],
                  X = i[0],
                  h = i[1],
                  m = i[2],
                  C = i[3],
                  v = i[4],
                  A = i[5],
                  I = i[6],
                  y = i[7]
                if (((e = void 0), 'string' == typeof n)) {
                  for (
                    e = (n = unescape(encodeURIComponent(n))).length,
                      w = 0,
                      _ = [];
                    w < e;

                  )
                    _[w >> 2] =
                      (n.charCodeAt(w++) << 24) |
                      (n.charCodeAt(w++) << 16) |
                      (n.charCodeAt(w++) << 8) |
                      n.charCodeAt(w++)
                  ;(_.len = e), (e = (n = _).len)
                } else e = e || n.length << 2
                ;(n[e >> 2] |= 128 << (24 - (31 & (e <<= 3)))),
                  (n[15 + (((e + 64) >> 9) << 4)] = e)
                for (var g = (u = n).length, S = t; l < g; ) {
                  for (
                    n = X,
                      e = h,
                      w = m,
                      _ = C,
                      P = v,
                      d = A,
                      r = I,
                      c = y,
                      s = 0;
                    64 > s;

                  )
                    16 > s
                      ? (f[s] = u[l + s])
                      : ((a = f[s - 2]),
                        (p = f[s - 15]),
                        (f[s] =
                          ((a >>> 17) ^
                            (a << 15) ^
                            (a >>> 19) ^
                            (a << 13) ^
                            (a >>> 10)) +
                          (0 | f[s - 7]) +
                          ((p >>> 7) ^
                            (p << 25) ^
                            (p >>> 18) ^
                            (p << 14) ^
                            (p >>> 3)) +
                          (0 | f[s - 16]))),
                      (a =
                        (0 | f[s]) +
                        c +
                        ((P >>> 6) ^
                          (P << 26) ^
                          (P >>> 11) ^
                          (P << 21) ^
                          (P >>> 25) ^
                          (P << 7)) +
                        ((P & d) ^ (~P & r)) +
                        S[s++]),
                      (p =
                        ((n >>> 2) ^
                          (n << 30) ^
                          (n >>> 13) ^
                          (n << 19) ^
                          (n >>> 22) ^
                          (n << 10)) +
                        ((n & e) ^ (n & w) ^ (e & w))),
                      (c = r),
                      (r = d),
                      (d = P),
                      (P = (_ + a) | 0),
                      (_ = w),
                      (w = e),
                      (e = n),
                      (n = (a + p) | 0)
                  ;(X += n),
                    (h += e),
                    (m += w),
                    (C += _),
                    (v += P),
                    (A += d),
                    (I += r),
                    (y += c),
                    (l += 16)
                }
                for (f = (l = [X, h, m, C, v, A, I, y]).length; f--; )
                  l[f] = ('0000000' + (l[f] >>> 0).toString(16)).slice(-8)
                return l.join('')
              }
            })(window._PX_3P._),
            (window._PX_3P._.crypto.isSHA256 = function (n) {
              return /\b[A-Fa-f0-9]{64}\b/.test(n)
            }),
            (window._PX_3P._.loadScriptCache = {}),
            (window._PX_3P._.loadScript = function (n) {
              if (!window._PX_3P._.loadScriptCache[n]) {
                var o = document.createElement('script')
                ;(o.async = !0), (o.src = n)
                var i = document.getElementsByTagName('script')[0]
                !i && document.head.appendChild(o),
                  i && i.parentNode.insertBefore(o, i),
                  (window._PX_3P._.loadScriptCache[n] = !0)
              }
            }),
            (window._PX_3P.FB = window._PX_3P.FB || {}),
            (window._PX_3P.FB.prepare = function () {
              var n,
                o = function () {
                  var n = function () {
                    n.callMethod
                      ? n.callMethod.apply(n, arguments)
                      : n.queue.push(arguments)
                  }
                  return (
                    (n.push = n),
                    (n.loaded = !0),
                    (n.version = '2.0'),
                    (n.queue = []),
                    n
                  )
                }
              window.fbq ||
                ((n = o()), (window.fbq = n), window._fbq || (window._fbq = n))
            }),
            (window._PX_3P.FB.load = function () {
              window._PX_3P._.loadScript(
                'https://connect.facebook.net/en_US/fbevents.js',
              )
            }),
            (window._PX_3P.FB.init = function () {
              window.fbq('set', 'autoConfig', 'false', '848344025228357')
            }),
            (window._PX_3P.CAPI = window._PX_3P.CAPI || {}),
            (window._PX_3P.CAPI.prepare = function () {
              window.p2sq = window.p2sq || []
            }),
            (window._PX_3P.CAPI.load = function () {
              window._PX_3P._.loadScript(
                'https://cpi.proximus.be/js/v4.2/proximus.be',
              )
            }),
            (window._PX_3P.CAPI.getPII = function () {
              var n = decodeURIComponent(
                (document.cookie.match(
                  /^(?:.*;)?\s*iamsll\s*=\s*([^;]+)(?:.*)?$/i,
                ) || [, null])[1],
              )
              n =
                n && !window._PX_3P._.crypto.isSHA256(n)
                  ? window._PX_3P._.crypto.sha256(n)
                  : n
              var o = decodeURIComponent(
                (document.cookie.match(
                  /^(?:.*;)?\s*firstname\s*=\s*([^;]+)(?:.*)?$/i,
                ) || [, null])[1],
              )
              o =
                o && !window._PX_3P._.crypto.isSHA256(o)
                  ? window._PX_3P._.crypto.sha256(o)
                  : o
              var i = decodeURIComponent(
                (document.cookie.match(
                  /^(?:.*;)?\s*name\s*=\s*([^;]+)(?:.*)?$/i,
                ) || [, null])[1],
              )
              i =
                i && !window._PX_3P._.crypto.isSHA256(i)
                  ? window._PX_3P._.crypto.sha256(i)
                  : i
              var t = {}
              return n && (t.em = n), o && (t.fn = o), i && (t.ln = i), t
            }),
            (window._PX_3P.CAPI.init = function () {
              var n = window._PX_3P.CAPI.getPII()
              window.p2sq && window.p2sq.push({ et: 'Init', p: n })
            }),
            window._PX_3P.initialize())
        })()
      })
      _satellite['_runScript24'](function (event, target, Promise) {
        !(function (e, a, t) {
          'use strict'
          function r() {
            for (var e = 0; e < g.length; e++) {
              if (n(g[e])) i(o(g[e]))
            }
          }
          function n(e) {
            var a = e.src || ''
            return (
              a.indexOf('youtube.com/embed/') > -1 ||
              a.indexOf('youtube.com/v/') > -1
            )
          }
          function o(t) {
            var r = e.createElement('a')
            ;(r.href = t.src),
              (r.hostname = 'www.youtube.com'),
              (r.protocol = e.location.protocol)
            var n =
                '/' === r.pathname.charAt(0) ? r.pathname : '/' + r.pathname,
              o =
                a.location.protocol +
                '%2F%2F' +
                a.location.hostname +
                (a.location.port ? ':' + a.location.port : '')
            if (
              (-1 === r.search.indexOf('enablejsapi') &&
                (r.search =
                  (r.search.length > 0 ? r.search + '&' : '') +
                  'enablejsapi=1'),
              -1 === r.search.indexOf('origin') &&
                -1 === a.location.hostname.indexOf('localhost') &&
                (r.search = r.search + '&origin=' + o),
              'application/x-shockwave-flash' === t.type)
            ) {
              var i = e.createElement('iframe')
              ;(i.height = t.height),
                (i.width = t.width),
                (n = n.replace('/v/', '/embed/')),
                t.parentNode.parentNode.replaceChild(i, t.parentNode),
                (t = i)
            }
            return (
              (r.pathname = n),
              t.src !== r.href + r.hash && (t.src = r.href + r.hash),
              t
            )
          }
          function i(e) {
            ;(e.pauseFlag = !1),
              new YT.Player(e, {
                events: {
                  onStateChange: function (a) {
                    p(a, e)
                  },
                },
              })
          }
          function c(e) {
            var a = {}
            if (
              (m.events.end && (a.end = (99 * e) / 100), m.percentageTracking)
            ) {
              var t,
                r = []
              if (
                (m.percentageTracking.each &&
                  (r = r.concat(m.percentageTracking.each)),
                m.percentageTracking.every)
              ) {
                var n = parseInt(m.percentageTracking.every, 10),
                  o = 100 / n
                for (t = 1; t < o; t++) r.push(t * n)
              }
              for (t = 0; t < r.length; t++) {
                var i = r[t],
                  c = (e * i) / 100
                a[i + '%'] = Math.floor(c)
              }
            }
            return a
          }
          function l(e, a, t) {
            e.getDuration()
            var r,
              n = e.getCurrentTime(),
              o = (e.getPlaybackRate(), e.getVideoData()),
              i = !(!o || !o.title || '' === o.title) && o.title
            for (r in ((e[t] = e[t] || {}), a))
              a[r] <= n && !e[t][r] && ((e[t][r] = !0), s(t, r, n, i))
          }
          function p(e, a) {
            var t = e.data,
              r = e.target,
              n = r.getVideoUrl().match(/[?&]v=([^&#]*)/)[1],
              o = r.getPlayerState(),
              i = r.getVideoData(),
              p = !(!i || !i.title || '' === i.title) && i.title,
              u = r.getDuration(),
              h = r.getCurrentTime(),
              g = c(u),
              d = { 1: 'play', 2: 'pause' }[t]
            if (
              ((a.playTracker = a.playTracker || {}),
              1 !== o || a.timer
                ? (clearInterval(a.timer), (a.timer = !1))
                : (clearInterval(a.timer),
                  (a.timer = setInterval(function () {
                    l(r, g, a.videoId)
                  }, 1e3))),
              a.videoId !== n && T[d] && (T[d].run = !1),
              1 === t &&
                ((a.playTracker[n] = !0), (a.videoId = n), (a.pauseFlag = !1)),
              !a.playTracker[a.videoId])
            )
              return !1
            if (2 === t) {
              if (a.pauseFlag) return !1
              a.pauseFlag = !0
            }
            if (y[d]) {
              if (T[d] && !0 === T[d].run) return !0
              s(a.videoId, d, h, p), T[d] && !1 === T[d].run && (T[d].run = !0)
            }
          }
          function s(e, a, t, r) {
            var n = {
              event: 'video-' + a,
              video: {
                url:
                  (r =
                    !(!r || '' === r) &&
                    r.replace(/\W|\s/g, '.').replace(/\W{2,}/g, '.')) &&
                  '' !== r
                    ? r
                    : 'Youtube-' + e,
                duration: t,
              },
            }
            pxdatalayer.push(n)
          }
          var u
          a.onYouTubeIframeAPIReady =
            ((u = a.onYouTubeIframeAPIReady),
            function () {
              u && u.apply(this, arguments),
                navigator.userAgent.match(/MSIE [67]\./gi) || r()
            })
          for (
            var h = Array.prototype.slice
                .call(e.getElementsByTagName('iframe'))
                .concat(
                  Array.prototype.slice.call(e.getElementsByTagName('embed')),
                ),
              g = [],
              d = 0;
            d < h.length;
            d++
          )
            if (n(h[d])) {
              var f = o(h[d])
              g.push(f)
            }
          h = void 0
          var v,
            m = t || {},
            y = (m.forceSyntax, { play: !0, pause: !0, end: !0 }),
            T = {}
          for (v in m.events)
            m.events.hasOwnProperty(v) &&
              ((y[v] = m.events[v].enabled),
              m.events[v].once && ((T[v] = m.events[v]), (T[v].run = !1)))
          if (0 !== g.length) {
            var b = e.createElement('script')
            b.src = '//www.youtube.com/iframe_api'
            var I = e.getElementsByTagName('script')[0]
            I.parentNode.insertBefore(b, I)
          }
        })(document, window, {
          events: {
            play: { enabled: !0, once: !0 },
            pause: { enabled: !1, once: !0 },
            end: { enabled: !0, once: !1 },
          },
          percentageTracking: { each: [25, 50, 75] },
        })
      })
      _satellite['_runScript25'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })
      _satellite['_runScript26'](function (event, target, Promise) {
        !(function (t, e, h, j, i, n) {
          ;(t.hj =
            t.hj ||
            function () {
              ;(t.hj.q = t.hj.q || []).push(arguments)
            }),
            (t._hjSettings = { hjid: 561467, hjsv: 5 }),
            (i = e.getElementsByTagName('head')[0]),
            ((n = e.createElement('script')).async = 1),
            (n.src = h + t._hjSettings.hjid + j + t._hjSettings.hjsv),
            i.appendChild(n)
        })(window, document, '//static.hotjar.com/c/hotjar-', '.js?sv='),
          _satellite.logger.log('Loading HotJar (' + _hjSettings.hjid + ')')
      })
      ;(function (d, s, e, t) {
        e = d.createElement(s)
        e.type = 'text/java' + s
        e.async = 'async'
        e.src =
          location.protocol +
          '//shared.mediahuis.be/cxense/cxense.proximus.min.js'
        t = d.getElementsByTagName(s)[0]
        t.parentNode.insertBefore(e, t)
      })(document, 'script')
      _satellite['_runScript27'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })
      _satellite['_runScript28'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })
      _satellite['_runScript29'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })
      _satellite['_runScript30'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })
      _satellite['_runScript31'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })
      _satellite['_runScript32'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })
      _satellite['_runScript33'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })
      _satellite['_runScript34'](function (event, target, Promise) {
        var products = _satellite.getVar('Products', event),
          order_id =
            event.detail && event.detail.cart && event.detail.cart.order_id
              ? event.detail.cart.order_id
              : void 0,
          data = { products: products, cart: { order_id: order_id } }
        window._dpgp && window._dpgp.process(data)
      })