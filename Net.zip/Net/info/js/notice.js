function _truste_eumap() {
  truste = self.truste || {}
  truste.eu || (truste.eu = {})
  truste.util || (truste.util = {})
  new Image(1, 1).src =
    ''.replace('http:', 'https:') +
    '?domain=proximus.com&country=be&state=&behavior=expressed&c=' +
    (((1 + Math.random()) * 65536) | 0).toString(16).substring(1)
  truste.util.error = function (l, h, k) {
    k = k || {}
    var j = (h && h.toString()) || '',
      e = k.caller || ''
    if (h && h.stack) {
      j +=
        '\n' +
        h.stack.match(/(@|at)[^\n\r\t]*/)[0] +
        '\n' +
        h.stack.match(/(@|at)[^\n\r\t]*$/)[0]
    }
    truste.util.trace(l, j, k)
    if (truste.util.debug || (!h && !l)) {
      return
    }
    var d = {
      apigwlambdaUrl: '',
      enableJsLog: false,
    }
    if (d.enableJsLog) {
      delete k.caller
      delete k.mod
      delete k.domain
      delete k.authority
      k.msg = l
      var i = new (self.XMLHttpRequest ||
        self.XDomainRequest ||
        self.ActiveXObject)('MSXML2.XMLHTTP.3.0')
      i.open('POST', d.apigwlambdaUrl, true)
      i.setRequestHeader &&
        i.setRequestHeader('Content-type', 'application/json')
      i.send(
        truste.util.getJSON({
          info: truste.util.getJSON(k) || '',
          error: j,
          caller: e,
        }),
      )
    }
  }
  truste.util.trace = function () {
    if (
      self.console &&
      console.log &&
      (this.debug ||
        (this.debug !== false &&
          (self.location.hostname.indexOf('.') < 0 ||
            self.location.hostname.indexOf('.truste-svc.net') > 0)))
    ) {
      if (console.log.apply) {
        console.log.apply(console, arguments)
      } else {
        var d = Function.prototype.bind.call(console.log, console)
        d.apply(console, arguments)
      }
      return true
    }
    return false
  }
  truste.util.getJSON = function (e) {
    if (
      self.JSON &&
      !(self.JSON.org || self.JSON.license || self.JSON.copyright)
    ) {
      return self.JSON.stringify(e)
    }
    if (e instanceof Array) {
      var j = '['
      if (e.length) {
        j += truste.util.getJSON(e[0])
        for (var h = 1; h < e.length; h++) {
          j += ',' + truste.util.getJSON(e[h])
        }
      }
      return j + ']'
    } else {
      if (typeof e == 'string') {
        return '"' + e + '"'
      } else {
        if (e instanceof Object) {
          var d = false,
            j = '{'
          for (var k in e) {
            j += (d ? ',' : '') + '"' + k + '":' + truste.util.getJSON(e[k])
            d = true
          }
          return j + '}'
        } else {
          return e === undefined ? undefined : e + ''
        }
      }
    }
  }
  ;(function () {
    var d = self.onerror
    self.onerror = function e(m, k, h, i, l) {
      var j = [].slice.call(arguments)
      var n = m + (k ? '; ' + k : '') + (h ? ' ' + h : '') + (i ? ':' + i : '')
      if ((n + '' + (l && l.stack)).match(/truste||notice/)) {
        truste.util.error('Got Window Error:', l && l.stack ? l : n, {
          product: 'cm',
          tag: k,
        })
      }
      d && d.apply(self, j)
    }
  })()
  var g = (truste.eu.bindMap = {
    version: 'v1.7-9751',
    domain: 'proximus.com',
    width: parseInt('1024'),
    height: parseInt('270'),
    baseName: 'te-notice-clr1-812a761d-1134-423f-82ed-955eaf47f22c',
    showOverlay: '{ShowLink}',
    hideOverlay: '{HideLink}',
    anchName: 'te-notice-clr1-812a761d-1134-423f-82ed-955eaf47f22c-anch',
    intDivName: 'te-notice-clr1-812a761d-1134-423f-82ed-955eaf47f22c-itl',
    iconSpanId: 'te-notice-clr1-812a761d-1134-423f-82ed-955eaf47f22c-icon',
    containerId:
      !'TrustArcConsent' || /^_LB.*LB_$/.test('TrustArcConsent')
        ? 'teconsent'
        : 'TrustArcConsent',
    messageBaseUrl: '',
    originBaseUrl: '',
    daxSignature: '',
    privacyUrl: '',
    prefmgrUrl:
      '',
    text: 'false',
    icon: 'Préférences de cookies',
    locale: 'fr',
    language: 'fr',
    country: 'be',
    state: '',
    categoryCount: parseInt('4', 10) || 3,
    noticeJsURL:
      (parseInt('0')
        ? ''
        : '') + 'asset/notice.js/v/v1.7-9751',
    assetServerURL:
      (parseInt('0')
        ? ''
        : '') + 'asset/',
    consensuUrl: '',
    cdnURL: ''.replace(
      /^(http:)?\/\//,
      'https://',
    ),
    iconBaseUrl: '',
    behavior: 'expressed',
    behaviorManager: 'eu',
    provisionedFeatures: '',
    cookiePreferenceIcon: '',
    cookieExpiry: parseInt('395', 10) || 395,
    closeButtonUrl: '',
    apiDefaults: '{"reportlevel":16777215}',
    cmTimeout: parseInt('6000', 10),
    popTime:
      new Date(''.replace(' +0000', 'Z').replace(' ', 'T')).getTime() || null,
    popupMsg: '',
    bannerMsgURL: '',
    IRMIntegrationURL: '',
    irmWidth: parseInt(''),
    irmHeight: parseInt(''),
    irmContainerId:
      !'_LBirmcLB_' || /^_LB.*LB_$/.test('_LBirmcLB_')
        ? 'teconsent'
        : '_LBirmcLB_',
    irmText: '',
    lspa: '',
    ccpaText: '',
    containerRole: '',
    iconRole: '',
    atpIds: '',
    dntOptedIn: '',
    gpcOptedIn: '',
    feat: {
      iabGdprApplies: true,
      consentResolution: false,
      dropBehaviorCookie: false,
      crossDomain: false,
      uidEnabled: true,
      replaceDelimiter: false,
      optoutClose: false,
      enableIRM: false,
      enableCM: true,
      enableBanner: false,
      enableCCPA: false,
      enableIrmAutoOptOut: false,
      ccpaApplies: false,
      unprovisionedDropBehavior: false,
      unprovisionedIab: false,
      unprovisionedCCPA: false,
      dnt: false && (navigator.doNotTrack == '1' || window.doNotTrack == '1'),
      dntShowUI: false,
      gpc:
        false &&
        (navigator.globalPrivacyControl || window.globalPrivacyControl),
      iabBannerApplies: false,
      enableTwoStepVerification: false,
      enableContainerRole: true,
      enableContainerLabel: true,
      enableIconRole: true,
      enableIconLabel: true,
      enableReturnFocus: false,
      enableShopify: 0,
      enableReturnFocus: false,
      enableTcfOptout: false,
      enableTransparentAlt: true,
      enableACString: false,
      gcm: { ads: undefined, analytics: undefined },
      autoblock: false,
      gtm: 1,
    },
    autoDisplayCloseButton: false,
    localization: {
      modalTitle: 'Your choices regarding the use of cookies on this site',
    },
  })
  if (/layout=gdpr/.test(g.prefmgrUrl)) {
    g.isGdprLayout = true
  }
  if (/layout=iab/.test(g.prefmgrUrl)) {
    g.isIabLayout = true
  }
  if (self.location.protocol != 'http:') {
    for (var b in g) {
      if (g[b] && g[b].replace) {
        g[b] = g[b].replace(/^(http:)?\/\//, 'https://')
      }
    }
  }
  truste.eu.noticeLP = truste.eu.noticeLP || {}
  truste.eu.noticeLP.pcookie = undefined
  ;(function (d) {
    var m = function (o) {
      if (d.feat.iab) {
        return
      }
      var q = self.document,
        p = q.createElement('script')
      p.setAttribute('async', 'async')
      p.setAttribute('type', 'text/javascript')
      p.setAttribute('crossorigin', '')
      p.setAttribute('importance', 'high')
      p.src = o
      ;(
        q.getElementById(d.containerId) ||
        q.getElementsByTagName('body')[0] ||
        q.getElementsByTagName('head')[0]
      ).appendChild(p)
      d.feat.iab = true
    }
    var l = function (t, s, o, r) {
      if (t()) {
        s()
        return
      }
      var p,
        q = function () {
          if (t()) {
            p = clearInterval(p)
            s()
          }
        }
      p = setInterval(q, o)
      q()
      setTimeout(function () {
        clearInterval(p)
      }, r)
    }
    if (d.isIabLayout) {
      var h = false
      var j = document.head.getElementsByTagName('script')
      for (var i = 0; i < j.length; i++) {
        var k = j[i]
        if (k.id === '') {
          h = true
          d.feat.iab = true
        }
      }
      if (!h) {
        l(
          function n() {
            return typeof __tcfapi !== 'undefined'
          },
          function e() {
            m(d.consensuUrl + 'asset/tcfapi.js/v/2.1')
          },
          10,
          30000,
        )
      }
    }
  })(truste.eu.bindMap)
  truste.util.createCookie = function (C, t, h, l) {
    if (truste.util.cookie) {
      t = truste.util.cookie.convert(t)
    }
    var d = truste.eu.bindMap || {},
      z = '; expires='
    if (!h) {
      var w = new Date()
      w.setDate(w.getDate() + d.cookieExpiry)
      z += w.toGMTString()
    } else {
      if (h == '0') {
        z = ''
      } else {
        z += h
      }
    }
    if (l && truste.util.createCookieStorage) {
      truste.util.createCookieStorage(C, t, w)
    }
    var x = d.domain,
      n = self.location.hostname
    var j =
      !!n.match(/^\d{0,3}\.\d{0,3}\.\d{0,3}\.\d{0,3}$/) || n == 'localhost'
    var u = new RegExp('[.]' + x + '$|^' + x + '$')
    var o = x && u.test(n) ? x : j ? n : n.replace(/^www\./, '')
    var k = self.location.protocol == 'https:' ? ' Secure;' : ''
    var B = k ? 'None;' : 'Lax;'
    var r =
      (truste.util.samesite && !truste.util.samesite(navigator.userAgent)
        ? ''
        : ' SameSite=' + B) + k
    if (typeof truste.eu.noticeLP.pcookie != 'undefined') {
      document.cookie =
        C +
        '=;expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/;domain=' +
        (j ? '' : '.') +
        o.replace(/^\./, '') +
        ';' +
        r
      if (!d.topLevelDomain) {
        var v = 0,
          A = o,
          q = A.split('.'),
          y = [],
          m = '_gd' + new Date().getTime()
        while (v < q.length - 1 && document.cookie.indexOf(m + '=' + m) == -1) {
          A = q.slice(-1 - ++v).join('.')
          document.cookie = m + '=' + m + ';domain=' + A + ';'
          y.push(m)
        }
        d.topLevelDomain = A
        for (var e = 0; e < y.length; e++) {
          document.cookie =
            y[e] + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=' + A + ';'
        }
        document.cookie =
          m + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=' + A + ';' + r
      }
      o = d.topLevelDomain
    }
    self.document.cookie =
      C +
      '=' +
      t +
      z +
      '; path=/;domain=' +
      (j ? '' : '.') +
      o.replace(/^\./, '') +
      ';' +
      r
  }
  if (g.feat.dropBehaviorCookie) {
    var a = g.feat.replaceDelimiter ? '|' : ','
    truste.util.createCookie(
      '',
      g.behavior + a + g.behaviorManager,
      '0',
    )
  }
  if (!truste.cma) {
    var f = self.document,
      c = f.createElement('script')
    c.setAttribute('async', 'async')
    c.setAttribute('type', 'text/javascript')
    c.setAttribute('crossorigin', '')
    c.setAttribute('importance', 'high')
    c.src = g.noticeJsURL
    ;(
      f.getElementById(g.containerId) ||
      f.getElementsByTagName('body')[0] ||
      f.getElementsByTagName('head')[0]
    ).appendChild(c)
  }
  ;(function (e) {
    if (e.feat.crossDomain) {
      var d = function () {
        if (!window.frames.trustarc_notice) {
          if (document.body) {
            var h = document.body,
              i = document.createElement('iframe')
            i.style.display = 'none'
            i.name = ''
            i.id = ''
            i.title = 'Trustarc Cross-Domain Consent Frame'
            i.src = e.cdnURL + 'get?name=crossdomain.html&domain=' + e.domain
            h.appendChild(i)
          } else {
            setTimeout(d, 5)
          }
        }
      }
      d()
    }
  })(truste.eu.bindMap)
  $temp_box_overlay = { margin: '20px auto !important' }
  g.styles = {}
  g.externalcss = typeof $temp_externalcss != 'undefined' && $temp_externalcss
  g.styles.closebtnlink =
    typeof $temp_closebtnlink_style != 'undefined' && $temp_closebtnlink_style
  g.styles.closebtn =
    typeof $temp_closebtn_style != 'undefined' && $temp_closebtn_style
  g.styles.box_overlay =
    typeof $temp_box_overlay != 'undefined' && $temp_box_overlay
  g.styles.box_overlay_border =
    typeof $temp_box_overlay_border != 'undefined' && $temp_box_overlay_border
  g.styles.overlay = typeof $temp_overlay != 'undefined' && $temp_overlay
  g.styles.inner_iframe =
    typeof $temp_inner_iframe != 'undefined' && $temp_inner_iframe
  g.styles.outerdiv =
    typeof $temp_style_outerdiv != 'undefined' && $temp_style_outerdiv
  g.outerdiv = typeof $temp_outerdiv != 'undefined'
}
;(self._truste && (self._truste.eumap = _truste_eumap)) || _truste_eumap()
