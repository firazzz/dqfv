<?php

?>
<div class="site-footer-wrapper centered">
                 <div class="footer-divider"></div>
                 <div class="site-footer">
                    <p class="footer-top"><?php echo $Desquestion ?><a class="footer-top-a" href="#"><?php echo $Numeronetflix ?></a></p>
                    <ul class="footer-links structural">
                       <li class="footer-link-item" placeholder="footer_responsive_link_faq_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_faq"><span id="" data-uia="data-uia-footer-label"><?php echo $FAQ ?></span></a></li>
                       <li class="footer-link-item" placeholder="footer_responsive_link_help_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_help"><span id="" data-uia="data-uia-footer-label"><?php echo $centredaide ?></span></a></li>
                       <li class="footer-link-item" placeholder="footer_responsive_link_terms_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_terms"><span id="" data-uia="data-uia-footer-label"><?php echo $Conditionsdutilisation ?></span></a></li>
                       <li class="footer-link-item" placeholder="footer_responsive_link_privacy_separate_link_item"><a class="footer-link" data-uia="footer-link" href="#"><span id="" data-uia="data-uia-footer-label"><?php echo $Confidentialite ?></span></a></li>
                       <li class="footer-link-item" placeholder="footer_responsive_link_cookies_separate_link_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_cookies_separate_link"><span id="" data-uia="data-uia-footer-label"><?php echo $Cookies ?></span></a></li>
                       <li class="footer-link-item" placeholder="footer_responsive_link_corporate_information_item"><a class="footer-link" data-uia="footer-link" href="#" placeholder="footer_responsive_link_corporate_information"><span id="" data-uia="data-uia-footer-label"><?php echo $Mentionslegales ?></span></a></li>
                    </ul>
                    <div class="lang-selection-container" id="lang-switcher">
                       <div class="nfSelectWrapper inFooter selectArrow prefix" data-uia="language-picker+container">
                          <label class="nfLabel" for="lang-switcher-select"><?php echo $Choisirlangue ?></label>
                          <div class="nfSelectPlacement globe">
                             <select data-uia="language-picker" class="nfSelect" id="lang-switcher-select" name="__langSelect" tabindex="0">
                                <option selected=""  label="Français"><?php echo $Langue1 ?></option>
                                <option  label="English"><?php echo $Langue2 ?></option>
                             </select>
                          </div>
                       </div>
                    </div>
                 </div>
</div>